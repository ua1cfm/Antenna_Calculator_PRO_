#define _GNU_SOURCE
#include <jni.h>
#include <android/log.h>
#include <complex.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "opennec.h"
#include "internals.h"
#include "input.h"
#include "control.h"
#include "radiation.h"
#include "deck.h"
#include "import-export/nec2-support.h"

#define LOG_TAG "CSTFFS-OpenNEC"


typedef struct {
    int declared_sources;
    int declared_loads;
} maa_normalize_info_t;

static int compact_line(const char *src, size_t len, char *dst, size_t cap) {
    if (!src || !dst || cap == 0) return -1;
    size_t j = 0;
    for (size_t i = 0; i < len; ++i) {
        unsigned char c = (unsigned char)src[i];
        if (c == ' ' || c == '\t' || c == '\r' || c == '\n') continue;
        if (j + 1 >= cap) return -1;
        dst[j++] = (char)c;
    }
    dst[j] = '\0';
    return 0;
}

static int is_source_header(const char *compact) {
    return strcmp(compact, "***Source***") == 0 ||
           strcmp(compact, "***Источ.***") == 0;
}

static int is_load_header(const char *compact) {
    return strcmp(compact, "***Load***") == 0 ||
           strcmp(compact, "***Нагрузка***") == 0;
}

static int is_segmentation_header(const char *compact) {
    return strcmp(compact, "***Segmentation***") == 0 ||
           strcmp(compact, "***Автосегм***") == 0;
}

static int is_ground_header(const char *compact) {
    return strncmp(compact, "***G/H/M/R", 10) == 0 ||
           strncmp(compact, "*G/H/M/R", 8) == 0;
}

/*
 * OpenNEC 2.2.0's MAA importer intentionally understands only its compact
 * English section names (***Source***, ***Load***, ...).  Real MMANA-GAL
 * libraries commonly use spaced English headers or localized Russian ones.
 * Canonicalize only the section markers; all numeric geometry/source data is
 * copied byte-for-byte so the NEC solver receives the original model values.
 */
static char *normalize_maa_for_opennec(const char *src, maa_normalize_info_t *info) {
    if (!src) return NULL;
    if (info) {
        info->declared_sources = -1;
        info->declared_loads = -1;
    }

    const size_t len = strlen(src);
    /* Canonical markers are never longer than the originals; a little slack
       keeps the routine safe if the final line has no newline. */
    size_t cap = len + 256;
    char *out = (char *)malloc(cap);
    if (!out) return NULL;
    size_t used = 0;
    int expect_count = 0; /* 1=source, 2=load */

    const char *p = src;
    while (*p) {
        const char *nl = strchr(p, '\n');
        size_t line_len = nl ? (size_t)(nl - p) : strlen(p);
        size_t match_len = line_len;
        if (match_len > 0 && p[match_len - 1] == '\r') match_len--;

        char compact[512];
        int compact_ok = compact_line(p, match_len, compact, sizeof(compact)) == 0;
        const char *replacement = NULL;
        if (compact_ok && is_source_header(compact)) {
            replacement = "***Source***";
            expect_count = 1;
        } else if (compact_ok && is_load_header(compact)) {
            replacement = "***Load***";
            expect_count = 2;
        } else if (compact_ok && is_segmentation_header(compact)) {
            replacement = "***Segmentation***";
            expect_count = 0;
        } else if (compact_ok && is_ground_header(compact)) {
            replacement = "***G/H/M/R/AzEl/X***";
            expect_count = 0;
        }

        if (!replacement && expect_count != 0 && compact_ok && compact[0] != '\0' && compact[0] != '*') {
            char *endp = NULL;
            long count = strtol(compact, &endp, 10);
            if (endp != compact && count >= 0 && count <= 100000) {
                if (info) {
                    if (expect_count == 1) info->declared_sources = (int)count;
                    else info->declared_loads = (int)count;
                }
                expect_count = 0;
            }
        }

        const char *write_ptr = replacement ? replacement : p;
        size_t write_len = replacement ? strlen(replacement) : line_len;
        size_t need = used + write_len + (nl ? 1 : 0) + 1;
        if (need > cap) {
            size_t new_cap = cap * 2;
            while (new_cap < need) new_cap *= 2;
            char *tmp = (char *)realloc(out, new_cap);
            if (!tmp) { free(out); return NULL; }
            out = tmp;
            cap = new_cap;
        }
        memcpy(out + used, write_ptr, write_len);
        used += write_len;
        if (nl) out[used++] = '\n';
        p = nl ? nl + 1 : p + line_len;
    }
    out[used] = '\0';
    return out;
}

static int count_deck_cards(const deck_t *deck, const char *code) {
    if (!deck || !code) return 0;
    int n = 0;
    for (int i = 0; i < deck->num_cards; ++i) {
        if (strcmp(deck->cards[i].card_code, code) == 0) n++;
    }
    return n;
}

static void free_errors_list(errors_list_t *list) {
    if (!list || !list->errors) return;
    for (int i = 0; i < list->num_errors; ++i) {
        free(list->errors[i].message);
        list->errors[i].message = NULL;
    }
    free(list->errors);
    list->errors = NULL;
    list->num_errors = 0;
}

static void append_text(char *dst, size_t cap, const char *s) {
    if (!dst || !s || cap == 0) return;
    size_t used = strlen(dst);
    if (used >= cap - 1) return;
    strncat(dst, s, cap - used - 1);
}

static void append_error_summary(char *dst, size_t cap, const errors_list_t *list) {
    if (!list || list->num_errors <= 0) return;
    for (int i = 0; i < list->num_errors; ++i) {
        const error_t *e = &list->errors[i];
        if (!e->message || !e->message[0]) continue;
        if (dst[0]) append_text(dst, cap, " / ");
        append_text(dst, cap, e->message);
        if (strlen(dst) > cap - 96) break;
    }
}

static void jni_log(void *user_data, int level, const char *message) {
    (void)user_data;
    int prio = ANDROID_LOG_INFO;
    if (level >= ONEC_SEV_FATAL) prio = ANDROID_LOG_ERROR;
    else if (level >= ONEC_SEV_WARNING) prio = ANDROID_LOG_WARN;
    __android_log_print(prio, LOG_TAG, "%s", message ? message : "");
}

static int prepare_execution_deck(deck_t *deck, int include_pattern) {
    (void)include_pattern;
    if (!deck) return -1;

    /* 1.19.35: the NEC deck itself is solved only once with XQ.
       Do NOT append an RP card here.  The embedded-library RP batching path can leave
       ctx->rpat empty after an XQ-only solve even though impedance/currents are valid.
       After run_simulation() returns, JNI calls OpenNEC's own
       compute_radiation_pattern() directly on those solved currents. */
    for (int i = deck->num_cards - 1; i >= 0; --i) {
        if (strcmp(deck->cards[i].card_code, "RP") == 0 ||
            strcmp(deck->cards[i].card_code, "XQ") == 0) {
            if (remove_card(deck, i) != 0) return -1;
        }
    }

    int en_index = -1;
    for (int i = 0; i < deck->num_cards; ++i) {
        if (strcmp(deck->cards[i].card_code, "EN") == 0 && en_index < 0) en_index = i;
    }
    if (en_index < 0) return -1;

    if (append_card_from_text(deck, "XQ 0") != 0) return -1;
    int exec_index = deck->num_cards - 1;
    if (move_card(deck, exec_index, en_index) != 0) return -1;
    return 0;
}

/*
 * Compute a full 2.5-degree OpenNEC RP grid directly from the already solved XQ
 * currents.  This intentionally mirrors control.c:execute_extra_patterns(): after
 * execute_frequency_loop() returns, geometry is back in metres, while
 * compute_radiation_pattern()/far_e_field() expect wavelength units.
 */
static int compute_native_rp_after_solve(context_t *ctx) {
    if (!ctx || !ctx->crnt.surface_cur || ctx->geometry.num_segs <= 0) return -1;
    if (!(ctx->save.freq_mhz > 0.0) || !(ctx->geometry.wavelength > 0.0)) return -1;
    if (!(ctx->netcx.power_in > 1.0e-30) || !isfinite(ctx->netcx.power_in)) return -1;

    ctx->gnd.far_field_type = 0; /* ordinary far field; ground type remains in ctx->gnd */
    ctx->fpat.is_near_field = -1;
    ctx->fpat.num_theta = 73;    /* 0..180 deg in 2.5 deg */
    ctx->fpat.num_phi = 145;     /* 0..360 deg in 2.5 deg */
    ctx->fpat.gain_type = 0;     /* power gain, exactly RP I4=0 */
    ctx->fpat.avg_power_flag = 0;
    ctx->fpat.normalize_gain = 0;
    ctx->fpat.pol_axis = 0;
    ctx->fpat.theta_start = 0.0;
    ctx->fpat.phi_start = 0.0;
    ctx->fpat.theta_step = 2.5;
    ctx->fpat.phi_step = 2.5;
    ctx->fpat.range = 0.0;
    ctx->fpat.norm_gain = 0.0;
    ctx->fpat.power_in = ctx->netcx.power_in;
    ctx->fpat.network_loss = ctx->netcx.power_net_loss;

    const double fr = 1.0 / ctx->geometry.wavelength; /* metres -> wavelengths */
    for (int i = 0; i < ctx->geometry.num_segs; ++i) {
        ctx->geometry.x_center[i] *= fr;
        ctx->geometry.y_center[i] *= fr;
        ctx->geometry.z_center[i] *= fr;
        ctx->geometry.half_len[i] *= fr;
        ctx->geometry.radius[i] *= fr;
    }
    if (ctx->geometry.num_patches > 0) {
        const double fr2 = fr * fr;
        for (int i = 0; i < ctx->geometry.num_patches; ++i) {
            ctx->geometry.patch_x_center[i] *= fr;
            ctx->geometry.patch_y_center[i] *= fr;
            ctx->geometry.patch_z_center[i] *= fr;
            ctx->geometry.patch_area[i] *= fr2;
        }
    }

    compute_radiation_pattern(ctx);

    for (int i = 0; i < ctx->geometry.num_segs; ++i) {
        ctx->geometry.x_center[i] /= fr;
        ctx->geometry.y_center[i] /= fr;
        ctx->geometry.z_center[i] /= fr;
        ctx->geometry.half_len[i] /= fr;
        ctx->geometry.radius[i] /= fr;
    }
    if (ctx->geometry.num_patches > 0) {
        const double fr2 = fr * fr;
        for (int i = 0; i < ctx->geometry.num_patches; ++i) {
            ctx->geometry.patch_x_center[i] /= fr;
            ctx->geometry.patch_y_center[i] /= fr;
            ctx->geometry.patch_z_center[i] /= fr;
            ctx->geometry.patch_area[i] /= fr2;
        }
    }

    if (!ctx->rpat.points || ctx->rpat.num_points <= 0) return -1;
    return 0;
}
JNIEXPORT jstring JNICALL
Java_ua1cfm_cstffs_OpenNecFull_nativeSolveNec(JNIEnv *env, jclass clazz, jstring nec_text, jboolean include_pattern_j) {
    (void)clazz;
    const int include_pattern = include_pattern_j == JNI_TRUE;
    if (!nec_text) return (*env)->NewStringUTF(env, "ERR|Empty NEC-2 deck");

    const char *utf = (*env)->GetStringUTFChars(env, nec_text, NULL);
    if (!utf) return (*env)->NewStringUTF(env, "ERR|Failed to get UTF-8 NEC deck");

    FILE *in = NULL;
    FILE *out = NULL;
    FILE *err = NULL;
    char *out_buf = NULL;
    char *err_buf = NULL;
    size_t out_size = 0;
    size_t err_size = 0;
    context_t *ctx = NULL;
    deck_t deck;
    int deck_initialized = 0;
    errors_list_t import_errors = {0};
    char result[32768];
    char *dynamic_result = NULL;
    result[0] = '\0';

    size_t utf_len = strlen(utf);
    in = fmemopen((void *)utf, utf_len, "r");
    out = open_memstream(&out_buf, &out_size);
    err = open_memstream(&err_buf, &err_size);
    if (!in || !out || !err) {
        snprintf(result, sizeof(result), "ERR|Failed to create memory stream for OpenNEC");
        goto done;
    }

    ctx = create_context();
    if (!ctx) {
        snprintf(result, sizeof(result), "ERR|OpenNEC: create_context failed");
        goto done;
    }
    set_log_callback(ctx, jni_log, NULL);
    ctx->input_fp = in;
    ctx->output_fp = out;
    ctx->error_fp = err;

    init_deck(&deck);
    deck_initialized = 1;
    if (read_deck_nec2(&deck, in) != 0) {
        snprintf(result, sizeof(result), "ERR|OpenNEC could not read the standard NEC-2 deck");
        goto done;
    }

    /* read_deck_nec2/read_deck stores raw lines in orig_str only.  OpenNEC fills
       card_code (GW/EX/LD/XQ/EN...) inside parse_deck().  Therefore card counting
       and any card-code based deck manipulation MUST happen after parse_deck(). */
    parse_deck(ctx, &deck, &import_errors);

    if (import_errors.num_errors > 0) {
        int has_fatal = 0;
        for (int i = 0; i < import_errors.num_errors; ++i) {
            if (import_errors.errors[i].severity >= FATAL) { has_fatal = 1; break; }
        }
        if (has_fatal) {
            char msg[8192] = {0};
            append_error_summary(msg, sizeof(msg), &import_errors);
            snprintf(result, sizeof(result), "ERR|OpenNEC NEC-deck import: %s", msg[0] ? msg : "fatal error");
            goto done;
        }
    }

    const int imported_ex = count_deck_cards(&deck, "EX");
    if (imported_ex <= 0) {
        snprintf(result, sizeof(result), "ERR|NEC-2 FULL: EX source not found after parse_deck");
        goto done;
    }

    if (prepare_execution_deck(&deck, include_pattern) != 0) {
        snprintf(result, sizeof(result), "ERR|OpenNEC: failed to prepare %s deck after parse_deck", include_pattern ? "RP pattern" : "XQ impedance");
        goto done;
    }

    initialize_symbol_table(&deck, &import_errors);
    update_deck_values(ctx, &deck);

    /* Execution card was inserted after parse_deck. update_deck_values() above evaluates
       the new card together with the already-parsed geometry/control cards. */
    int sim_rc = run_simulation(ctx, &deck);
    if (sim_rc != 0) {
        char msg[8192] = {0};
        append_error_summary(msg, sizeof(msg), &ctx->errors);
        snprintf(result, sizeof(result), "ERR|OpenNEC solver: %s", msg[0] ? msg : "simulation failed");
        goto done;
    }

    if (ctx->netcx.ninp <= 0 || ctx->netcx.inp_z == NULL) {
        char msg[8192] = {0};
        append_error_summary(msg, sizeof(msg), &ctx->errors);
        snprintf(result, sizeof(result), "ERR|OpenNEC did not return input impedance%s%s",
                 msg[0] ? ": " : "", msg);
        goto done;
    }

    char warnings[8192] = {0};
    append_error_summary(warnings, sizeof(warnings), &import_errors);
    if (ctx->errors.num_errors > 0) append_error_summary(warnings, sizeof(warnings), &ctx->errors);
    if (ctx->netcx.ninp != imported_ex) {
        char count_msg[256];
        snprintf(count_msg, sizeof(count_msg), "%sEX=%d, returned inputs=%d",
                 warnings[0] ? "; " : "", imported_ex, ctx->netcx.ninp);
        append_text(warnings, sizeof(warnings), count_msg);
    }

    /* Return both the input impedance and the actual solved complex current on every
       OpenNEC wire segment. OpenNEC's own solver defines the physical current as
       surface_cur[i] * wavelength, in amperes.

       IMPORTANT (v1.19.32): run_simulation()/execute_frequency_loop() restores
       x_center/y_center/z_center/half_len/radius to the ORIGINAL UNSCALED METRE
       values before returning. Older JNI code multiplied those values by wavelength
       a second time. That left input Z untouched, but corrupted every reconstructed
       far-/near-field phase k*r. Export geometry directly in metres here. */
    const int nseg = ctx->geometry.num_segs;
    if (nseg <= 0 || ctx->crnt.surface_cur == NULL) {
        snprintf(result, sizeof(result), "ERR|OpenNEC did not return segment currents");
        goto done;
    }

    /* 1.19.35: native RP is calculated directly from the valid XQ solution.
       If OpenNEC cannot produce it for some unusual model, leave npat=0; Kotlin
       will fall back to the exact A/B/C current-basis renderer instead of showing
       a blank 3D panel. */
    int native_pattern_ok = 0;
    if (include_pattern) {
        native_pattern_ok = (compute_native_rp_after_solve(ctx) == 0);
        if (!native_pattern_ok) {
            if (warnings[0]) append_text(warnings, sizeof(warnings), "; ");
            append_text(warnings, sizeof(warnings), "native RP unavailable; exact A/B/C fallback active");
        }
    }

    /* v1.19.30 also exports OpenNEC's A/B/C current-expansion coefficients.
       They are required for the exact NEC far-field integral; a single centre current
       per segment is not sufficient for directional arrays such as Yagis. */
    const int has_basis = ctx->crnt.a_real && ctx->crnt.a_imag &&
                          ctx->crnt.b_real && ctx->crnt.b_imag &&
                          ctx->crnt.c_real && ctx->crnt.c_imag;
    const int npat = (include_pattern && native_pattern_ok && ctx->rpat.points != NULL && ctx->rpat.num_points > 0)
        ? ctx->rpat.num_points : 0;
    size_t dyn_cap = 4096u + (size_t)ctx->netcx.ninp * 160u + (size_t)nseg * 560u +
                     (size_t)npat * 96u + strlen(warnings) + 1u;
    dynamic_result = (char *)calloc(dyn_cap, 1u);
    if (!dynamic_result) {
        snprintf(result, sizeof(result), "ERR|Not enough memory for NEC-2 FULL currents");
        goto done;
    }

    snprintf(dynamic_result, dyn_cap, "OK|%s|%.9g|%d|", VERSION_STRING, ctx->save.freq_mhz, ctx->netcx.ninp);
    for (int i = 0; i < ctx->netcx.ninp; ++i) {
        char row[256];
        complex double z = ctx->netcx.inp_z[i];
        int tag = ctx->netcx.inp_tag ? ctx->netcx.inp_tag[i] : 0;
        int seg = ctx->netcx.inp_seg ? ctx->netcx.inp_seg[i] : 0;
        snprintf(row, sizeof(row), "%s%d,%d,%.15g,%.15g",
                 i ? ";" : "", tag, seg, creal(z), cimag(z));
        append_text(dynamic_result, dyn_cap, row);
    }

    append_text(dynamic_result, dyn_cap, "|");
    {
        char nbuf[64];
        snprintf(nbuf, sizeof(nbuf), "%d|", nseg);
        append_text(dynamic_result, dyn_cap, nbuf);
    }

    for (int i = 0; i < nseg; ++i) {
        const int tag = ctx->geometry.tag_nums ? ctx->geometry.tag_nums[i] : 0;
        int rel_seg = 1;
        for (int j = 0; j < i; ++j) {
            if (ctx->geometry.tag_nums && ctx->geometry.tag_nums[j] == tag) rel_seg++;
        }
        const double wl = ctx->geometry.wavelength;
        const complex double cur_a = ctx->crnt.surface_cur[i] * wl;
        char row[1024];
        const double ar = has_basis ? ctx->crnt.a_real[i] : NAN;
        const double ai = has_basis ? ctx->crnt.a_imag[i] : NAN;
        const double br = has_basis ? ctx->crnt.b_real[i] : NAN;
        const double bi = has_basis ? ctx->crnt.b_imag[i] : NAN;
        const double cr = has_basis ? ctx->crnt.c_real[i] : NAN;
        const double ci = has_basis ? ctx->crnt.c_imag[i] : NAN;
        snprintf(row, sizeof(row),
                 "%s%d,%d,%d,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g",
                 i ? ";" : "", i, tag, rel_seg,
                 ctx->geometry.x_center[i],
                 ctx->geometry.y_center[i],
                 ctx->geometry.z_center[i],
                 ctx->geometry.half_len[i] * 2.0, /* run_simulation restored metres */
                 ctx->geometry.radius[i],
                 ctx->geometry.dir_cos_x[i],
                 ctx->geometry.dir_cos_y[i],
                 ctx->geometry.dir_cos_z[i],
                 creal(cur_a), cimag(cur_a),
                 ar, ai, br, bi, cr, ci);
        append_text(dynamic_result, dyn_cap, row);
    }
    append_text(dynamic_result, dyn_cap, "|");
    append_text(dynamic_result, dyn_cap, warnings);

    /* Native RP payload. gtot is OpenNEC's own total gain in dB after coherent Etheta/Ephi
       summation, so Kotlin no longer has to recreate phase-sensitive Yagi/Quad patterns. */
    {
        char hdr[64];
        snprintf(hdr, sizeof(hdr), "|%d|", npat);
        append_text(dynamic_result, dyn_cap, hdr);
    }
    for (int i = 0; i < npat; ++i) {
        const rpat_point_t *pt = &ctx->rpat.points[i];
        char prow[160];
        snprintf(prow, sizeof(prow), "%s%.9g,%.9g,%.15g",
                 i ? ";" : "", pt->theta, pt->phi, pt->gtot);
        append_text(dynamic_result, dyn_cap, prow);
    }

done:
    if (deck_initialized) destroy_deck(&deck);
    free_errors_list(&import_errors);
    if (ctx) {
        ctx->input_fp = NULL;
        ctx->output_fp = NULL;
        ctx->error_fp = NULL;
        destroy_context(ctx);
    }
    if (in) fclose(in);
    if (out) fclose(out);
    if (err) fclose(err);
    free(out_buf);
    free(err_buf);
    (*env)->ReleaseStringUTFChars(env, nec_text, utf);
    const char *final_result = dynamic_result ? dynamic_result : (result[0] ? result : "ERR|Unknown OpenNEC error");
    jstring java_result = (*env)->NewStringUTF(env, final_result);
    free(dynamic_result);
    return java_result;
}
