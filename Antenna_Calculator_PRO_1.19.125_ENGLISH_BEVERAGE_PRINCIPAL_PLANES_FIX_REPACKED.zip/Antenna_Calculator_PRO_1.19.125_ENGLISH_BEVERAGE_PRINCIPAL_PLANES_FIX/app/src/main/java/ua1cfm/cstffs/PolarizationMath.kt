package ua1cfm.cstffs

import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Pure math helpers for a fully coherent two-component electric-field phasor. */
object PolarizationMath {
    enum class Kind { TOO_SMALL, NEAR_CIRCULAR, ELLIPTICAL, ELONGATED, NEAR_LINEAR }

    data class Analysis(
        val amplitudeU: Double,
        val amplitudeV: Double,
        val minMaxAmplitudeRatio: Double,
        /** phase(V) - phase(U), normalized to (-180, +180]. */
        val deltaPhaseDeg: Double,
        /** Major/minor field-axis ratio. 1 = circular, very large = linear. */
        val axialRatio: Double,
        val kind: Kind
    )

    fun analyze(uRe: Double, uIm: Double, vRe: Double, vIm: Double): Analysis {
        val au = sqrt(uRe * uRe + uIm * uIm)
        val av = sqrt(vRe * vRe + vIm * vIm)
        var dPhi = Math.toDegrees(atan2(vIm, vRe) - atan2(uIm, uRe))
        while (dPhi > 180.0) dPhi -= 360.0
        while (dPhi <= -180.0) dPhi += 360.0

        val s0 = au * au + av * av
        val s1 = au * au - av * av
        // 2*Re(U*conj(V)). Together with s0/s1 this gives the ellipse axes.
        val s2 = 2.0 * (uRe * vRe + uIm * vIm)
        val linearPart = sqrt((s1 * s1 + s2 * s2).coerceAtLeast(0.0))
        val major2 = 0.5 * (s0 + linearPart)
        val minor2 = (0.5 * (s0 - linearPart)).coerceAtLeast(0.0)
        val ar = if (minor2 > major2 * 1e-12) sqrt(major2 / minor2) else 1.0e6
        val ratio = if (max(au, av) > 1e-30) min(au, av) / max(au, av) else 0.0
        val kind = when {
            s0 <= 1e-30 -> Kind.TOO_SMALL
            ar <= 1.20 -> Kind.NEAR_CIRCULAR
            ar <= 3.0 -> Kind.ELLIPTICAL
            ar <= 20.0 -> Kind.ELONGATED
            else -> Kind.NEAR_LINEAR
        }
        return Analysis(au, av, ratio, dPhi, ar, kind)
    }
}
