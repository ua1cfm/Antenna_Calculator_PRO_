package ua1cfm.cstffs

import android.graphics.Paint
import android.graphics.Bitmap
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.DocumentsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.BufferedReader
import java.io.StringReader
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.nio.charset.Charset
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.log10
import kotlin.math.sqrt
import kotlin.math.sin
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean

private enum class MaaViewMode { ISO, SIDE, FRONT }
private enum class MaaPatternMode { POLAR, RECT }
private enum class MaaCutView { PRINCIPAL_1, PRINCIPAL_2 }
private enum class MaaFieldDisplay { H_DB, E_DB, H_LINEAR, E_LINEAR, B_MICROTESLA, S_DB, S_LINEAR, Z_EH }
private enum class MaaFieldDetail { NORMAL, HIGH, ULTRA }

/**
 * Audio/visual impedance palette.
 * X < 0: violet/blue, X ~= 0: green, X > 0: yellow/red.
 * Brightness increases as |Gamma| approaches zero (better match).
 */
private fun impedanceSweepColor(rOhm: Double, xOhm: Double, z0Ohm: Double): Color {
    val z0 = z0Ohm.coerceAtLeast(1e-9)
    val xNorm = (xOhm / (2.0 * z0)).coerceIn(-1.0, 1.0)
    val hue = if (xNorm <= 0.0) {
        (120.0 + (-xNorm) * 120.0).toFloat() // green -> blue
    } else {
        (120.0 - xNorm * 120.0).toFloat()    // green -> red
    }
    val den = (rOhm + z0) * (rOhm + z0) + xOhm * xOhm
    val gammaMag = if (den <= 1e-30 || !den.isFinite()) 1.0 else {
        val gr = (((rOhm - z0) * (rOhm + z0) + xOhm * xOhm) / den)
        val gi = (2.0 * z0 * xOhm / den)
        kotlin.math.hypot(gr, gi).coerceIn(0.0, 1.0)
    }
    val saturation = (0.58 + 0.34 * kotlin.math.abs(xNorm)).toFloat().coerceIn(0f, 1f)
    val value = (1.0 - 0.36 * gammaMag).toFloat().coerceIn(0.55f, 1f)
    return Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, saturation, value)))
}


private fun sonogramScalarColor(value01: Double, invert: Boolean = false): Color {
    val u0 = value01.coerceIn(0.0, 1.0)
    val u = if (invert) 1.0 - u0 else u0
    // green -> yellow -> red: compact "good to bad" engineering palette.
    val hue = (120.0 * (1.0 - u)).toFloat()
    return Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, 0.82f, 0.96f)))
}

private fun sonogramResistanceColor(rOhm: Double, z0Ohm: Double): Color {
    val z0 = z0Ohm.coerceAtLeast(1e-9)
    val e = ((rOhm - z0) / z0).coerceIn(-1.0, 1.0)
    // Low R = cyan/blue, R=R0 = green, high R = orange/red.
    val hue = if (e < 0.0) (120.0 + (-e) * 90.0) else (120.0 - e * 120.0)
    return Color(android.graphics.Color.HSVToColor(floatArrayOf(hue.toFloat(), 0.78f, 0.95f)))
}

private fun sonogramPhaseColor(phaseDeg: Double): Color {
    val p = ((phaseDeg + 180.0) / 360.0).coerceIn(0.0, 1.0)
    val hue = (300.0 * p).toFloat()
    return Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, 0.72f, 0.95f)))
}

private fun gammaMagFromZ(rOhm: Double, xOhm: Double, z0Ohm: Double): Double =
    impedanceToGamma(rOhm, xOhm, z0Ohm).mag.coerceIn(0.0, 1.0)


private data class AntennaNoisePoint(
    val frequencyMHz: Double,
    val totalK: Double,
    val skyContributionK: Double,
    val groundContributionK: Double,
    val lossContributionK: Double,
    val skyBrightnessK: Double,
    val radiationEfficiency: Double,
    val skyFraction: Double,
    val groundFraction: Double
)

/**
 * Engineering antenna-noise estimate from the solver-native absolute RP gain grid.
 * The normalized angular weighting is independent of gain scale, while the integral
 * of absolute gain over 4π provides an estimate of radiation efficiency.
 */
private fun antennaNoiseFromNec(result: OpenNecFull.Result): AntennaNoisePoint {
    val points = result.nativePattern.filter {
        it.thetaDeg.isFinite() && it.phiDeg.isFinite() && it.gainDb.isFinite() &&
            it.phiDeg >= -1e-6 && it.phiDeg < 360.0 - 1e-6 &&
            it.thetaDeg >= -1e-6 && it.thetaDeg <= 180.0 + 1e-6 &&
            it.gainDb > -290.0
    }
    require(points.size >= 100) { "NEC native 3D gain grid is unavailable for antenna-noise calculation." }

    val thetaValues = points.map { it.thetaDeg }.distinct().sorted()
    val phiValues = points.map { it.phiDeg }.distinct().sorted()
    val dThetaDeg = thetaValues.zipWithNext { a, b -> b - a }.filter { it > 1e-6 }.minOrNull() ?: 2.5
    val dPhiDeg = phiValues.zipWithNext { a, b -> b - a }.filter { it > 1e-6 }.minOrNull() ?: 2.5
    val dTheta = Math.toRadians(dThetaDeg)
    val dPhi = Math.toRadians(dPhiDeg)

    var totalW = 0.0
    var skyW = 0.0
    var groundW = 0.0
    var absoluteGainIntegral = 0.0
    for (q in points) {
        val theta = Math.toRadians(q.thetaDeg.coerceIn(0.0, 180.0))
        val domega = kotlin.math.sin(theta).coerceAtLeast(0.0) * dTheta * dPhi
        val gain = Math.pow(10.0, q.gainDb.coerceIn(-300.0, 100.0) / 10.0)
        val w = gain * domega
        totalW += w
        absoluteGainIntegral += w
        if (q.thetaDeg <= 90.0) skyW += w else groundW += w
    }
    require(totalW > 1e-20) { "NEC gain integral is zero." }

    val skyFraction = (skyW / totalW).coerceIn(0.0, 1.0)
    val groundFraction = (groundW / totalW).coerceIn(0.0, 1.0)
    val etaRad = (absoluteGainIntegral / (4.0 * PI)).coerceIn(0.0, 1.0)

    val fMHz = result.frequencyMHz.coerceAtLeast(0.1)
    // Quiet-sky engineering model: CMB + galactic background.
    val skyBrightness = (2.725 + 60.0 * Math.pow(300.0 / fMHz, 2.55)).coerceIn(2.725, 1.0e7)
    val physicalK = 290.0
    val skyContribution = etaRad * skyFraction * skyBrightness
    val groundContribution = etaRad * groundFraction * physicalK
    val lossContribution = (1.0 - etaRad) * physicalK
    val total = skyContribution + groundContribution + lossContribution

    return AntennaNoisePoint(
        frequencyMHz = result.frequencyMHz,
        totalK = total,
        skyContributionK = skyContribution,
        groundContributionK = groundContribution,
        lossContributionK = lossContribution,
        skyBrightnessK = skyBrightness,
        radiationEfficiency = etaRad,
        skyFraction = skyFraction,
        groundFraction = groundFraction
    )
}

@Composable
private fun AntennaNoiseTemperatureCard(
    points: List<AntennaNoisePoint>,
    running: Boolean,
    progress: Int,
    error: String?,
    onCalculate: () -> Unit
) {
    val axisColor = MaterialTheme.colorScheme.onSurface
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    val totalColor = MaterialTheme.colorScheme.primary
    val skyColor = MaterialTheme.colorScheme.secondary
    val groundColor = MaterialTheme.colorScheme.tertiary

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("ANTENNA NOISE TEMPERATURE", style = MaterialTheme.typography.titleSmall)
            Button(onClick = onCalculate, modifier = Modifier.fillMaxWidth(), enabled = !running) {
                Text(if (points.isEmpty()) "CALCULATE TANT ±5%" else "RECALCULATE TANT ±5%")
            }
            if (running) {
                LinearProgressIndicator(progress = { progress.coerceIn(0,100) / 100f }, modifier = Modifier.fillMaxWidth())
                Text("NEC noise sweep: $progress%", style = MaterialTheme.typography.bodySmall)
            }
            error?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

            if (points.isNotEmpty()) {
                val center = points.minByOrNull { kotlin.math.abs(it.frequencyMHz - points[points.size/2].frequencyMHz) } ?: points[points.size/2]
                Text("Tant = ${"%.1f".format(center.totalK)} K @ ${"%.6g".format(center.frequencyMHz)} MHz", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Sky ${"%.1f".format(center.skyContributionK)} K  •  Ground ${"%.1f".format(center.groundContributionK)} K  •  Loss ${"%.1f".format(center.lossContributionK)} K",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    "ηrad ≈ ${"%.1f".format(center.radiationEfficiency*100.0)}%  •  sky weighting ${"%.1f".format(center.skyFraction*100.0)}%  •  ground weighting ${"%.1f".format(center.groundFraction*100.0)}%",
                    style = MaterialTheme.typography.bodySmall
                )

                Canvas(Modifier.fillMaxWidth().height(250.dp)) {
                    val padL = 72f
                    val padR = 58f
                    val padT = 18f
                    val padB = 36f
                    val plotW = (size.width - padL - padR).coerceAtLeast(1f)
                    val plotH = (size.height - padT - padB).coerceAtLeast(1f)
                    val rows = 4
                    val rowH = plotH / rows.toFloat()
                    val cellW = plotW / points.size.coerceAtLeast(1).toFloat()
                    val minF = points.minOf { it.frequencyMHz }
                    val maxF = points.maxOf { it.frequencyMHz }
                    val maxT = points.maxOf {
                        maxOf(it.totalK, it.skyContributionK, it.groundContributionK, it.lossContributionK)
                    }.coerceAtLeast(1.0)
                    val minTotalIndex = points.indices.minByOrNull { points[it].totalK } ?: 0

                    fun heatColor(v: Double): Color {
                        val q = (v / maxT).coerceIn(0.0, 1.0)
                        // 240° blue -> 120° green -> 60° yellow -> 0° red.
                        val hue = (240.0 * (1.0 - q)).toFloat()
                        val value = (0.48 + 0.52 * kotlin.math.sqrt(q)).toFloat()
                        return Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, 0.90f, value)))
                    }

                    val selectors: List<(AntennaNoisePoint) -> Double> = listOf(
                        { it.skyContributionK },
                        { it.groundContributionK },
                        { it.lossContributionK },
                        { it.totalK }
                    )
                    val labels = listOf("SKY", "GROUND", "LOSS", "TOTAL")
                    val paint = Paint().apply {
                        color = axisColor.toArgb()
                        textSize = 22f
                        isAntiAlias = true
                    }

                    for (row in 0 until rows) {
                        val top = padT + rowH * row
                        val bottom = top + rowH
                        val selector = selectors[row]
                        points.forEachIndexed { i, pt ->
                            val left = padL + i * cellW
                            val right = if (i == points.lastIndex) padL + plotW else left + cellW + 0.6f
                            drawRect(
                                color = heatColor(selector(pt)),
                                topLeft = Offset(left, top),
                                size = Size((right-left).coerceAtLeast(1f), rowH)
                            )
                        }
                        drawRect(
                            color = axisColor.copy(alpha = if (row == 3) 0.78f else 0.38f),
                            topLeft = Offset(padL, top),
                            size = Size(plotW, rowH),
                            style = Stroke(width = if (row == 3) 2.2f else 1.0f)
                        )
                        drawContext.canvas.nativeCanvas.drawText(labels[row], 4f, top + rowH*0.63f, paint)
                    }

                    // Mark the frequency where TOTAL noise temperature is minimum.
                    val minLeft = padL + minTotalIndex * cellW
                    drawRect(
                        color = axisColor,
                        topLeft = Offset(minLeft, padT + rowH*3f),
                        size = Size(cellW.coerceAtLeast(2f), rowH),
                        style = Stroke(width = 3.2f)
                    )

                    // Shared temperature color bar in kelvin.
                    val barX = padL + plotW + 15f
                    val barW = 18f
                    val steps = 64
                    repeat(steps) { k ->
                        val q0 = k.toDouble() / steps.toDouble()
                        val q1 = (k+1).toDouble() / steps.toDouble()
                        val y0 = padT + plotH * (1f - q1.toFloat())
                        val y1 = padT + plotH * (1f - q0.toFloat())
                        drawRect(
                            color = heatColor(maxT * q0),
                            topLeft = Offset(barX, y0),
                            size = Size(barW, (y1-y0).coerceAtLeast(1f))
                        )
                    }
                    drawRect(axisColor.copy(alpha=.65f), Offset(barX,padT), Size(barW,plotH), style=Stroke(width=1.2f))

                    drawContext.canvas.nativeCanvas.drawText("${"%.0f".format(maxT)} K", barX-5f, padT-3f, paint)
                    drawContext.canvas.nativeCanvas.drawText("0", barX+2f, padT+plotH+24f, paint)
                    drawContext.canvas.nativeCanvas.drawText("${"%.4g".format(minF)}", padL, size.height-5f, paint)
                    val maxLabel = "${"%.4g".format(maxF)} MHz"
                    drawContext.canvas.nativeCanvas.drawText(maxLabel, (padL+plotW-118f).coerceAtLeast(padL), size.height-5f, paint)
                }
                val minTotal = points.minByOrNull { it.totalK }
                minTotal?.let {
                    Text(
                        "MIN TOTAL ${"%.1f".format(it.totalK)} K @ ${"%.6g".format(it.frequencyMHz)} MHz",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Text("TOTAL  •  SKY  •  GROUND  •  LOSS", style = MaterialTheme.typography.bodySmall)
                Text("Engineering estimate from NEC absolute 3D gain. Quiet-sky model + 290 K ground/antenna physical temperature.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

/**
 * Display-only raster density for the Near Field heat map.
 * The NEC/NearField physics grid is never modified here.  Static frames can afford a denser
 * CPU interpolation raster, while animated frames deliberately stay smaller and are enlarged
 * by the GPU with high-quality filtering.
 */
private fun nearFieldRasterSize(gridSize: Int, detail: MaaFieldDetail, animated: Boolean): Int {
    val n = gridSize.coerceAtLeast(2)
    return if (animated) {
        when (detail) {
            MaaFieldDetail.NORMAL -> n.coerceIn(72, 96)
            MaaFieldDetail.HIGH -> n.coerceIn(96, 128)
            MaaFieldDetail.ULTRA -> n.coerceIn(128, 160)
        }
    } else {
        when (detail) {
            MaaFieldDetail.NORMAL -> max(n, 128).coerceAtMost(192)
            MaaFieldDetail.HIGH -> max(n * 2, 256).coerceAtMost(384)
            MaaFieldDetail.ULTRA -> max(n * 3, 384).coerceAtMost(512)
        }
    }
}

/** 1024-entry version of the previous blue-to-red HSV scale; precomputed to avoid per-pixel Color objects. */
private val nearFieldPaletteArgb: IntArray by lazy {
    IntArray(1024) { i ->
        val n = i / 1023f
        val hue = 240f * (1f - n)
        val value = (0.20f + 0.80f * kotlin.math.sqrt(n.toDouble()).toFloat()).coerceIn(0f, 1f)
        android.graphics.Color.HSVToColor(floatArrayOf(hue, 0.92f, value))
    }
}

private data class LoadedMaa(
    val name: String?,
    val model: MaaModel,
    val rawText: String,
    val sourcePathHint: String?
)
private data class MaaFolderFile(val name: String, val uri: Uri)
private data class BuiltInMaaEntry(val path: String, val title: String, val frequencyMHz: Double?, val category: String)

@Composable
fun YagiMaaTab(injectedModel: MaaModel? = null) {
    val context = LocalContext.current
    var model by remember { mutableStateOf<MaaModel?>(null) }
    var fileName by remember { mutableStateOf<String?>(null) }
    var rawMaaText by remember { mutableStateOf<String?>(null) }
    // Full archive/document path is kept as semantic context for corpus-assisted MAA interpretation.
    var maaSourcePath by remember { mutableStateOf<String?>(null) }
    var currentMaaUri by remember { mutableStateOf<Uri?>(null) }
    var maaFolderUri by remember { mutableStateOf<Uri?>(null) }
    var maaFolderFiles by remember { mutableStateOf<List<MaaFolderFile>>(emptyList()) }
    var pendingMaaNavigation by remember { mutableStateOf(0) }
    var libraryExpanded by remember { mutableStateOf(false) }
    var librarySearch by remember { mutableStateOf("") }
    var libraryCategory by remember { mutableStateOf("ALL") }
    val builtInLibrary by remember {
        mutableStateOf(
            runCatching {
                context.assets.open("maa_library_index.tsv").bufferedReader(Charsets.UTF_8).useLines { lines ->
                    lines.mapNotNull { line ->
                        val p = line.split('\t')
                        if (p.size < 4) null else BuiltInMaaEntry(
                            path = p[0],
                            title = p[1],
                            frequencyMHz = p[2].toDoubleOrNull(),
                            category = p[3]
                        )
                    }.toList()
                }
            }.getOrDefault(emptyList())
        )
    }
    // Learn semantic category vocabulary from the curated 722-model archive at runtime.
    // This is presentation/classification assistance only; NEC-2 remains the physics engine.
    val corpusLearner = remember(builtInLibrary) {
        MaaCorpusLearner(
            builtInLibrary.map { MaaCorpusSeed(it.path, it.title, it.frequencyMHz, it.category) }
        )
    }
    var analysisFrequencyMHz by remember { mutableStateOf<Double?>(null) }
    var analysisFrequencyText by remember { mutableStateOf("") }
    var analysisFrequencyError by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Open an MMANA-GAL antenna description file (*.maa).") }
    var viewMode by remember { mutableStateOf(MaaViewMode.ISO) }
    // Keep the last ISO geometry camera so the NEC 3D radiation pattern can open from
    // exactly the same engineering view instead of forcing the user to rotate it by hand.
    var geometryIsoYawDeg by remember { mutableFloatStateOf(-28f) }
    var geometryIsoPitchDeg by remember { mutableFloatStateOf(22f) }
    var geometryExpanded by remember { mutableStateOf(false) }
    var patternMode by remember { mutableStateOf(MaaPatternMode.POLAR) }
    var cutView by remember { mutableStateOf(MaaCutView.PRINCIPAL_1) }
    var radiation3DExpanded by remember { mutableStateOf(false) }
    var cuts2DExpanded by remember { mutableStateOf(false) }
    var radiation3DPoints by remember { mutableStateOf<List<Pattern3DPoint>>(emptyList()) }
    var radiation3DStepDeg by remember { mutableStateOf(5.0) }
    var radiation3DRunning by remember { mutableStateOf(false) }
    var radiation3DProgress by remember { mutableStateOf(0) }
    var radiation3DError by remember { mutableStateOf<String?>(null) }
    val solverScope = rememberCoroutineScope()
    var fullNecResult by remember { mutableStateOf<OpenNecFull.Result?>(null) }
    var fullNecRunning by remember { mutableStateOf(false) }
    var fullNecError by remember { mutableStateOf<String?>(null) }
    var smithSweepPoints by remember { mutableStateOf<List<OpenNecFull.SweepPoint>>(emptyList()) }
    var smithSweepRunning by remember { mutableStateOf(false) }
    var smithSweepProgress by remember { mutableStateOf(0) }
    var smithSweepError by remember { mutableStateOf<String?>(null) }
    var smithSweepCancelToken by remember { mutableStateOf<AtomicBoolean?>(null) }
    var noiseSweepPoints by remember { mutableStateOf<List<AntennaNoisePoint>>(emptyList()) }
    var noiseSweepRunning by remember { mutableStateOf(false) }
    var noiseSweepProgress by remember { mutableStateOf(0) }
    var noiseSweepError by remember { mutableStateOf<String?>(null) }
    var diagnosticsReport by remember { mutableStateOf<Nec2Diagnostics.Report?>(null) }
    var diagnosticsExpanded by remember { mutableStateOf(false) }
    var convergenceReport by remember { mutableStateOf<Nec2Diagnostics.ConvergenceReport?>(null) }
    var convergenceExpanded by remember { mutableStateOf(false) }
    var convergenceRunning by remember { mutableStateOf(false) }
    var convergenceProgress by remember { mutableStateOf("") }
    var convergenceError by remember { mutableStateOf<String?>(null) }
    var segMode by remember { mutableStateOf(Nec2Core.SegmentationMode.AUTO) }
    var manualSegPerLambdaText by remember { mutableStateOf("36") }
    var maxSegmentsText by remember { mutableStateOf("480") }
    var fieldPlane by remember { mutableStateOf(NearFieldEngine.Plane.XZ) }
    var fieldDisplay by remember { mutableStateOf(MaaFieldDisplay.H_DB) }
    var fieldDetail by remember { mutableStateOf(MaaFieldDetail.HIGH) }
    var fieldGridText by remember { mutableStateOf("71") }
    var fieldRangeDbText by remember { mutableStateOf("60") }
    var fieldResult by remember { mutableStateOf<NearFieldEngine.Grid?>(null) }
    var fieldRunning by remember { mutableStateOf(false) }
    var fieldProgress by remember { mutableStateOf(0) }
    var fieldError by remember { mutableStateOf<String?>(null) }
    var fieldCancelToken by remember { mutableStateOf<AtomicBoolean?>(null) }
    var fieldVectorMode by remember { mutableStateOf(false) }
    var fieldCleanView by remember { mutableStateOf(false) }
    var phaseViewEnabled by remember { mutableStateOf(false) }
    var phaseAnimationRunning by remember { mutableStateOf(false) }
    var phaseAnimationDeg by remember { mutableFloatStateOf(0f) }
    var phaseAnimationSpeed by remember { mutableFloatStateOf(1f) }

    LaunchedEffect(model) {
        // Every newly loaded MAA model starts from the same canonical ISO camera.
        geometryIsoYawDeg = -28f
        geometryIsoPitchDeg = 22f
    }

    // One NEC solution contains complex phasors. Animation only rotates their common time phase;
    // it never re-runs NEC and therefore cannot change input impedance or the solved current distribution.
    LaunchedEffect(phaseAnimationRunning, phaseAnimationSpeed) {
        while (phaseAnimationRunning) {
            delay(33L)
            phaseAnimationDeg = (phaseAnimationDeg + 3.0f * phaseAnimationSpeed) % 360.0f
        }
    }

    fun fullConfig(): Nec2Core.SegmentationConfig = Nec2Core.SegmentationConfig(
        mode = segMode,
        segmentsPerWavelength = (manualSegPerLambdaText.toIntOrNull() ?: 36).coerceIn(8, 100),
        maxSegments = (maxSegmentsText.toIntOrNull() ?: 480).coerceIn(24, 600)
    )

    fun invalidateFullImpedance() {
        smithSweepCancelToken?.set(true)
        smithSweepCancelToken = null
        smithSweepRunning = false
        smithSweepPoints = emptyList()
        smithSweepProgress = 0
        smithSweepError = null
        noiseSweepPoints = emptyList()
        noiseSweepRunning = false
        noiseSweepProgress = 0
        noiseSweepError = null
        fullNecResult = null
        fullNecError = null
        diagnosticsReport = null
        diagnosticsExpanded = false
        geometryExpanded = false
        radiation3DExpanded = false
        cuts2DExpanded = false
        radiation3DPoints = emptyList()
        radiation3DRunning = false
        radiation3DProgress = 0
        radiation3DError = null
        convergenceReport = null
        convergenceExpanded = false
        convergenceProgress = ""
        convergenceError = null
        fieldResult = null
        fieldError = null
    }

    fun resetAnalysisResults() {
        phaseAnimationRunning = false
        phaseViewEnabled = false
        fieldVectorMode = false
        invalidateFullImpedance()
    }

    fun startRadiation3D(target: MaaModel, solved: OpenNecFull.Result) {
        if (radiation3DRunning) return
        radiation3DRunning = true
        radiation3DProgress = 0
        radiation3DError = null
        radiation3DPoints = emptyList()
        solverScope.launch {
            val outcome = runCatching {
                withContext(Dispatchers.Default) {
                    OpenNecPattern.calculate3D(target, solved, thetaStepDeg = radiation3DStepDeg, phiStepDeg = radiation3DStepDeg) { done, total ->
                        solverScope.launch {
                            radiation3DProgress = if (total > 0) ((100.0 * done / total).toInt()).coerceIn(0, 100) else 0
                        }
                    }
                }
            }
            outcome.onSuccess { radiation3DPoints = it }
                .onFailure { radiation3DError = it.message ?: "3D pattern build error" }
            if (outcome.isSuccess) radiation3DProgress = 100
            radiation3DRunning = false
        }
    }

    fun parseAnalysisFrequency(text: String): Double? =
        text.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it.isFinite() && it > 0.0 }

    fun startFullImpedance(target: MaaModel) {
        if (!OpenNecFull.isAvailable || fullNecRunning || convergenceRunning || smithSweepRunning) return
        smithSweepCancelToken?.set(true)
        smithSweepCancelToken = null
        smithSweepPoints = emptyList()
        smithSweepProgress = 0
        smithSweepError = null
        radiation3DPoints = emptyList()
        radiation3DProgress = 0
        radiation3DError = null
        radiation3DRunning = false
        fullNecRunning = true
        fullNecError = null
        fullNecResult = null
        val config = fullConfig()
        solverScope.launch {
            val outcome = runCatching {
                withContext(Dispatchers.Default) { OpenNecFull.solveModel(target, config) }
            }
            outcome.onSuccess {
                fullNecResult = it
                fieldResult = null
                fieldError = null
            }
                .onFailure { fullNecError = it.message ?: "NEC-2 FULL error" }
            fullNecRunning = false
        }
    }

    fun startSmithSweep(target: MaaModel) {
        val centreResult = fullNecResult ?: return
        if (!OpenNecFull.isAvailable || fullNecRunning || convergenceRunning || smithSweepRunning) return

        val centreMHz = target.frequencyMHz
        if (!centreMHz.isFinite() || centreMHz <= 0.0) {
            smithSweepError = "Invalid center frequency."
            return
        }

        val config = fullConfig()
        val token = AtomicBoolean(false)
        smithSweepCancelToken?.set(true)
        smithSweepCancelToken = token
        smithSweepRunning = true
        smithSweepPoints = emptyList()
        smithSweepProgress = 0
        smithSweepError = null

        solverScope.launch {
            val prepared = runCatching {
                withContext(Dispatchers.Default) { OpenNecFull.prepareSweep(target, config) }
            }
            val plan = prepared.getOrElse { err ->
                smithSweepError = err.message ?: "Failed to prepare NEC-2 sweep."
                smithSweepRunning = false
                smithSweepCancelToken = null
                return@launch
            }

            val count = 21
            val frequencies = List(count) { i ->
                val k = -0.05 + 0.10 * i.toDouble() / (count - 1).toDouble()
                centreMHz * (1.0 + k)
            }
            val centreIndex = count / 2
            val collected = ArrayList<OpenNecFull.SweepPoint>(count)

            for ((index, frequencyMHz) in frequencies.withIndex()) {
                if (token.get()) break
                val point = if (
                    index == centreIndex &&
                    kotlin.math.abs(centreResult.frequencyMHz - centreMHz) <= centreMHz * 1e-9 &&
                    centreResult.inputs.size == plan.baseDeck.sourceCount
                ) {
                    OpenNecFull.SweepPoint(centreResult.frequencyMHz, centreResult.inputs)
                } else {
                    val outcome = runCatching {
                        withContext(Dispatchers.Default) { OpenNecFull.solveSweepPoint(plan, frequencyMHz) }
                    }
                    val solved = outcome.getOrNull()
                    if (solved == null) {
                        val err = outcome.exceptionOrNull()
                        smithSweepError = "Sweep ${"%.6g".format(frequencyMHz)} MHz: ${err?.message ?: "NEC-2 error"}"
                        break
                    }
                    solved
                }
                if (token.get()) break
                collected += point
                smithSweepPoints = collected.toList()
                smithSweepProgress = ((index + 1) * 100 / count).coerceIn(0, 100)
            }

            val cancelled = token.get()
            smithSweepRunning = false
            smithSweepCancelToken = null
            if (cancelled) {
                smithSweepError = "Sweep stopped."
            } else if (smithSweepError == null && smithSweepPoints.size == count) {
                smithSweepProgress = 100
            }
        }
    }

    fun startNoiseSweep(target: MaaModel) {
        val centreResult = fullNecResult ?: return
        if (!OpenNecFull.isAvailable || fullNecRunning || convergenceRunning || smithSweepRunning || noiseSweepRunning) return
        val centreMHz = target.frequencyMHz
        if (!centreMHz.isFinite() || centreMHz <= 0.0) {
            noiseSweepError = "Invalid center frequency."
            return
        }
        val config = fullConfig()
        noiseSweepRunning = true
        noiseSweepProgress = 0
        noiseSweepError = null
        noiseSweepPoints = emptyList()
        solverScope.launch {
            val count = 9
            val frequencies = List(count) { i ->
                val k = -0.05 + 0.10 * i.toDouble() / (count - 1).toDouble()
                centreMHz * (1.0 + k)
            }
            val centreIndex = count / 2
            val collected = ArrayList<AntennaNoisePoint>(count)
            for ((index, fMHz) in frequencies.withIndex()) {
                val solved: OpenNecFull.Result
                if (index == centreIndex && kotlin.math.abs(centreResult.frequencyMHz-centreMHz) <= centreMHz*1e-9) {
                    solved = centreResult
                } else {
                    val outcome = runCatching {
                        withContext(Dispatchers.Default) { OpenNecFull.solveModel(target.copy(frequencyMHz=fMHz), config) }
                    }
                    val value = outcome.getOrNull()
                    if (value == null) {
                        val err = outcome.exceptionOrNull()
                        noiseSweepError = "Noise sweep ${"%.6g".format(fMHz)} MHz: ${err?.message ?: "NEC-2 error"}"
                        break
                    }
                    solved = value
                }
                val estimated = runCatching { withContext(Dispatchers.Default) { antennaNoiseFromNec(solved) } }
                val np = estimated.getOrNull()
                if (np == null) {
                    val err = estimated.exceptionOrNull()
                    noiseSweepError = "Noise model ${"%.6g".format(fMHz)} MHz: ${err?.message ?: "calculation error"}"
                    break
                }
                collected += np
                noiseSweepPoints = collected.toList()
                noiseSweepProgress = ((index+1)*100/count).coerceIn(0,100)
            }
            noiseSweepRunning = false
            if (noiseSweepError == null && noiseSweepPoints.size == count) noiseSweepProgress = 100
        }
    }

    fun readMaaUri(uri: Uri): Result<LoadedMaa> = runCatching {
        val name: String? = context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }

        val bytes: ByteArray = context.contentResolver.openInputStream(uri)?.use { input ->
            input.readBytes()
        } ?: error("Failed to open file.")

        val text: String = decodeMaaText(bytes)
        // SAF document IDs often preserve a useful relative folder path (for example
        // ANT/HF multibands/Short/...).  Use it when available so the corpus learner can
        // understand feed/short/match variants instead of seeing only the bare filename.
        val documentPathHint = runCatching {
            DocumentsContract.getDocumentId(uri).substringAfter(':').replace('\\', '/')
        }.getOrNull()?.takeIf { it.isNotBlank() }
        val semanticPathHint = documentPathHint ?: name
        val parsed: MaaModel = BufferedReader(StringReader(text)).use { reader ->
            MaaParser.parse(reader, semanticPathHint)
        }
        LoadedMaa(name, parsed, text, semanticPathHint)
    }

    fun applyLoadedMaa(uri: Uri, loaded: LoadedMaa, keepFolderNavigation: Boolean) {
        val name: String? = loaded.name
        val parsed: MaaModel = loaded.model
        model = parsed
        fileName = name
        rawMaaText = loaded.rawText
        maaSourcePath = loaded.sourcePathHint
        currentMaaUri = uri
        if (!keepFolderNavigation) {
            maaFolderUri = null
            maaFolderFiles = emptyList()
            pendingMaaNavigation = 0
        }
        analysisFrequencyMHz = parsed.frequencyMHz
        analysisFrequencyText = "%.6g".format(parsed.frequencyMHz)
        analysisFrequencyError = null
        fullNecResult = null
        fullNecError = null
        fullNecRunning = false
        diagnosticsReport = null
        diagnosticsExpanded = false
        convergenceReport = null
        convergenceExpanded = false
        convergenceRunning = false
        convergenceProgress = ""
        convergenceError = null
        fieldPlane = NearFieldEngine.Plane.XZ
        fieldResult = null
        fieldProgress = 0
        fieldError = null
        status = "Done: ${parsed.wires.size} wires, ${parsed.elementStationsM.size} geometric positions. ${parsed.antennaKind}"
        startFullImpedance(parsed)
    }

    fun loadMaaUri(uri: Uri, keepFolderNavigation: Boolean) {
        readMaaUri(uri).onSuccess { loaded ->
            applyLoadedMaa(uri, loaded, keepFolderNavigation)
        }.onFailure { error ->
            status = "MAA error: ${error.message ?: "unknown error"}"
        }
    }

    fun loadBuiltInMaa(entry: BuiltInMaaEntry) {
        runCatching {
            val bytes = context.assets.open("maa_library/${entry.path}").use { it.readBytes() }
            val text = decodeMaaText(bytes)
            val parsed = BufferedReader(StringReader(text)).use { reader -> MaaParser.parse(reader, entry.path) }
            parsed to text
        }.onSuccess { (parsed, text) ->
            model = parsed
            fileName = entry.path.substringAfterLast('/')
            rawMaaText = text
            maaSourcePath = entry.path
            currentMaaUri = null
            maaFolderUri = null
            maaFolderFiles = emptyList()
            pendingMaaNavigation = 0
            analysisFrequencyMHz = parsed.frequencyMHz
            analysisFrequencyText = "%.6g".format(parsed.frequencyMHz)
            analysisFrequencyError = null
            resetAnalysisResults()
            fieldPlane = NearFieldEngine.Plane.XZ
            status = "Library: ${entry.category} / ${entry.title} • ${parsed.wires.size} wires. NEC-2 FULL started."
            libraryExpanded = false
            startFullImpedance(parsed)
        }.onFailure { err ->
            status = "Library MAA error: ${err.message ?: "unknown error"}"
        }
    }

    fun listMaaFiles(treeUri: Uri): Result<List<MaaFolderFile>> = runCatching {
        val resolver = context.contentResolver
        val treeDocumentId = DocumentsContract.getTreeDocumentId(treeUri)
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeDocumentId)
        val files = ArrayList<MaaFolderFile>()
        resolver.query(
            childrenUri,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            ),
            null,
            null,
            null
        )?.use { cursor ->
            val idCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
            while (cursor.moveToNext()) {
                val docId = if (idCol >= 0) cursor.getString(idCol) else null
                val name = if (nameCol >= 0) cursor.getString(nameCol) else null
                val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                if (!docId.isNullOrBlank() && !name.isNullOrBlank() &&
                    mime != DocumentsContract.Document.MIME_TYPE_DIR &&
                    name.endsWith(".maa", ignoreCase = true)
                ) {
                    files += MaaFolderFile(name, DocumentsContract.buildDocumentUriUsingTree(treeUri, docId))
                }
            }
        }
        files.sortedBy { it.name.lowercase() }
    }

    fun navigateMaaFiles(files: List<MaaFolderFile>, direction: Int) {
        if (files.isEmpty()) {
            status = "No *.maa files in the selected folder."
            return
        }
        val currentIndex = files.indexOfFirst { entry ->
            entry.uri == currentMaaUri || entry.name.equals(fileName, ignoreCase = true)
        }
        val targetIndex = if (currentIndex >= 0) {
            (currentIndex + direction + files.size) % files.size
        } else if (direction >= 0) {
            0
        } else {
            files.lastIndex
        }
        loadMaaUri(files[targetIndex].uri, keepFolderNavigation = true)
    }

    val folderPicker = rememberLauncherForActivityResult<Uri?, Uri?>(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        val direction = pendingMaaNavigation
        pendingMaaNavigation = 0
        if (treeUri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            listMaaFiles(treeUri).onSuccess { files ->
                maaFolderUri = treeUri
                maaFolderFiles = files
                if (direction != 0) navigateMaaFiles(files, direction)
            }.onFailure { error ->
                status = "Failed to read MAA folder: ${error.message ?: "access denied"}"
            }
        }
    }

    fun requestMaaNavigation(direction: Int) {
        if (direction == 0 || model == null) return
        val files = maaFolderFiles
        val currentKnown = files.any { entry ->
            entry.uri == currentMaaUri || entry.name.equals(fileName, ignoreCase = true)
        }
        if (maaFolderUri != null && files.isNotEmpty() && currentKnown) {
            navigateMaaFiles(files, direction)
        } else {
            pendingMaaNavigation = direction
            folderPicker.launch(null)
        }
    }

    val picker = rememberLauncherForActivityResult<Array<String>, Uri?>(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            loadMaaUri(uri, keepFolderNavigation = false)
        }
    }

    val saveCurrentMaa = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            val textToSave = rawMaaText ?: model?.let { MaaTextWriter.toText(it) }.orEmpty()
            if (textToSave.isNotBlank()) {
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(textToSave) }
                }.onFailure { err ->
                    status = "MAA save error: ${err.message ?: "unknown error"}"
                }.onSuccess {
                    status = "MAA saved successfully."
                }
            }
        }
    }

    LaunchedEffect(injectedModel) {
        val generated = injectedModel ?: return@LaunchedEffect
        resetAnalysisResults()
        model = generated
        fileName = "Yagi Designer — in memory"
        rawMaaText = MaaTextWriter.toText(generated)
        maaSourcePath = generated.fileNameHint
        currentMaaUri = null
        maaFolderUri = null
        maaFolderFiles = emptyList()
        pendingMaaNavigation = 0
        analysisFrequencyMHz = generated.frequencyMHz
        analysisFrequencyText = "%.6g".format(generated.frequencyMHz)
        analysisFrequencyError = null
        fieldPlane = NearFieldEngine.Plane.XZ
        geometryExpanded = true
        cuts2DExpanded = true
        status = "Yagi Designer geometry received: ${generated.wires.size} elements. NEC-2 FULL calculation started automatically."
        startFullImpedance(generated)
    }

    Text("MAA Antenna Viewer", style = MaterialTheme.typography.titleLarge)

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button(
            modifier = Modifier.weight(0.24f),
            onClick = { requestMaaNavigation(-1) },
            enabled = model != null && !fullNecRunning && !fieldRunning && !convergenceRunning && !smithSweepRunning
        ) { Text("<") }
        Button(
            modifier = Modifier.weight(1f),
            onClick = { picker.launch(arrayOf("*/*")) },
            enabled = !fullNecRunning && !fieldRunning && !convergenceRunning && !smithSweepRunning
        ) { AutoFitButtonText("Open MAA") }
        Button(
            modifier = Modifier.weight(0.24f),
            onClick = { requestMaaNavigation(1) },
            enabled = model != null && !fullNecRunning && !fieldRunning && !convergenceRunning && !smithSweepRunning
        ) { Text(">") }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button(
            onClick = { libraryExpanded = !libraryExpanded },
            modifier = Modifier.weight(1f),
            enabled = !fullNecRunning && !fieldRunning && !convergenceRunning && !smithSweepRunning
        ) { AutoFitButtonText(if (libraryExpanded) "ANTENNA LIBRARY ✓" else "ANTENNA LIBRARY (${builtInLibrary.size})", maxLines = 2, minFontSize = 9.sp) }
    }
    if (libraryExpanded) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = librarySearch,
                    onValueChange = { librarySearch = it },
                    label = { Text("Search antenna") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                val categories = listOf("ALL") + builtInLibrary.map { it.category }.distinct().sorted()
                val visibleCats = categories.chunked(4)
                visibleCats.forEach { group ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        group.forEach { cat ->
                            Button(
                                onClick = { libraryCategory = cat },
                                modifier = Modifier.weight(1f)
                            ) { AutoFitButtonText(if (libraryCategory == cat) "$cat ✓" else cat, maxLines = 2, minFontSize = 8.sp) }
                        }
                    }
                }
                val q = librarySearch.trim().lowercase()
                val filtered = builtInLibrary.filter { e ->
                    (libraryCategory == "ALL" || e.category == libraryCategory) &&
                        (q.isEmpty() || e.title.lowercase().contains(q) || e.path.lowercase().contains(q) || (e.frequencyMHz?.toString()?.contains(q) == true))
                }
                Text("${filtered.size} antenna(s) found", style = MaterialTheme.typography.bodySmall)
                filtered.take(30).forEach { e ->
                    Button(
                        onClick = { loadBuiltInMaa(e) },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !fullNecRunning && !fieldRunning && !convergenceRunning && !smithSweepRunning
                    ) {
                        val f = e.frequencyMHz?.let { " • ${"%.6g".format(it)} MHz" } ?: ""
                        AutoFitButtonText("${e.title}$f", maxLines = 2, maxFontSize = 15.sp, minFontSize = 8.sp)
                    }
                }
                if (filtered.size > 30) Text("Showing first 30. Refine search or category.", style = MaterialTheme.typography.bodySmall)
                Text("OPEN MAA remains available for external *.maa files.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    if (model != null) {
        Button(
            onClick = {
                val suggested = (fileName?.takeIf { it.endsWith(".maa", ignoreCase = true) }
                    ?: "Yagi_${model?.wires?.size ?: 0}el_${"%.3f".format(model?.frequencyMHz ?: 0.0)}MHz.maa")
                    .replace(" — in memory", "")
                saveCurrentMaa.launch(suggested)
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !fullNecRunning && !fieldRunning && !convergenceRunning && !smithSweepRunning
        ) { AutoFitButtonText("SAVE CURRENT MAA", maxLines = 2) }
    }
    Text(status, style = MaterialTheme.typography.bodyMedium)

    model?.let { sourceModel ->
        val activeFrequencyMHz = analysisFrequencyMHz?.takeIf { it.isFinite() && it > 0.0 } ?: sourceModel.frequencyMHz
        val m = remember(sourceModel, activeFrequencyMHz) {
            if (abs(activeFrequencyMHz - sourceModel.frequencyMHz) < 1e-12) sourceModel
            else sourceModel.copy(frequencyMHz = activeFrequencyMHz)
        }
        MaaInfoCard(fileName, m, sourceModel.frequencyMHz, corpusLearner.profile(m, maaSourcePath))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(
                onClick = {
                    val open = !geometryExpanded
                    geometryExpanded = open
                    if (open) radiation3DExpanded = false
                },
                modifier = Modifier.weight(1f)
            ) { Text(if (geometryExpanded) "3D MODEL ✓" else "3D MODEL", maxLines = 1) }
            Button(
                onClick = {
                    val open = !radiation3DExpanded
                    radiation3DExpanded = open
                    if (open) {
                        geometryExpanded = false
                        val solved = fullNecResult
                        if (solved != null && radiation3DPoints.isEmpty() && !radiation3DRunning) {
                            startRadiation3D(m, solved)
                        }
                    }
                },
                modifier = Modifier.weight(1f),
                enabled = !fullNecRunning && !convergenceRunning && !smithSweepRunning
            ) { Text(if (radiation3DExpanded) "3D PATTERN ✓" else "3D PATTERN", maxLines = 1) }
        }

        if (geometryExpanded) {
            Card(modifier = Modifier.fillMaxWidth()) {
Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("3D antenna model", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = { viewMode = MaaViewMode.ISO }, modifier = Modifier.weight(1f), enabled = viewMode != MaaViewMode.ISO) { Text("ISO") }
                        Button(onClick = { viewMode = MaaViewMode.SIDE }, modifier = Modifier.weight(1f), enabled = viewMode != MaaViewMode.SIDE) { Text("SIDE") }
                        Button(onClick = { viewMode = MaaViewMode.FRONT }, modifier = Modifier.weight(1f), enabled = viewMode != MaaViewMode.FRONT) { Text("FRONT") }
                    }
                    MaaGeometryCanvas(m, viewMode) { yawDeg, pitchDeg ->
                        geometryIsoYawDeg = yawDeg
                        geometryIsoPitchDeg = pitchDeg
                    }
                }
            }
        }

        val manualDensity = (manualSegPerLambdaText.toIntOrNull() ?: 36).coerceIn(8, 100)
        val maxSegments = (maxSegmentsText.toIntOrNull() ?: 480).coerceIn(maxOf(24, m.wires.size), 600)
        val segConfig = remember(m, segMode, manualDensity, maxSegments) {
            Nec2Core.SegmentationConfig(segMode, manualDensity, maxSegments)
        }
        val segPlan = remember(m, segConfig) { runCatching { Nec2Core.planSegmentation(m, segConfig) }.getOrNull() }
        val visualizationSegments = fullNecResult?.nearFieldSegments.orEmpty()
        val visualizationEngineLabel = "NEC-2 FULL / OpenNEC"
        val fullPattern = remember(m, fullNecResult, radiation3DPoints) {
            when {
                radiation3DPoints.isNotEmpty() ->
                    runCatching { OpenNecPattern.calculateFrom3D(m, radiation3DPoints) }.getOrNull()
                else -> fullNecResult?.let { solved ->
                    runCatching { OpenNecPattern.calculate(m, solved) }.getOrNull()
                }
            }
        }
        val preview = fullPattern?.let { if (cutView == MaaCutView.PRINCIPAL_1) it.previewTop else it.previewSide }


        if (radiation3DExpanded) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = {
                        if (radiation3DStepDeg != 5.0) {
                            radiation3DStepDeg = 5.0
                            radiation3DPoints = emptyList()
                            radiation3DError = null
                            fullNecResult?.let { startRadiation3D(m, it) }
                        }
                    },
                    modifier = Modifier.weight(1f),
                    enabled = !radiation3DRunning && radiation3DStepDeg != 5.0
                ) { Text("NORMAL 5°", maxLines = 1) }
                Button(
                    onClick = {
                        if (radiation3DStepDeg != 2.5) {
                            radiation3DStepDeg = 2.5
                            radiation3DPoints = emptyList()
                            radiation3DError = null
                            fullNecResult?.let { startRadiation3D(m, it) }
                        }
                    },
                    modifier = Modifier.weight(1f),
                    enabled = !radiation3DRunning && radiation3DStepDeg != 2.5
                ) { Text("PRECISE 2.5°", maxLines = 1) }
            }
            when {
                fullNecResult == null -> {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            "First run NEC-2 FULL. After calculation press 3D PATTERN — the spatial pattern will be built from the same complex currents.",
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                radiation3DRunning -> {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text("Building 3D pattern ${format3DStep(radiation3DStepDeg)}°… ${radiation3DProgress}%", style = MaterialTheme.typography.bodyMedium)
                            LinearProgressIndicator(progress = { radiation3DProgress / 100f }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
                radiation3DError != null -> {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text("3D pattern: ${radiation3DError}", style = MaterialTheme.typography.bodyMedium)
                            Button(onClick = { fullNecResult?.let { startRadiation3D(m, it) } }) { Text("RETRY") }
                        }
                    }
                }
                radiation3DPoints.isNotEmpty() -> {
                    val peak3D = remember(radiation3DPoints) { radiation3DPoints.maxByOrNull { it.db } }
                    val dMax3D = remember(radiation3DPoints) { estimatePattern3DDirectivityDbi(radiation3DPoints) }
                    Radiation3DCard(
                        title = "NEC-2 FULL 3D radiation pattern",
                        points = radiation3DPoints,
                        subtitle = if (dMax3D != null)
                            "Spatial pattern from NEC-2 FULL complex currents. θ/φ grid = ${format3DStep(radiation3DStepDeg)}°. The internal shape is stored normalized; the absolute scale is referenced to Dmax calculated by integrating the 3D pattern."
                        else
                            "Spatial pattern from NEC-2 FULL complex currents. θ/φ grid = ${format3DStep(radiation3DStepDeg)}°. Normalized scale.",
                        initialRadiusScale = Radius3DScale.DB,
                        absolutePeakDbi = dMax3D,
                        absolutePeakLabel = "Dmax",
                        peakThetaDeg = peak3D?.thetaDeg,
                        peakPhiDeg = peak3D?.phiDeg,
                        geometryViewYawDeg = when (viewMode) {
                            MaaViewMode.ISO -> geometryIsoYawDeg
                            MaaViewMode.SIDE -> 0f
                            MaaViewMode.FRONT -> -90f
                        },
                        geometryViewPitchDeg = when (viewMode) {
                            MaaViewMode.ISO -> geometryIsoPitchDeg
                            MaaViewMode.SIDE, MaaViewMode.FRONT -> 0f
                        },
                        // 3D PATTERN uses the same physical world X/Y/Z basis as 3D MODEL.
                        // No display-only azimuth rotation is applied: phi=0 is +X, phi=90 is +Y.
                        patternAzimuthDisplayOffsetDeg = 0.0
                    )
                    Button(
                        onClick = { cuts2DExpanded = !cuts2DExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (cuts2DExpanded) "2D CUTS ✓" else "2D CUTS") }
                    if (cuts2DExpanded) {
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Radiation-pattern cuts", style = MaterialTheme.typography.bodyMedium)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    val p1 = fullPattern?.principalPlane1Label ?: "P1"
                                    val p2 = fullPattern?.principalPlane2Label ?: "P2"
                                    Button(onClick = { cutView = MaaCutView.PRINCIPAL_1 }, modifier = Modifier.weight(1f), enabled = cutView != MaaCutView.PRINCIPAL_1) { Text(p1, maxLines = 1) }
                                    Button(onClick = { cutView = MaaCutView.PRINCIPAL_2 }, modifier = Modifier.weight(1f), enabled = cutView != MaaCutView.PRINCIPAL_2) { Text(p2, maxLines = 1) }
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button(onClick = { patternMode = MaaPatternMode.POLAR }, modifier = Modifier.weight(1f), enabled = patternMode != MaaPatternMode.POLAR) { Text("POLAR") }
                                    Button(onClick = { patternMode = MaaPatternMode.RECT }, modifier = Modifier.weight(1f), enabled = patternMode != MaaPatternMode.RECT) { Text("dB / ANGLE") }
                                }
                                if (preview == null || preview.points.isEmpty()) {
                                    Text("No 2D pattern data.")
                                } else {
                                    if (patternMode == MaaPatternMode.POLAR) MaaPolarPattern(preview) else MaaRectPattern(preview)
                                    val planeLabel = fullPattern?.let {
                                        if (cutView == MaaCutView.PRINCIPAL_1) it.principalPlane1Label else it.principalPlane2Label
                                    } ?: if (cutView == MaaCutView.PRINCIPAL_1) "P1" else "P2"
                                    MaaPatternEngineeringInfo(m, preview, planeLabel)
                                }
                            }
                        }
                    }
                }
                else -> {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Text("Preparing 3D pattern…", modifier = Modifier.padding(12.dp))
                    }
                }
            }
        }
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("MAA / NEC-2 analysis", style = MaterialTheme.typography.titleMedium)

                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Analysis frequency", style = MaterialTheme.typography.titleSmall)
                        OutlinedTextField(
                            value = analysisFrequencyText,
                            onValueChange = { value ->
                                analysisFrequencyText = value.filter { it.isDigit() || it == '.' || it == ',' }.take(14)
                                analysisFrequencyError = null
                            },
                            label = { Text("Frequency, MHz") },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !fullNecRunning && !fieldRunning && !convergenceRunning && !smithSweepRunning,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            isError = analysisFrequencyError != null,
                            supportingText = analysisFrequencyError?.let { err -> { Text(err) } }
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = {
                                    val f = sourceModel.frequencyMHz
                                    analysisFrequencyText = "%.6g".format(f)
                                    analysisFrequencyMHz = f
                                    analysisFrequencyError = null
                                    resetAnalysisResults()
                                    startFullImpedance(sourceModel)
                                },
                                modifier = Modifier.weight(1f),
                                enabled = !fullNecRunning && !fieldRunning && !convergenceRunning && !smithSweepRunning
                            ) { Text("FROM MAA") }
                            Button(
                                onClick = {
                                    val f = parseAnalysisFrequency(analysisFrequencyText)
                                    if (f == null) {
                                        analysisFrequencyError = "Enter a frequency greater than 0 MHz"
                                    } else {
                                        analysisFrequencyMHz = f
                                        analysisFrequencyText = "%.6g".format(f)
                                        analysisFrequencyError = null
                                        resetAnalysisResults()
                                        startFullImpedance(sourceModel.copy(frequencyMHz = f))
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                enabled = !fullNecRunning && !fieldRunning && !convergenceRunning && !smithSweepRunning
                            ) { Text("APPLY") }
                        }
                    }
                }

                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("MAIN ENGINE — NEC-2 FULL", style = MaterialTheme.typography.titleSmall)
                        if (!OpenNecFull.isAvailable) {
                            Text("FULL is unavailable in this build: ${OpenNecFull.availabilityMessage ?: "native library is not loaded"}", style = MaterialTheme.typography.bodySmall)
                        } else if (fullNecRunning) {
                            Text("NEC-2 FULL: Zin + complex segment currents…", style = MaterialTheme.typography.bodyMedium)
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        } else {
                            Button(
                                onClick = { startFullImpedance(m) },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !convergenceRunning && !smithSweepRunning
                            ) { Text(if (fullNecResult == null) "CALCULATE NEC-2 FULL" else "RECALCULATE NEC-2 FULL") }
                        }
                        fullNecError?.let { Text("NEC-2 FULL: $it", style = MaterialTheme.typography.bodySmall) }
                        fullNecResult?.let { full ->
                            val r0 = (m.referenceImpedanceOhms ?: 50.0).coerceAtLeast(1.0)
                            val isStack = m.antennaKind.contains("stack", ignoreCase = true) && full.inputs.size > 1
                            val z = if (isStack) {
                                OpenNecFull.InputImpedance(
                                    tag = full.inputs.first().tag,
                                    segment = full.inputs.first().segment,
                                    rOhm = full.inputs.map { it.rOhm }.average(),
                                    xOhm = full.inputs.map { it.xOhm }.average()
                                )
                            } else full.primary
                            val swr = z.swr(r0)
                            Text(if (isStack) "Active Zin / Yagi (mean) = ${z.formattedZ()}" else "Zin = ${z.formattedZ()}", style = MaterialTheme.typography.titleMedium)
                            Text("SWR to R0=${"%.0f".format(r0)} Ω = ${if (swr.isFinite()) "%.3f".format(swr) else "∞"}", style = MaterialTheme.typography.bodyMedium)
                            if (full.inputs.size > 1) {
                                full.inputs.forEachIndexed { index, zi ->
                                    Text(
                                        if (isStack) "Yagi ${index + 1} active Z: tag ${zi.tag}, seg ${zi.segment} • ${zi.formattedZ()}"
                                        else "Input ${index + 1}: tag ${zi.tag}, seg ${zi.segment} • ${zi.formattedZ()}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                Text(
                                    if (isStack) "All stack ports are solved simultaneously. Values above are NEC active impedances V/I with mutual coupling included; no power-divider impedance is invented."
                                    else "⚠ Multi-source/phased model: FULL remains the main solver, but interpret individual input Z values with regard to simultaneous excitation.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            full.warning?.let { Text("⚠ OpenNEC: $it", style = MaterialTheme.typography.bodySmall) }

                            AntennaSmithCard(
                                primary = z,
                                inputs = full.inputs,
                                z0Ohm = r0,
                                sweepPoints = smithSweepPoints,
                                sweepRunning = smithSweepRunning,
                                sweepProgress = smithSweepProgress,
                                sweepError = smithSweepError,
                                onStartSweep = { startSmithSweep(m) },
                                onCancelSweep = { smithSweepCancelToken?.set(true) }
                            )
                            AntennaNoiseTemperatureCard(
                                points = noiseSweepPoints,
                                running = noiseSweepRunning,
                                progress = noiseSweepProgress,
                                error = noiseSweepError,
                                onCalculate = { startNoiseSweep(m) }
                            )
                        }
                    }
                }

                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("NEC-2 FULL segmentation", style = MaterialTheme.typography.titleSmall)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = { segMode = Nec2Core.SegmentationMode.AUTO; invalidateFullImpedance() },
                                modifier = Modifier.weight(1f),
                                enabled = !fullNecRunning && !convergenceRunning && !smithSweepRunning && segMode != Nec2Core.SegmentationMode.AUTO
                            ) { Text("AUTO") }
                            Button(
                                onClick = { segMode = Nec2Core.SegmentationMode.MANUAL; invalidateFullImpedance() },
                                modifier = Modifier.weight(1f),
                                enabled = !fullNecRunning && !convergenceRunning && !smithSweepRunning && segMode != Nec2Core.SegmentationMode.MANUAL
                            ) { Text("MANUAL") }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(
                                value = if (segMode == Nec2Core.SegmentationMode.AUTO) (segPlan?.effectiveSegmentsPerWavelength?.toString() ?: "—") else manualSegPerLambdaText,
                                onValueChange = { v -> if (segMode == Nec2Core.SegmentationMode.MANUAL) { manualSegPerLambdaText = v.filter { it.isDigit() }.take(3); invalidateFullImpedance() } },
                                label = { Text("Seg./λ") },
                                modifier = Modifier.weight(1f),
                                enabled = !fullNecRunning && !convergenceRunning && !smithSweepRunning && segMode == Nec2Core.SegmentationMode.MANUAL,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = maxSegmentsText,
                                onValueChange = { v -> maxSegmentsText = v.filter { it.isDigit() }.take(3); invalidateFullImpedance() },
                                label = { Text("MAX N") },
                                modifier = Modifier.weight(1f),
                                enabled = !fullNecRunning && !convergenceRunning && !smithSweepRunning,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                        }
                        segPlan?.let { plan ->
                            Text(
                                "${plan.appliedSegments} seg. • ${plan.effectiveSegmentsPerWavelength}/λ • max Δ=${"%.4f".format(plan.longestSegmentM)} m" +
                                    if (plan.capApplied) " • MAX N" else "",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("NEC-2 DIAGNOSTICS AND CONVERGENCE", style = MaterialTheme.typography.titleSmall)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = {
                                    if (diagnosticsExpanded) {
                                        diagnosticsExpanded = false
                                    } else {
                                        if (diagnosticsReport == null) {
                                            diagnosticsReport = Nec2Diagnostics.analyze(m, segConfig, fullNecResult)
                                        }
                                        diagnosticsExpanded = true
                                        convergenceExpanded = false
                                        convergenceError = null
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                enabled = diagnosticsExpanded || (!fullNecRunning && !fieldRunning && !convergenceRunning && !smithSweepRunning)
                            ) { Text("DIAGNOSTICS") }
                            Button(
                                onClick = {
                                    if (convergenceExpanded) {
                                        convergenceExpanded = false
                                    } else {
                                        convergenceExpanded = true
                                        diagnosticsExpanded = false
                                        if (convergenceReport == null && !convergenceRunning) {
                                            convergenceRunning = true
                                            convergenceError = null
                                            convergenceProgress = "Preparing meshes…"
                                            solverScope.launch {
                                                val outcome = runCatching {
                                                    withContext(Dispatchers.Default) {
                                                        Nec2Diagnostics.runConvergence(m, segConfig) { done, total, message ->
                                                            solverScope.launch {
                                                                convergenceProgress = "${done.coerceIn(0,total)}/$total • $message"
                                                            }
                                                        }
                                                    }
                                                }
                                                outcome.onSuccess { report ->
                                                    convergenceReport = report
                                                    convergenceProgress = "Done"
                                                    diagnosticsReport = Nec2Diagnostics.analyze(m, segConfig, fullNecResult)
                                                }.onFailure { e ->
                                                    convergenceError = e.message ?: "Convergence-check error"
                                                    convergenceProgress = "Error"
                                                }
                                                convergenceRunning = false
                                            }
                                        }
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                enabled = convergenceExpanded || (OpenNecFull.isAvailable && !fullNecRunning && !fieldRunning && !smithSweepRunning)
                            ) { Text("CONVERGENCE") }
                        }

                        if (diagnosticsExpanded) diagnosticsReport?.let { report ->
                            val overall = when (report.overall) {
                                Nec2Diagnostics.Level.OK -> "✅ OK"
                                Nec2Diagnostics.Level.WARNING -> "⚠ CHECK"
                                Nec2Diagnostics.Level.ERROR -> "❌ ERROR"
                            }
                            Text("$overall • errors: ${report.errors} • warnings: ${report.warnings}", style = MaterialTheme.typography.bodyMedium)
                            report.checks.forEach { check ->
                                val icon = when (check.level) {
                                    Nec2Diagnostics.Level.OK -> "✅"
                                    Nec2Diagnostics.Level.WARNING -> "⚠"
                                    Nec2Diagnostics.Level.ERROR -> "❌"
                                }
                                Text("$icon ${check.title}: ${check.detail}", style = MaterialTheme.typography.bodySmall)
                            }
                        }

                        if (convergenceExpanded) {
                            if (convergenceRunning) {
                                Text("Convergence check: $convergenceProgress", style = MaterialTheme.typography.bodyMedium)
                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            }
                            convergenceError?.let { Text("Convergence: $it", style = MaterialTheme.typography.bodySmall) }
                            convergenceReport?.let { report ->
                            val statusText = when (report.level) {
                                Nec2Diagnostics.Level.OK -> "✅ CONVERGED"
                                Nec2Diagnostics.Level.WARNING -> "⚠ REVIEW NEEDED"
                                Nec2Diagnostics.Level.ERROR -> "❌ NOT CONVERGED"
                            }
                            Text(statusText, style = MaterialTheme.typography.titleSmall)
                            report.samples.forEachIndexed { index, sample ->
                                val swrText = if (sample.swr.isFinite()) "%.3f".format(sample.swr) else "∞"
                                Text(
                                    "${index + 1}) ${sample.densityPerLambda} seg./λ • N=${sample.segmentCount}${if (sample.capped) " MAX" else ""} • " +
                                        "Z=${"%.2f".format(sample.rOhm)} ${if (sample.xOhm >= 0) "+" else "−"} j${"%.2f".format(abs(sample.xOhm))} Ω • SWR=$swrText • " +
                                        "max P1=${"%.1f".format(sample.p1PeakDeg)}° P2=${"%.1f".format(sample.p2PeakDeg)}°",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    "   HPBW P1=${sample.p1HpbwDeg?.let { "%.1f°".format(it) } ?: "—"} • P2=${sample.p2HpbwDeg?.let { "%.1f°".format(it) } ?: "—"} • " +
                                        "F/B P1=${sample.p1FbDb?.let { "%.1f dB".format(it) } ?: "—"} • P2=${sample.p2FbDb?.let { "%.1f dB".format(it) } ?: "—"}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Text(
                                "Last two meshes: ΔR=${"%.2f".format(report.deltaRPercent)}% • ΔX=${"%.2f".format(report.deltaXOhm)} Ω • " +
                                    "Δ|Z|=${"%.2f".format(report.deltaZPercent)}% • max pattern shift=${"%.2f".format(report.maxPeakShiftDeg)}° • pattern RMS=${"%.2f".format(report.maxPatternRmsDb)} dB",
                                style = MaterialTheme.typography.bodySmall
                            )
                                Text(report.note, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }


            }
        }

        if (visualizationSegments.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Field phase animation", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = {
                                phaseViewEnabled = true
                                phaseAnimationRunning = !phaseAnimationRunning
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text(if (phaseAnimationRunning) "⏸ PAUSE" else "▶ PHASE ANIMATION") }
                        Button(
                            onClick = {
                                phaseAnimationRunning = false
                                phaseViewEnabled = false
                            },
                            modifier = Modifier.weight(1f),
                            enabled = phaseViewEnabled
                        ) { Text("STATIC") }
                    }
                    Text("Phase: ${"%.1f".format(phaseAnimationDeg)}°", style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = phaseAnimationDeg,
                        onValueChange = {
                            phaseAnimationRunning = false
                            phaseViewEnabled = true
                            phaseAnimationDeg = it
                        },
                        valueRange = 0f..360f,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf(0.25f, 0.5f, 1.0f, 2.0f).forEach { speed ->
                            Button(
                                onClick = { phaseAnimationSpeed = speed },
                                modifier = Modifier.weight(1f),
                                enabled = kotlin.math.abs(phaseAnimationSpeed - speed) > 0.001f
                            ) { Text("${if (speed == speed.toInt().toFloat()) speed.toInt() else speed}×") }
                        }
                    }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Electromagnetic field E/H/B/S — Near Field", style = MaterialTheme.typography.titleMedium)

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(onClick = { fieldPlane = NearFieldEngine.Plane.XY; fieldResult = null }, modifier = Modifier.weight(1f), enabled = !fieldRunning && fieldPlane != NearFieldEngine.Plane.XY) { Text("XY") }
                    Button(onClick = { fieldPlane = NearFieldEngine.Plane.XZ; fieldResult = null }, modifier = Modifier.weight(1f), enabled = !fieldRunning && fieldPlane != NearFieldEngine.Plane.XZ) { Text("XZ") }
                    Button(onClick = { fieldPlane = NearFieldEngine.Plane.YZ; fieldResult = null }, modifier = Modifier.weight(1f), enabled = !fieldRunning && fieldPlane != NearFieldEngine.Plane.YZ) { Text("YZ") }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = fieldGridText,
                        onValueChange = { fieldGridText = it.filter(Char::isDigit); fieldResult = null },
                        label = { Text("Grid") },
                        singleLine = true,
                        enabled = !fieldRunning,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = fieldRangeDbText,
                        onValueChange = { fieldRangeDbText = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' } },
                        label = { Text("dB range") },
                        singleLine = true,
                        enabled = !fieldRunning,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(onClick = { fieldDetail = MaaFieldDetail.NORMAL }, modifier = Modifier.weight(1f), enabled = fieldDetail != MaaFieldDetail.NORMAL) { Text("FIELD N") }
                    Button(onClick = { fieldDetail = MaaFieldDetail.HIGH }, modifier = Modifier.weight(1f), enabled = fieldDetail != MaaFieldDetail.HIGH) { Text("FIELD HD") }
                    Button(onClick = { fieldDetail = MaaFieldDetail.ULTRA }, modifier = Modifier.weight(1f), enabled = fieldDetail != MaaFieldDetail.ULTRA) { Text("FIELD ULTRA") }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.H_DB }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.H_DB) { Text("H dB") }
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.E_DB }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.E_DB) { Text("E dB") }
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.B_MICROTESLA }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.B_MICROTESLA) { Text("B µT") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.H_LINEAR }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.H_LINEAR) { Text("H A/m") }
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.E_LINEAR }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.E_LINEAR) { Text("E V/m") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(
                        onClick = {
                            val enableVector = !fieldVectorMode
                            fieldVectorMode = enableVector
                            if (enableVector) {
                                fieldDisplay = MaaFieldDisplay.E_LINEAR
                                phaseViewEnabled = true
                            } else {
                                phaseAnimationRunning = false
                                phaseViewEnabled = false
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(if (fieldVectorMode) "E-VECTOR ✓" else "E-VECTOR") }
                    Button(
                        onClick = {
                            fieldVectorMode = true
                            fieldDisplay = MaaFieldDisplay.E_LINEAR
                            phaseViewEnabled = true
                            phaseAnimationRunning = !phaseAnimationRunning
                        },
                        modifier = Modifier.weight(1f),
                        enabled = fieldResult != null
                    ) { Text(if (phaseAnimationRunning && fieldVectorMode) "⏸ E" else "▶ ROTATE E") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.S_DB }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.S_DB) { Text("S dB") }
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.S_LINEAR }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.S_LINEAR) { Text("S W/m²") }
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.Z_EH }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.Z_EH) { Text("|E|/|H|") }
                }
                val segmentsForField = visualizationSegments
                if (segmentsForField.isEmpty()) {
                    Text("NEC-2 FULL complex currents are required. Run the main FULL calculation.", style = MaterialTheme.typography.bodySmall)
                } else if (!fieldRunning) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Button(
                            onClick = {
                                val token = AtomicBoolean(false)
                                fieldCancelToken = token
                                fieldRunning = true
                                fieldProgress = 0
                                fieldError = null
                                val halfSpan = NearFieldEngine.autoHalfSpanLambda(m, fieldPlane)
                                val grid = (fieldGridText.toIntOrNull() ?: 71).coerceIn(21, 161)
                                solverScope.launch {
                                    val outcome = runCatching {
                                        withContext(Dispatchers.Default) {
                                            NearFieldEngine.calculate(
                                                model = m,
                                                segments = segmentsForField,
                                                plane = fieldPlane,
                                                halfSpanLambda = halfSpan,
                                                gridSize = grid,
                                                currentSourceLabel = visualizationEngineLabel,
                                                onProgress = { pr -> solverScope.launch { fieldProgress = pr.percent } },
                                                isCancelled = { token.get() }
                                            )
                                        }
                                    }
                                    outcome.onSuccess { fieldResult = it; fieldProgress = 100 }
                                    outcome.onFailure { e -> fieldError = e.message ?: "Near Field error" }
                                    fieldRunning = false
                                    fieldCancelToken = null
                                }
                            },
                            modifier = Modifier.weight(2f)
                        ) { Text(if (fieldResult == null) "CALCULATE FIELD" else "RECALCULATE FIELD") }
                    }
                } else {
                    Text("$fieldProgress% • Calculating electromagnetic field", style = MaterialTheme.typography.bodyMedium)
                    LinearProgressIndicator(progress = { fieldProgress.coerceIn(0,100) / 100f }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { fieldCancelToken?.set(true) }, modifier = Modifier.fillMaxWidth()) { Text("CANCEL FIELD") }
                }
                fieldError?.let { Text("Near Field: $it", style = MaterialTheme.typography.bodySmall) }
                fieldResult?.let { g ->
                    val fieldRangeDb = (fieldRangeDbText.replace(",", ".").toDoubleOrNull() ?: 60.0).coerceIn(20.0, 100.0)
                    val animatedFieldFrame = fieldVectorMode || phaseViewEnabled
                    // In E-VECTOR mode only arrows rotate; the colour envelope is static and can stay HD.
                    val animatedColorRaster = phaseViewEnabled && !fieldVectorMode
                    val rasterSize = nearFieldRasterSize(g.size, fieldDetail, animatedColorRaster)
                    Text(
                        "Display raster ${rasterSize}×${rasterSize} • GPU smooth filtering • physics grid ${g.size}×${g.size}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    NearFieldHeatMap(
                        model = m,
                        grid = g,
                        display = fieldDisplay,
                        detail = fieldDetail,
                        dbRange = fieldRangeDb,
                        phaseDeg = if (animatedFieldFrame) phaseAnimationDeg else null,
                        vectorMode = fieldVectorMode,
                        cleanWireArtifacts = fieldCleanView
                    )
                    val peakText = when (fieldDisplay) {
                        MaaFieldDisplay.H_DB -> "0.0 dB (|H|)"
                        MaaFieldDisplay.E_DB -> "0.0 dB (|E|)"
                        MaaFieldDisplay.S_DB -> "0.0 dB (|S|)"
                        MaaFieldDisplay.H_LINEAR -> "${"%.4g".format(g.peakHAmpPerM)} A/m"
                        MaaFieldDisplay.E_LINEAR -> "${"%.4g".format(g.peakEVoltPerM)} V/m"
                        MaaFieldDisplay.B_MICROTESLA -> "${"%.4g".format(g.peakBMicroTesla)} µT"
                        MaaFieldDisplay.S_LINEAR -> "${"%.4g".format(g.peakPowerDensityWPerM2)} W/m²"
                        MaaFieldDisplay.Z_EH -> "local |E|/|H|"
                    }
                    val peakU = when (fieldDisplay) {
                        MaaFieldDisplay.E_DB, MaaFieldDisplay.E_LINEAR -> g.peakEU
                        MaaFieldDisplay.S_DB, MaaFieldDisplay.S_LINEAR -> g.peakSU
                        else -> g.peakHU
                    }
                    val peakV = when (fieldDisplay) {
                        MaaFieldDisplay.E_DB, MaaFieldDisplay.E_LINEAR -> g.peakEV
                        MaaFieldDisplay.S_DB, MaaFieldDisplay.S_LINEAR -> g.peakSV
                        else -> g.peakHV
                    }
                    Text(
                        "${g.plane} • ${g.size}×${g.size} • peak $peakText • u=${"%.3f".format(peakU)} m, v=${"%.3f".format(peakV)} m",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

    }
}


@Composable
private fun MaaPatternEngineeringInfo(model: MaaModel, preview: MaaPatternPreview, planeLabel: String) {
    val pts = preview.points
    if (pts.isEmpty()) return
    val maxPoint = pts.maxByOrNull { it.db } ?: return
    val minPoint = pts.minByOrNull { it.db } ?: return
    fun nearestDb(angle: Double): Double? = pts.minByOrNull { p ->
        val d = kotlin.math.abs(((p.angleDeg - angle + 540.0) % 360.0) - 180.0)
        d
    }?.db
    fun db(v: Double?) = v?.let { "%.1f dB".format(it) } ?: "—"
    fun deg(v: Double) = "%.1f°".format((v % 360.0 + 360.0) % 360.0)

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("Current cut parameters", style = MaterialTheme.typography.titleSmall)
            Text("Cut: $planeLabel   •   engine: NEC-2 FULL")
            Text("Pattern maximum: ${db(maxPoint.db)} at ${deg(maxPoint.angleDeg)}")
            Text("Pattern minimum: ${db(minPoint.db)} at ${deg(minPoint.angleDeg)}")
            Text("HPBW (−3 dB): ${preview.hpbwDeg?.let { "%.1f°".format(it) } ?: "—"}")
            Text("F/B: ${db(preview.frontBackDb)}   •   max sidelobe: ${db(preview.maxSideLobeDb)}")

            if (planeLabel.startsWith("AZ ")) {
                val vals = pts.map { it.db }
                val ripple = (vals.maxOrNull() ?: 0.0) - (vals.minOrNull() ?: 0.0)
                Text("Azimuth nonuniformity: ${"%.2f dB".format(ripple)}")
                Text("0°/90°/180°/270°: ${db(nearestDb(0.0))} / ${db(nearestDb(90.0))} / ${db(nearestDb(180.0))} / ${db(nearestDb(270.0))}")
                Text("AZ — cut perpendicular to symmetry axis ${model.omniSymmetryAxis ?: model.mainAxis}.", style = MaterialTheme.typography.bodySmall)
            } else if (planeLabel.startsWith("EL ") && model.omniSymmetryAxis != null) {
                val ax = model.omniSymmetryAxis
                Text("Horizon 0°/180°: ${db(nearestDb(0.0))} / ${db(nearestDb(180.0))}")
                Text("Along axis +$ax / −$ax (90°/270°): ${db(nearestDb(90.0))} / ${db(nearestDb(270.0))}")
                Text("EL — vertical cut: 0° and 180° = horizon; 90° = +$ax; 270° = −$ax.", style = MaterialTheme.typography.bodySmall)
            } else {
                val axes = planeLabel.substringAfter(' ', "").split('-')
                val a = axes.getOrNull(0)?.ifBlank { null } ?: model.mainAxis.toString()
                val b = axes.getOrNull(1)?.ifBlank { null } ?: "⊥"
                Text("0° (+$a): ${db(nearestDb(0.0))}   •   180° (−$a): ${db(nearestDb(180.0))}")
                Text("90° (+$b): ${db(nearestDb(90.0))}   •   270° (−$b): ${db(nearestDb(270.0))}")
                Text("For a directional antenna, 0° corresponds to +$a; the opposite direction is 180°.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}


@Composable
private fun MaaInfoCard(
    fileName: String?,
    m: MaaModel,
    sourceFrequencyMHz: Double = m.frequencyMHz,
    corpusProfile: MaaCorpusProfile? = null
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(m.title, style = MaterialTheme.typography.titleMedium)
            fileName?.takeIf { it.isNotBlank() }?.let { maaFileName ->
                Text(
                    "MAA file: $maaFileName",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Text("${m.antennaKind} • ${"%.3f".format(m.frequencyMHz)} MHz • λ=${"%.4f".format(m.wavelengthM)} m")
            val sourceCount = m.sources.size.coerceAtLeast(if (m.sourceWireIndex != null) 1 else 0)
            Text("Wires: ${m.wires.size} • sources: $sourceCount")
            Text("Dimensions: ${"%.3f".format(m.spanX)} × ${"%.3f".format(m.spanY)} × ${"%.3f".format(m.spanZ)} m", style = MaterialTheme.typography.bodySmall)
            corpusProfile?.let { cp ->
                Text(
                    "CORPUS: ${cp.category} • ${cp.confidencePercent}% confidence",
                    style = MaterialTheme.typography.bodySmall
                )
                Text("Role: ${cp.role}", style = MaterialTheme.typography.bodySmall)
                Text("Feed: ${cp.feedVariant}", style = MaterialTheme.typography.bodySmall)
                Text("Variant: ${cp.shortening} • ${cp.ground}", style = MaterialTheme.typography.bodySmall)
                Text("Learned from: ${cp.evidence}", style = MaterialTheme.typography.bodySmall)
            }
            if (abs(m.frequencyMHz - sourceFrequencyMHz) > 1e-9) {
                Text("MAA: ${"%.3f".format(sourceFrequencyMHz)} MHz", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun MaaGeometryCanvas(
    model: MaaModel,
    mode: MaaViewMode,
    onIsoViewChanged: (yawDeg: Float, pitchDeg: Float) -> Unit = { _, _ -> }
) {
    var yaw by remember(model) { mutableFloatStateOf(-28f) }
    var pitch by remember(model) { mutableFloatStateOf(22f) }
    var zoom by remember(model) { mutableFloatStateOf(1f) }
    var panX by remember(model) { mutableFloatStateOf(0f) }
    var panY by remember(model) { mutableFloatStateOf(0f) }

    val normal = MaterialTheme.colorScheme.primary
    val source = MaterialTheme.colorScheme.error
    val grid = MaterialTheme.colorScheme.outline.copy(alpha = 0.23f)

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(330.dp)
            .pointerInput(model, mode) {
                detectTransformGestures { _, pan, gestureZoom, rotation ->
                    if (mode == MaaViewMode.ISO) {
                        yaw += rotation
                        pitch = (pitch + pan.y * 0.08f).coerceIn(-85f, 85f)
                        onIsoViewChanged(yaw, pitch)
                    }
                    zoom = (zoom * gestureZoom).coerceIn(0.45f, 5.0f)
                    panX += pan.x * 0.25f
                    panY += pan.y * 0.25f
                }
            }
    ) {
        val w = size.width
        val h = size.height
        // engineering-paper grid
        val step = min(w, h) / 10f
        var x = 0f
        while (x <= w) { drawLine(grid, Offset(x, 0f), Offset(x, h), 1f); x += step }
        var y = 0f
        while (y <= h) { drawLine(grid, Offset(0f, y), Offset(w, y), 1f); y += step }

        val corners = listOf(
            doubleArrayOf(model.minX, model.minY, model.minZ), doubleArrayOf(model.minX, model.minY, model.maxZ),
            doubleArrayOf(model.minX, model.maxY, model.minZ), doubleArrayOf(model.minX, model.maxY, model.maxZ),
            doubleArrayOf(model.maxX, model.minY, model.minZ), doubleArrayOf(model.maxX, model.minY, model.maxZ),
            doubleArrayOf(model.maxX, model.maxY, model.minZ), doubleArrayOf(model.maxX, model.maxY, model.maxZ)
        )
        val center = doubleArrayOf((model.minX+model.maxX)/2, (model.minY+model.maxY)/2, (model.minZ+model.maxZ)/2)
        val yawNow = when (mode) { MaaViewMode.ISO -> yaw.toDouble(); MaaViewMode.SIDE -> 0.0; MaaViewMode.FRONT -> -90.0 }
        val pitchNow = when (mode) { MaaViewMode.ISO -> pitch.toDouble(); MaaViewMode.SIDE -> 0.0; MaaViewMode.FRONT -> 0.0 }
        val rawCorners = corners.map { project3d(it[0], it[1], it[2], center, yawNow, pitchNow) }
        val minPx = rawCorners.minOf { it.first }; val maxPx = rawCorners.maxOf { it.first }
        val minPy = rawCorners.minOf { it.second }; val maxPy = rawCorners.maxOf { it.second }
        val spanX = (maxPx-minPx).coerceAtLeast(1e-6); val spanY = (maxPy-minPy).coerceAtLeast(1e-6)
        val sc = 0.82 * min(w.toDouble()/spanX, h.toDouble()/spanY) * zoom
        val cx = w/2f + panX; val cy = h/2f + panY
        fun p(xx: Double, yy: Double, zz: Double): Offset {
            val q = project3d(xx, yy, zz, center, yawNow, pitchNow)
            return Offset((cx + q.first*sc).toFloat(), (cy - q.second*sc).toFloat())
        }

        // Axes use the same colors as the 3D radiation-pattern renderer so both views are
        // visually comparable: X = red, Y = green, Z = blue.
        val axisLen = max(model.boomLengthM, model.transverseSizeM).coerceAtLeast(0.05) * 0.18
        val o = p(center[0], center[1], center[2])
        drawLine(Color(0xFFFF5353), o, p(center[0]+axisLen, center[1], center[2]), 2.6f)
        drawLine(Color(0xFF63E572), o, p(center[0], center[1]+axisLen, center[2]), 2.6f)
        drawLine(Color(0xFF6695FF), o, p(center[0], center[1], center[2]+axisLen), 2.6f)

        model.wires.forEachIndexed { idx, wire ->
            val a = p(wire.x1, wire.y1, wire.z1)
            val b = p(wire.x2, wire.y2, wire.z2)
            val c = if (idx == model.sourceWireIndex) source else normal
            val thickness = if (idx == model.sourceWireIndex) 6f else 3.2f
            drawLine(c, a, b, thickness)
            if (idx == model.sourceWireIndex) {
                drawCircle(source, radius = 6f, center = Offset((a.x+b.x)/2f, (a.y+b.y)/2f))
            }
        }
    }
}

private fun project3d(x: Double, y: Double, z: Double, c: DoubleArray, yawDeg: Double, pitchDeg: Double): Pair<Double, Double> {
    val xx = x - c[0]; val yy = y - c[1]; val zz = z - c[2]
    val ya = Math.toRadians(yawDeg); val pa = Math.toRadians(pitchDeg)
    val x1 = xx * cos(ya) - yy * sin(ya)
    val y1 = xx * sin(ya) + yy * cos(ya)
    val z1 = zz
    val sx = x1
    val sy = z1 * cos(pa) - y1 * sin(pa)
    return sx to sy
}

@Composable
private fun MaaPolarPattern(preview: MaaPatternPreview) {
    val curve = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
    val textish = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
    val marker = MaterialTheme.colorScheme.error
    Canvas(Modifier.fillMaxWidth().height(320.dp)) {
        val c = Offset(size.width/2f, size.height/2f)
        val rMax = min(size.width, size.height)*0.43f
        listOf(0f, -10f, -20f, -30f, -40f).forEach { db ->
            val r = rMax * ((db + 40f) / 40f)
            drawCircle(grid, r, c, style = Stroke(1f))
        }
        for (a in 0 until 360 step 30) {
            val t = Math.toRadians(a.toDouble())
            drawLine(grid, c, Offset(c.x + rMax*cos(t).toFloat(), c.y - rMax*sin(t).toFloat()), 1f)
        }
        // Forward direction of the detected main axis is to the right, angle 0°.
        drawLine(textish, c, Offset(c.x+rMax, c.y), 2f)
        val path = Path()
        preview.points.forEachIndexed { idx, pp ->
            val db = pp.db.coerceIn(-40.0, 0.0)
            val rr = rMax * ((db + 40.0) / 40.0).toFloat()
            val t = Math.toRadians(pp.angleDeg)
            val p = Offset(c.x + rr*cos(t).toFloat(), c.y - rr*sin(t).toFloat())
            if (idx == 0) path.moveTo(p.x,p.y) else path.lineTo(p.x,p.y)
        }
        path.close()
        drawPath(path, curve.copy(alpha = 0.16f))
        drawPath(path, curve, style = Stroke(3f))
        drawCircle(marker, 5f, Offset(c.x+rMax,c.y))
    }
}

@Composable
private fun MaaRectPattern(preview: MaaPatternPreview) {
    val curve = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
    val marker = MaterialTheme.colorScheme.error
    Canvas(Modifier.fillMaxWidth().height(280.dp)) {
        val left=42f; val right=12f; val top=12f; val bottom=28f
        val pw=size.width-left-right; val ph=size.height-top-bottom
        for (i in 0..6) {
            val x=left+pw*i/6f
            drawLine(grid, Offset(x,top), Offset(x,top+ph),1f)
        }
        for (i in 0..4) {
            val y=top+ph*i/4f
            drawLine(grid, Offset(left,y), Offset(left+pw,y),1f)
        }
        fun pt(a:Double, db:Double):Offset {
            val x=left+((a+180.0)/360.0*pw).toFloat()
            val y=top+((-db.coerceIn(-40.0,0.0))/40.0*ph).toFloat()
            return Offset(x,y)
        }
        val path=Path()
        preview.points.forEachIndexed { i,p -> val q=pt(p.angleDeg,p.db); if(i==0)path.moveTo(q.x,q.y) else path.lineTo(q.x,q.y) }
        drawPath(path,curve,style=Stroke(3f))
        val x0 = pt(0.0, 0.0).x
        drawLine(marker.copy(alpha=.7f), Offset(x0, top), Offset(x0, top + ph), 2f)
    }
}


private fun decodeMaaText(bytes: ByteArray): String {
    // Modern files may be UTF-8; classic MMANA-GAL Russian files are commonly Windows-1251.
    return try {
        val decoder = StandardCharsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        decoder.decode(ByteBuffer.wrap(bytes)).toString()
    } catch (_: Exception) {
        String(bytes, Charset.forName("windows-1251"))
    }
}

@Composable
private fun NearFieldHeatMap(
    model: MaaModel,
    grid: NearFieldEngine.Grid,
    display: MaaFieldDisplay,
    detail: MaaFieldDetail,
    dbRange: Double,
    phaseDeg: Float? = null,
    vectorMode: Boolean = false,
    cleanWireArtifacts: Boolean = false
) {
    val surface = MaterialTheme.colorScheme.surface
    val textColor = MaterialTheme.colorScheme.onSurface
    val mu0 = 4.0e-7 * PI
    var probeX by remember(grid, display, detail, dbRange, vectorMode, cleanWireArtifacts) { mutableFloatStateOf(Float.NaN) }
    var probeY by remember(grid, display, detail, dbRange, vectorMode, cleanWireArtifacts) { mutableFloatStateOf(Float.NaN) }
    var probeGX by remember(grid, display, detail, dbRange, vectorMode, cleanWireArtifacts) { mutableFloatStateOf(Float.NaN) }
    var probeGY by remember(grid, display, detail, dbRange, vectorMode, cleanWireArtifacts) { mutableFloatStateOf(Float.NaN) }

    fun displayValueAt(idx: Int): Double = when (display) {
        MaaFieldDisplay.H_DB -> grid.hDb(idx, -dbRange)
        MaaFieldDisplay.E_DB -> grid.eDb(idx, -dbRange)
        MaaFieldDisplay.S_DB -> grid.sDb(idx, -dbRange)
        MaaFieldDisplay.H_LINEAR -> grid.hAmpPerM[idx]
        MaaFieldDisplay.E_LINEAR -> grid.eVoltPerM[idx]
        MaaFieldDisplay.B_MICROTESLA -> grid.hAmpPerM[idx] * mu0 * 1e6
        MaaFieldDisplay.S_LINEAR -> grid.powerDensityWPerM2[idx]
        MaaFieldDisplay.Z_EH -> grid.localWaveImpedanceOhm[idx]
    }

    fun normalizedFromValue(value: Double): Float = when (display) {
        MaaFieldDisplay.H_DB, MaaFieldDisplay.E_DB, MaaFieldDisplay.S_DB ->
            ((value + dbRange) / dbRange).coerceIn(0.0, 1.0).toFloat()
        MaaFieldDisplay.H_LINEAR -> (value / grid.peakHAmpPerM.coerceAtLeast(1e-30)).coerceIn(0.0, 1.0).toFloat()
        MaaFieldDisplay.E_LINEAR -> (value / grid.peakEVoltPerM.coerceAtLeast(1e-30)).coerceIn(0.0, 1.0).toFloat()
        MaaFieldDisplay.B_MICROTESLA -> (value / grid.peakBMicroTesla.coerceAtLeast(1e-30)).coerceIn(0.0, 1.0).toFloat()
        MaaFieldDisplay.S_LINEAR -> {
            val ref = grid.peakPowerDensityWPerM2.coerceAtLeast(1e-30) * if (phaseDeg != null) 2.0 else 1.0
            (value / ref).coerceIn(0.0, 1.0).toFloat()
        }
        MaaFieldDisplay.Z_EH -> {
            val z = value.coerceIn(1.0, 10000.0)
            val logRatio = kotlin.math.ln(z / 376.730313668) / kotlin.math.ln(10.0)
            ((logRatio + 2.0) / 4.0).coerceIn(0.0, 1.0).toFloat()
        }
    }

    fun colorArgbFor(norm: Float): Int {
        val safe = if (norm.isFinite()) norm.coerceIn(0f, 1f) else 0f
        val index = (safe * (nearFieldPaletteArgb.size - 1)).toInt().coerceIn(0, nearFieldPaletteArgb.lastIndex)
        return nearFieldPaletteArgb[index]
    }

    fun bilinearArray(values: DoubleArray, gx: Double, gy: Double): Double {
        val n = grid.size
        val x = gx.coerceIn(0.0, (n - 1).toDouble())
        val y = gy.coerceIn(0.0, (n - 1).toDouble())
        val x0 = kotlin.math.floor(x).toInt().coerceIn(0, n - 1)
        val y0 = kotlin.math.floor(y).toInt().coerceIn(0, n - 1)
        val x1 = (x0 + 1).coerceAtMost(n - 1)
        val y1 = (y0 + 1).coerceAtMost(n - 1)
        val tx = x - x0
        val ty = y - y0
        val v00 = values[y0 * n + x0]
        val v10 = values[y0 * n + x1]
        val v01 = values[y1 * n + x0]
        val v11 = values[y1 * n + x1]
        return (1.0 - ty) * ((1.0 - tx) * v00 + tx * v10) + ty * ((1.0 - tx) * v01 + tx * v11)
    }

    fun bilinearStaticValue(gx: Double, gy: Double): Double {
        val n = grid.size
        val x = gx.coerceIn(0.0, (n - 1).toDouble())
        val y = gy.coerceIn(0.0, (n - 1).toDouble())
        val x0 = kotlin.math.floor(x).toInt().coerceIn(0, n - 1)
        val y0 = kotlin.math.floor(y).toInt().coerceIn(0, n - 1)
        val x1 = (x0 + 1).coerceAtMost(n - 1)
        val y1 = (y0 + 1).coerceAtMost(n - 1)
        val tx = x - x0
        val ty = y - y0
        fun v(r: Int, c: Int) = displayValueAt(r * n + c)
        val v00 = v(y0, x0)
        val v10 = v(y0, x1)
        val v01 = v(y1, x0)
        val v11 = v(y1, x1)
        return (1.0 - ty) * ((1.0 - tx) * v00 + tx * v10) + ty * ((1.0 - tx) * v01 + tx * v11)
    }

    val phaseRad = phaseDeg?.toDouble()?.times(PI / 180.0)
    val phaseCos = phaseRad?.let { cos(it) } ?: 1.0
    val phaseSin = phaseRad?.let { sin(it) } ?: 0.0
    fun instant(re: Double, im: Double) = re * phaseCos - im * phaseSin
    fun ampDb(value: Double, peak: Double): Double =
        (20.0 * log10((value / peak.coerceAtLeast(1e-30)).coerceAtLeast(1e-12))).coerceAtLeast(-dbRange)
    fun powerDb(value: Double, peak: Double): Double =
        (10.0 * log10((value / peak.coerceAtLeast(1e-30)).coerceAtLeast(1e-12))).coerceAtLeast(-dbRange)

    fun phaseValue(gx: Double, gy: Double): Double {
        fun instComponent(reValues: DoubleArray, imValues: DoubleArray): Double =
            instant(bilinearArray(reValues, gx, gy), bilinearArray(imValues, gx, gy))

        return when (display) {
            MaaFieldDisplay.H_DB,
            MaaFieldDisplay.H_LINEAR,
            MaaFieldDisplay.B_MICROTESLA -> {
                val hx = instComponent(grid.hxRe, grid.hxIm)
                val hy = instComponent(grid.hyRe, grid.hyIm)
                val hz = instComponent(grid.hzRe, grid.hzIm)
                val h = sqrt(hx*hx + hy*hy + hz*hz)
                when (display) {
                    MaaFieldDisplay.H_DB -> ampDb(h, grid.peakHAmpPerM)
                    MaaFieldDisplay.B_MICROTESLA -> h * mu0 * 1e6
                    else -> h
                }
            }
            MaaFieldDisplay.E_DB,
            MaaFieldDisplay.E_LINEAR -> {
                val ex = instComponent(grid.exRe, grid.exIm)
                val ey = instComponent(grid.eyRe, grid.eyIm)
                val ez = instComponent(grid.ezRe, grid.ezIm)
                val e = sqrt(ex*ex + ey*ey + ez*ez)
                if (display == MaaFieldDisplay.E_DB) ampDb(e, grid.peakEVoltPerM) else e
            }
            MaaFieldDisplay.S_DB,
            MaaFieldDisplay.S_LINEAR,
            MaaFieldDisplay.Z_EH -> {
                val hx = instComponent(grid.hxRe, grid.hxIm)
                val hy = instComponent(grid.hyRe, grid.hyIm)
                val hz = instComponent(grid.hzRe, grid.hzIm)
                val ex = instComponent(grid.exRe, grid.exIm)
                val ey = instComponent(grid.eyRe, grid.eyIm)
                val ez = instComponent(grid.ezRe, grid.ezIm)
                val h = sqrt(hx*hx + hy*hy + hz*hz)
                val e = sqrt(ex*ex + ey*ey + ez*ez)
                if (display == MaaFieldDisplay.Z_EH) {
                    if (h > 1e-18) (e / h).coerceIn(0.0, 1.0e9) else 1.0e9
                } else {
                    // Instantaneous Poynting-vector magnitude |E(t) x H(t)|.
                    val sx = ey * hz - ez * hy
                    val sy = ez * hx - ex * hz
                    val sz = ex * hy - ey * hx
                    val s = sqrt(sx*sx + sy*sy + sz*sz)
                    if (display == MaaFieldDisplay.S_DB) {
                        powerDb(s, 2.0 * grid.peakPowerDensityWPerM2)
                    } else s
                }
            }
        }
    }

    // In E-vector mode the colour map deliberately stays on the phasor envelope.
    // Only the arrows rotate. This avoids the misleading "four moving lobes" effect of |E(t)|
    // and makes polarization visible as an actual vector trajectory.
    fun valueForPixel(gx: Double, gy: Double): Double =
        if (vectorMode || phaseDeg == null) bilinearStaticValue(gx, gy) else phaseValue(gx, gy)

    fun projectedEPhasor(gx: Double, gy: Double): DoubleArray {
        fun c(re: DoubleArray, im: DoubleArray): Pair<Double, Double> =
            Pair(bilinearArray(re, gx, gy), bilinearArray(im, gx, gy))
        val ex = c(grid.exRe, grid.exIm)
        val ey = c(grid.eyRe, grid.eyIm)
        val ez = c(grid.ezRe, grid.ezIm)
        return when (grid.plane) {
            NearFieldEngine.Plane.XY -> doubleArrayOf(ex.first, ex.second, ey.first, ey.second)
            NearFieldEngine.Plane.XZ -> doubleArrayOf(ex.first, ex.second, ez.first, ez.second)
            NearFieldEngine.Plane.YZ -> doubleArrayOf(ey.first, ey.second, ez.first, ez.second)
        }
    }

    // Display-only cleanup for the near-singular values sampled directly on a thin wire.
    // It never changes the NEC solution or the stored E/H phasors.  Only heat-map pixels
    // within a narrow tube around a wire are replaced by the average of two samples just
    // outside the tube, perpendicular to that wire.  RAW data, probe values and vectors
    // remain untouched.
    val cleanWireSegments = remember(model, grid) {
        val zShift = if (model.groundType != 0) model.addHeightM else 0.0
        val sliceCellM = 2.0 * grid.halfSpanM / (grid.size - 1).coerceAtLeast(1).toDouble()
        model.wires.mapNotNull { w ->
            val clipped = NearFieldSliceGeometry.clipWireToSlice(
                wire = w,
                plane = grid.plane,
                fixedCoordinateM = grid.fixedCoordinateM,
                zShiftM = zShift,
                sliceCellM = sliceCellM
            ) ?: return@mapNotNull null
            fun toGrid(x: Double, y: Double, z: Double): Pair<Double, Double> {
                val u: Double
                val v: Double
                when (grid.plane) {
                    NearFieldEngine.Plane.XY -> { u = x - grid.centerX; v = -(y - grid.centerY) }
                    NearFieldEngine.Plane.XZ -> { u = x - grid.centerX; v = -(z - grid.centerZ) }
                    NearFieldEngine.Plane.YZ -> { u = y - grid.centerY; v = -(z - grid.centerZ) }
                }
                val gx = (u + grid.halfSpanM) / (2.0 * grid.halfSpanM) * (grid.size - 1).toDouble()
                val gy = (v + grid.halfSpanM) / (2.0 * grid.halfSpanM) * (grid.size - 1).toDouble()
                return Pair(gx, gy)
            }
            val a = toGrid(clipped.x1, clipped.y1, clipped.z1)
            val b = toGrid(clipped.x2, clipped.y2, clipped.z2)
            doubleArrayOf(a.first, a.second, b.first, b.second)
        }
    }

    fun cleanedDisplayValue(gx: Double, gy: Double): Double {
        val raw = valueForPixel(gx, gy)
        if (!cleanWireArtifacts || cleanWireSegments.isEmpty()) return raw

        val maskRadiusCells = 1.55
        val sampleOffsetCells = 2.65
        var bestDist2 = Double.POSITIVE_INFINITY
        var bestX1 = 0.0
        var bestY1 = 0.0
        var bestX2 = 0.0
        var bestY2 = 0.0
        for (seg in cleanWireSegments) {
            val x1 = seg[0]; val y1 = seg[1]; val x2 = seg[2]; val y2 = seg[3]
            val dx = x2 - x1; val dy = y2 - y1
            val len2 = dx*dx + dy*dy
            val t = if (len2 > 1e-12) (((gx - x1)*dx + (gy - y1)*dy) / len2).coerceIn(0.0, 1.0) else 0.0
            val qx = x1 + t*dx; val qy = y1 + t*dy
            val ddx = gx - qx; val ddy = gy - qy
            val d2 = ddx*ddx + ddy*ddy
            if (d2 < bestDist2) {
                bestDist2 = d2
                bestX1 = x1; bestY1 = y1; bestX2 = x2; bestY2 = y2
            }
        }
        if (bestDist2 > maskRadiusCells * maskRadiusCells) return raw

        val dx = bestX2 - bestX1
        val dy = bestY2 - bestY1
        val len = sqrt(dx*dx + dy*dy)
        var nx = if (len > 1e-9) -dy / len else 1.0
        var ny = if (len > 1e-9) dx / len else 0.0
        if (!nx.isFinite() || !ny.isFinite()) { nx = 1.0; ny = 0.0 }

        val a = valueForPixel(gx + nx * sampleOffsetCells, gy + ny * sampleOffsetCells)
        val b = valueForPixel(gx - nx * sampleOffsetCells, gy - ny * sampleOffsetCells)
        val replacement = when {
            a.isFinite() && b.isFinite() -> 0.5 * (a + b)
            a.isFinite() -> a
            b.isFinite() -> b
            else -> raw
        }
        // Suppression mode must never create a new hotter peak than the RAW map.
        return if (display == MaaFieldDisplay.Z_EH) replacement else min(raw, replacement)
    }

    val projectedEPeak = remember(grid) {
        var peak = 0.0
        for (i in 0 until grid.size * grid.size) {
            val ur: Double; val ui: Double; val vr: Double; val vi: Double
            when (grid.plane) {
                NearFieldEngine.Plane.XY -> { ur = grid.exRe[i]; ui = grid.exIm[i]; vr = grid.eyRe[i]; vi = grid.eyIm[i] }
                NearFieldEngine.Plane.XZ -> { ur = grid.exRe[i]; ui = grid.exIm[i]; vr = grid.ezRe[i]; vi = grid.ezIm[i] }
                NearFieldEngine.Plane.YZ -> { ur = grid.eyRe[i]; ui = grid.eyIm[i]; vr = grid.ezRe[i]; vi = grid.ezIm[i] }
            }
            val a = sqrt(ur*ur + ui*ui + vr*vr + vi*vi)
            if (a > peak) peak = a
        }
        peak.coerceAtLeast(1e-30)
    }

    // Build the heat map as one raster image instead of issuing tens of thousands of drawRect()
    // calls.  This allows a denser static image and lets the GPU do the final smooth scaling.
    val rasterPhaseDeg = if (vectorMode) null else phaseDeg
    val rasterN = nearFieldRasterSize(grid.size, detail, rasterPhaseDeg != null)
    val heatMapImage = remember(grid, display, detail, dbRange, rasterPhaseDeg, vectorMode, cleanWireArtifacts) {
        val pixels = IntArray(rasterN * rasterN)
        val denom = (rasterN - 1).coerceAtLeast(1).toDouble()
        for (row in 0 until rasterN) {
            val gy = row * (grid.size - 1).toDouble() / denom
            val base = row * rasterN
            for (col in 0 until rasterN) {
                val gx = col * (grid.size - 1).toDouble() / denom
                val norm = normalizedFromValue(cleanedDisplayValue(gx, gy))
                pixels[base + col] = colorArgbFor(norm)
            }
        }
        Bitmap.createBitmap(rasterN, rasterN, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, rasterN, 0, 0, rasterN, rasterN)
        }.asImageBitmap()
    }

    Canvas(
        Modifier
            .fillMaxWidth()
            .height(360.dp)
            .pointerInput(grid, display, detail, dbRange, vectorMode, cleanWireArtifacts) {
                detectTapGestures { off ->
                    probeX = off.x
                    probeY = off.y
                    probeGX = (off.x / size.width.coerceAtLeast(1).toFloat() * (grid.size - 1)).coerceIn(0f, (grid.size - 1).toFloat())
                    probeGY = (off.y / size.height.coerceAtLeast(1).toFloat() * (grid.size - 1)).coerceIn(0f, (grid.size - 1).toFloat())
                }
            }
    ) {
        drawRect(surface)
        val n = grid.size
        if (n < 2) return@Canvas

        // One GPU-filtered image replaces thousands of individual Canvas rectangles.
        // The source raster is already interpolated from the physical Near Field grid; high
        // filter quality removes residual block edges when fitting it to the phone screen.
        drawImage(
            image = heatMapImage,
            dstSize = IntSize(size.width.toInt().coerceAtLeast(1), size.height.toInt().coerceAtLeast(1)),
            filterQuality = FilterQuality.High
        )

        fun mapPoint(x: Double, y: Double, z: Double): Offset {
            val u: Double
            val v: Double
            when (grid.plane) {
                NearFieldEngine.Plane.XY -> { u = x - grid.centerX; v = -(y - grid.centerY) }
                NearFieldEngine.Plane.XZ -> { u = x - grid.centerX; v = -(z - grid.centerZ) }
                NearFieldEngine.Plane.YZ -> { u = y - grid.centerY; v = -(z - grid.centerZ) }
            }
            val px = ((u + grid.halfSpanM) / (2.0 * grid.halfSpanM) * size.width).toFloat()
            val py = ((v + grid.halfSpanM) / (2.0 * grid.halfSpanM) * size.height).toFloat()
            return Offset(px, py)
        }

        // light reference grid
        for (i in 0..4) {
            val x = size.width * i / 4f
            val y = size.height * i / 4f
            drawLine(textColor.copy(alpha = 0.12f), Offset(x, 0f), Offset(x, size.height), 1f)
            drawLine(textColor.copy(alpha = 0.12f), Offset(0f, y), Offset(size.width, y), 1f)
        }

        val zShift = if (model.groundType != 0) model.addHeightM else 0.0
        // Overlay only geometry that physically belongs to the selected slice. Older builds
        // projected every wire onto the heat map, which could make an offset/cross section look
        // as if the whole antenna were located in that plane.
        val sliceCellM = 2.0 * grid.halfSpanM / (grid.size - 1).coerceAtLeast(1).toDouble()
        model.wires.forEachIndexed { wi, w ->
            val clipped = NearFieldSliceGeometry.clipWireToSlice(
                wire = w,
                plane = grid.plane,
                fixedCoordinateM = grid.fixedCoordinateM,
                zShiftM = zShift,
                sliceCellM = sliceCellM
            ) ?: return@forEachIndexed
            val a = mapPoint(clipped.x1, clipped.y1, clipped.z1)
            val b = mapPoint(clipped.x2, clipped.y2, clipped.z2)
            val source = wi == model.sourceWireIndex
            val c = if (source) Color.Red else textColor
            if (sqrt(((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y)).toDouble()) < 3.0) {
                drawCircle(c, radius = if (source) 3.6f else 2.3f, center = a)
            } else {
                drawLine(
                    color = c,
                    start = a,
                    end = b,
                    strokeWidth = if (source) 3.8f else 1.6f,
                    cap = StrokeCap.Round
                )
            }
        }

        if (vectorMode) {
            val phi = (phaseDeg ?: 0f).toDouble() * PI / 180.0
            val cPhi = cos(phi)
            val sPhi = sin(phi)
            val arrowCols = 11
            val arrowRows = 11
            val stepX = size.width / (arrowCols + 1).toFloat()
            val stepY = size.height / (arrowRows + 1).toFloat()
            val maxArrow = min(stepX, stepY) * 0.72f

            fun drawArrow(center: Offset, du: Double, dv: Double, alpha: Float) {
                val mag = sqrt(du*du + dv*dv)
                if (mag <= projectedEPeak * 0.008) return
                val rel = (mag / projectedEPeak).coerceIn(0.0, 1.0)
                val len = maxArrow * (0.22f + 0.78f * sqrt(rel).toFloat())
                val ux = (du / mag).toFloat()
                val uy = (dv / mag).toFloat()
                val end = Offset(center.x + ux * len, center.y + uy * len)
                val head = (len * 0.28f).coerceIn(4f, 10f)
                val px = -uy
                val py = ux
                val h1 = Offset(end.x - ux * head + px * head * 0.52f, end.y - uy * head + py * head * 0.52f)
                val h2 = Offset(end.x - ux * head - px * head * 0.52f, end.y - uy * head - py * head * 0.52f)
                val outline = Color.Black.copy(alpha = (alpha * 0.70f).coerceIn(0.25f, 0.80f))
                val arrow = Color.White.copy(alpha = alpha.coerceIn(0.45f, 1.0f))
                drawLine(outline, center, end, 4.0f, cap = StrokeCap.Round)
                drawLine(outline, end, h1, 4.0f, cap = StrokeCap.Round)
                drawLine(outline, end, h2, 4.0f, cap = StrokeCap.Round)
                drawLine(arrow, center, end, 2.0f, cap = StrokeCap.Round)
                drawLine(arrow, end, h1, 2.0f, cap = StrokeCap.Round)
                drawLine(arrow, end, h2, 2.0f, cap = StrokeCap.Round)
                drawCircle(outline, 2.4f, center)
                drawCircle(arrow, 1.2f, center)
            }

            for (r in 1..arrowRows) {
                for (c in 1..arrowCols) {
                    val px = stepX * c
                    val py = stepY * r
                    val gx = px / size.width.coerceAtLeast(1f) * (grid.size - 1).toFloat()
                    val gy = py / size.height.coerceAtLeast(1f) * (grid.size - 1).toFloat()
                    val e = projectedEPhasor(gx.toDouble(), gy.toDouble())
                    val du = e[0] * cPhi - e[1] * sPhi
                    val dv = -(e[2] * cPhi - e[3] * sPhi)
                    val staticAmp = sqrt(e[0]*e[0] + e[1]*e[1] + e[2]*e[2] + e[3]*e[3])
                    val alpha = (0.35 + 0.65 * sqrt((staticAmp / projectedEPeak).coerceIn(0.0, 1.0))).toFloat()
                    drawArrow(Offset(px, py), du, dv, alpha)
                }
            }

            // At the selected probe draw the full polarization trajectory (ellipse/line) and
            // the current instantaneous vector. This is a direct view of the phasor pair;
            // no extra solver or synthetic 90° phase shift is introduced.
            if (!probeX.isNaN() && !probeY.isNaN() && !probeGX.isNaN() && !probeGY.isNaN()) {
                val e = projectedEPhasor(probeGX.toDouble(), probeGY.toDouble())
                var trajPeak = 0.0
                for (q in 0..72) {
                    val a = q * 2.0 * PI / 72.0
                    val uu = e[0] * cos(a) - e[1] * sin(a)
                    val vv = -(e[2] * cos(a) - e[3] * sin(a))
                    trajPeak = max(trajPeak, sqrt(uu*uu + vv*vv))
                }
                if (trajPeak > projectedEPeak * 1e-6) {
                    val radius = min(size.width, size.height) * 0.10f
                    val scale = radius / trajPeak.toFloat()
                    val path = Path()
                    for (q in 0..72) {
                        val a = q * 2.0 * PI / 72.0
                        val uu = (e[0] * cos(a) - e[1] * sin(a)).toFloat() * scale
                        val vv = (-(e[2] * cos(a) - e[3] * sin(a))).toFloat() * scale
                        val pt = Offset(probeX + uu, probeY + vv)
                        if (q == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
                    }
                    drawPath(path, Color.White.copy(alpha = 0.88f), style = Stroke(2.0f))
                    val cu = (e[0] * cPhi - e[1] * sPhi).toFloat() * scale
                    val cv = (-(e[2] * cPhi - e[3] * sPhi)).toFloat() * scale
                    drawLine(Color.Black.copy(alpha = 0.75f), Offset(probeX, probeY), Offset(probeX + cu, probeY + cv), 5f, cap = StrokeCap.Round)
                    drawLine(Color.White, Offset(probeX, probeY), Offset(probeX + cu, probeY + cv), 2.5f, cap = StrokeCap.Round)
                }
            }
        }

        drawLine(textColor.copy(alpha = 0.45f), Offset(size.width / 2f, 0f), Offset(size.width / 2f, size.height), 1f)
        drawLine(textColor.copy(alpha = 0.45f), Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), 1f)
        drawRect(textColor.copy(alpha = 0.35f), style = Stroke(1.5f))

        if (!probeX.isNaN() && !probeY.isNaN()) {
            val px = probeX.coerceIn(0f, size.width)
            val py = probeY.coerceIn(0f, size.height)
            drawLine(Color.White.copy(alpha = 0.95f), Offset(px, 0f), Offset(px, size.height), 1.2f)
            drawLine(Color.White.copy(alpha = 0.95f), Offset(0f, py), Offset(size.width, py), 1.2f)
            drawCircle(Color.White, radius = 5f, center = Offset(px, py), style = Stroke(1.8f))
        }
    }

    if (!probeX.isNaN() && !probeY.isNaN()) {
        Text("Point marker enabled: the white crosshair shows the selected map region. Changing plane/mode recalculates the map without changing field physics.", style = MaterialTheme.typography.bodySmall)
        if (vectorMode && !probeGX.isNaN() && !probeGY.isNaN()) {
            val e = projectedEPhasor(probeGX.toDouble(), probeGY.toDouble())
            val pa = PolarizationMath.analyze(e[0], e[1], e[2], e[3])
            val kind = when (pa.kind) {
                PolarizationMath.Kind.TOO_SMALL -> "field too small to evaluate"
                PolarizationMath.Kind.NEAR_CIRCULAR -> "nearly circular projection"
                PolarizationMath.Kind.ELLIPTICAL -> "elliptical projection"
                PolarizationMath.Kind.ELONGATED -> "highly elongated elliptical projection"
                PolarizationMath.Kind.NEAR_LINEAR -> "nearly linear projection"
            }
            Text(
                "Polarization at marker (${grid.plane}): |Eu|=${"%.3g".format(pa.amplitudeU)} V/m, |Ev|=${"%.3g".format(pa.amplitudeV)} V/m, min/max=${"%.3f".format(pa.minMaxAmplitudeRatio)}, Δφ=${"%+.1f".format(pa.deltaPhaseDeg)}°, AR≈${if (pa.axialRatio < 999.0) "%.2f".format(pa.axialRatio) else "∞"}:1 → $kind.",
                style = MaterialTheme.typography.bodySmall
            )
            Text("The white curve around the marker is the trajectory of the E-vector tip over a full period. Circle = circular, ellipse = elliptical, line = linear polarization in this cut.", style = MaterialTheme.typography.bodySmall)
        }
    } else {
        Text(
            if (vectorMode) "Tap the map: the selected point will show the E polarization trajectory and Δφ/AR estimate."
            else "Tap the field map to enable the visual crosshair and inspect the local Near Field region more precisely.",
            style = MaterialTheme.typography.bodySmall
        )
    }

    Text(
        if (vectorMode) {
            "E-VECTOR: color = static |E|; arrows and polarization trajectory are built from complex E components without changing the NEC solution or adding an artificial phase shift."
        } else if (phaseDeg != null) {
            when (display) {
                MaaFieldDisplay.H_DB -> "Phase frame: |H(t)| from Re{H·eʲφ}, dB relative to the static phasor peak."
                MaaFieldDisplay.E_DB -> "Phase frame: |E(t)| from Re{E·eʲφ}, dB relative to the static phasor peak."
                MaaFieldDisplay.H_LINEAR -> "Phase frame: instantaneous |H(t)|, A/m."
                MaaFieldDisplay.E_LINEAR -> "Phase frame: instantaneous |E(t)|, V/m."
                MaaFieldDisplay.B_MICROTESLA -> "Phase frame: |B(t)|=µ₀|H(t)|, µT."
                MaaFieldDisplay.S_DB -> "Phase frame: instantaneous |E(t)×H(t)|, dB; this is not period-averaged S."
                MaaFieldDisplay.S_LINEAR -> "Phase frame: instantaneous |E(t)×H(t)|, W/m²."
                MaaFieldDisplay.Z_EH -> "Phase frame: instantaneous |E(t)|/|H(t)|, Ω; near nodes the ratio can change sharply."
            }
        } else when (display) {
            MaaFieldDisplay.H_DB -> "Color: |H|, 0…−${dbRange.toInt()} dB relative to maximum H."
            MaaFieldDisplay.E_DB -> "Color: |E|, 0…−${dbRange.toInt()} dB relative to maximum E."
            MaaFieldDisplay.H_LINEAR -> "Color: |H|, A/m; visual scale normalized to the map maximum."
            MaaFieldDisplay.E_LINEAR -> "Color: |E|, V/m; visual scale normalized to the map maximum."
            MaaFieldDisplay.B_MICROTESLA -> "Color: |B|=µ₀|H|, µT; visual scale normalized to the map maximum."
            MaaFieldDisplay.S_DB -> "Color: |S|=|½Re(E×H*)|, 0…−${dbRange.toInt()} dB relative to maximum power flux."
            MaaFieldDisplay.S_LINEAR -> "Color: power flux density |S|, W/m²; scale normalized to the map maximum."
            MaaFieldDisplay.Z_EH -> "Color: local |E|/|H| ratio, Ω. About 376.7 Ω corresponds locally to free-space wave mode."
        },
        style = MaterialTheme.typography.bodySmall
    )
}



@Composable
private fun ImpedanceSonogramCard(
    sweepPoints: List<OpenNecFull.SweepPoint>,
    z0Ohm: Double,
    sweepPosition: Double?
) {
    if (sweepPoints.size < 2) return
    val z0 = z0Ohm.coerceAtLeast(1e-9)
    val best = sweepPoints.minByOrNull { it.primary.swr(z0) } ?: return
    val resonance = sweepPoints.minByOrNull { kotlin.math.abs(it.primary.xOhm) } ?: best
    val r50 = sweepPoints.minByOrNull { kotlin.math.abs(it.primary.rOhm - z0) } ?: best
    val rl10 = sweepPoints.filter { gammaMagFromZ(it.primary.rOhm, it.primary.xOhm, z0) <= 0.31622776601683794 }
    val bandText = if (rl10.isNotEmpty()) {
        "−10 dB RL band: ${maaFmt(rl10.first().frequencyMHz, 6)}…${maaFmt(rl10.last().frequencyMHz, 6)} MHz"
    } else "−10 dB RL band: none in this sweep"
    val current = sweepPosition?.let { raw ->
        val u = raw.coerceIn(0.0, 1.0)
        val xx = u * (sweepPoints.lastIndex).toDouble()
        val i0 = kotlin.math.floor(xx).toInt().coerceIn(0, sweepPoints.lastIndex)
        val i1 = (i0 + 1).coerceAtMost(sweepPoints.lastIndex)
        val t = xx - i0
        val a = sweepPoints[i0]
        val b = sweepPoints[i1]
        val f = a.frequencyMHz + (b.frequencyMHz - a.frequencyMHz) * t
        val r = a.primary.rOhm + (b.primary.rOhm - a.primary.rOhm) * t
        val x = a.primary.xOhm + (b.primary.xOhm - a.primary.xOhm) * t
        Triple(f, r, x)
    }
    val axisColor = MaterialTheme.colorScheme.onSurface
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    val surfaceColor = MaterialTheme.colorScheme.surface
    val bgColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.28f)
    val bestColor = MaterialTheme.colorScheme.tertiary
    val labelArgb = axisColor.toArgb()

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("IMPEDANCE SONOGRAM", style = MaterialTheme.typography.titleSmall)
            Text(
                "Five synchronized maps: R • X • VSWR • |Γ| • ∠Γ. Vertical cursor follows ANTENNA AUDIO.",
                style = MaterialTheme.typography.bodySmall
            )
            Canvas(Modifier.fillMaxWidth().height(230.dp)) {
                drawRoundRect(bgColor, Offset.Zero, size, androidx.compose.ui.geometry.CornerRadius(18f,18f))
                val left = 62f
                val right = 8f
                val top = 12f
                val rowGap = 6f
                val rows = 5
                val plotW = (size.width - left - right).coerceAtLeast(1f)
                val rowH = ((size.height - top * 2f - rowGap * (rows - 1)) / rows).coerceAtLeast(1f)
                val labels = listOf("R", "X", "VSWR", "|Γ|", "∠Γ")
                val paint = Paint().apply { color = labelArgb; textSize = 19f; isAntiAlias = true }

                fun xForIndex(i: Int): Float = left + plotW * i.toFloat() / sweepPoints.lastIndex.toFloat()
                for (row in 0 until rows) {
                    val y = top + row * (rowH + rowGap)
                    drawRoundRect(surfaceColor.copy(alpha=0.55f), Offset(left,y), Size(plotW,rowH), androidx.compose.ui.geometry.CornerRadius(8f,8f))
                    drawContext.canvas.nativeCanvas.drawText(labels[row], 8f, y + rowH*0.68f, paint)
                    for (i in 0 until sweepPoints.lastIndex) {
                        val a=sweepPoints[i]
                        val b=sweepPoints[i+1]
                        val r=0.5*(a.primary.rOhm+b.primary.rOhm)
                        val x=0.5*(a.primary.xOhm+b.primary.xOhm)
                        val gm=gammaMagFromZ(r,x,z0)
                        val swr=((1.0+gm)/(1.0-gm).coerceAtLeast(1e-6)).coerceAtMost(20.0)
                        val ph=TouchstoneMath.phaseDeg(impedanceToGamma(r,x,z0))
                        val c=when(row){
                            0 -> sonogramResistanceColor(r,z0)
                            1 -> impedanceSweepColor(r,x,z0)
                            2 -> sonogramScalarColor(((swr-1.0)/5.0).coerceIn(0.0,1.0))
                            3 -> sonogramScalarColor(gm)
                            else -> sonogramPhaseColor(ph)
                        }
                        val x0=xForIndex(i); val x1=xForIndex(i+1)
                        drawRect(c, Offset(x0,y), Size((x1-x0)+1f,rowH))
                    }
                    drawLine(gridColor,Offset(left,y+rowH),Offset(left+plotW,y+rowH),strokeWidth=1f)
                }

                // Diagnostic marker lines: resonance, best match and R~=R0.
                fun markerX(point: OpenNecFull.SweepPoint): Float {
                    val idx=sweepPoints.indexOf(point).coerceAtLeast(0)
                    return xForIndex(idx)
                }
                drawLine(axisColor.copy(alpha=.70f),Offset(markerX(resonance),top),Offset(markerX(resonance),size.height-top),strokeWidth=1.4f)
                drawLine(bestColor,Offset(markerX(best),top),Offset(markerX(best),size.height-top),strokeWidth=2.6f)
                drawLine(axisColor.copy(alpha=.42f),Offset(markerX(r50),top),Offset(markerX(r50),size.height-top),strokeWidth=1.2f)

                sweepPosition?.let { raw ->
                    val u=raw.coerceIn(0.0,1.0).toFloat()
                    val xc=left+plotW*u
                    drawLine(surfaceColor,Offset(xc,top-3f),Offset(xc,size.height-top+3f),strokeWidth=5.0f)
                    drawLine(axisColor,Offset(xc,top-3f),Offset(xc,size.height-top+3f),strokeWidth=2.0f)
                }
            }
            Text(
                "MARKERS: BEST ${maaFmt(best.frequencyMHz,6)} MHz / SWR ${maaFmt(best.primary.swr(z0),3)}   •   RES X≈0 ${maaFmt(resonance.frequencyMHz,6)} MHz / X=${maaFmt(resonance.primary.xOhm,2)} Ω   •   R≈${maaFmt(z0,0)} Ω @ ${maaFmt(r50.frequencyMHz,6)} MHz",
                style = MaterialTheme.typography.bodySmall
            )
            Text(bandText, style = MaterialTheme.typography.bodySmall)
            current?.let { (f,r,x) ->
                val g=impedanceToGamma(r,x,z0)
                val gm=g.mag.coerceIn(0.0,0.999999)
                val swr=(1.0+gm)/(1.0-gm)
                Text(
                    "CURSOR ${maaFmt(f,6)} MHz   •   Z=${maaFmt(r,2)} ${if(x>=0) "+" else "−"} j${maaFmt(kotlin.math.abs(x),2)} Ω   •   VSWR=${maaFmt(swr,3)}   •   |Γ|=${maaFmt(gm,4)}   •   ∠Γ=${maaFmt(TouchstoneMath.phaseDeg(g),1)}°",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Text(
                "COLOR KEY: R low→blue / R0→green / high→red • X capacitive→blue, resonance→green, inductive→red • VSWR and |Γ| green→red • phase uses a cyclic hue scale.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}


@Composable
private fun AntennaSmithCard(
    primary: OpenNecFull.InputImpedance,
    inputs: List<OpenNecFull.InputImpedance>,
    z0Ohm: Double,
    sweepPoints: List<OpenNecFull.SweepPoint>,
    sweepRunning: Boolean,
    sweepProgress: Int,
    sweepError: String?,
    onStartSweep: () -> Unit,
    onCancelSweep: () -> Unit
) {
    val gamma = impedanceToGamma(primary.rOhm, primary.xOhm, z0Ohm)
    val sweepGammas = sweepPoints.map { it to impedanceToGamma(it.primary.rOhm, it.primary.xOhm, z0Ohm) }
    val bestSweep = sweepPoints.minByOrNull { it.primary.swr(z0Ohm) }
    var audioSweepPosition by remember(sweepPoints) { mutableStateOf<Double?>(null) }
    var audioMode by remember { mutableStateOf(AntennaAudioMode.COMPLEX_IFFT) }
    var audioVisualMode by remember { mutableStateOf(AntennaAudioMode.COMPLEX_IFFT) }
    val markerColor = MaterialTheme.colorScheme.secondary
    val extraMarkerColor = MaterialTheme.colorScheme.tertiary
    val thresholdColor = MaterialTheme.colorScheme.tertiary
    val sweepColor = MaterialTheme.colorScheme.primary
    val axisColor = MaterialTheme.colorScheme.onSurface
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    val chartBackground = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.32f)
    val surfaceColor = MaterialTheme.colorScheme.surface
    val labelArgb = axisColor.toArgb()

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Smith chart", style = MaterialTheme.typography.titleSmall)
        // 1.19.53: sonification of the antenna's own NEC impedance sweep.
        // Uses the already calculated Smith sweep only; no solver path is changed.
        AntennaSonificationCard(
            sweepPoints = sweepPoints,
            z0Ohm = z0Ohm,
            sweepRunning = sweepRunning,
            onSweepAudioPosition = { audioSweepPosition = it },
            onModeChanged = { audioVisualMode = it }
        )

        // 1.19.101: keep the Smith sweep controls directly above the Smith diagram.
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(
                onClick = onStartSweep,
                modifier = Modifier.weight(1f),
                enabled = !sweepRunning
            ) { Text(if (sweepPoints.isEmpty()) "SWEEP SMITH ±5%" else "RECALCULATE SWEEP") }
            if (sweepRunning) {
                Button(onClick = onCancelSweep) { Text("STOP") }
            }
        }
        if (sweepRunning) {
            LinearProgressIndicator(
                progress = { (sweepProgress.coerceIn(0, 100) / 100f) },
                modifier = Modifier.fillMaxWidth()
            )
            Text("Sweep NEC-2 FULL: $sweepProgress%", style = MaterialTheme.typography.bodySmall)
        }
        sweepError?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

        Card(modifier = Modifier.fillMaxWidth()) {
            Canvas(modifier = Modifier.fillMaxWidth().height(560.dp).padding(2.dp)) {
                drawRoundRect(
                    chartBackground,
                    topLeft = Offset.Zero,
                    size = size,
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(22f, 22f)
                )

                val cx = size.width / 2f
                val cy = size.height / 2f
                val r = min(size.width, size.height) * 0.475f
                val paint = Paint().apply {
                    color = labelArgb
                    textSize = 23f
                    isAntiAlias = true
                }

                drawCircle(surfaceColor.copy(alpha = 0.50f), r, Offset(cx, cy))
                drawCircle(axisColor, r, Offset(cx, cy), style = Stroke(width = 3.0f))
                val smithClip = Path().apply { addOval(Rect(cx - r, cy - r, cx + r, cy + r)) }
                fun pt(g: Cpx) = Offset(cx + (g.re * r).toFloat(), cy - (g.im * r).toFloat())

                clipPath(smithClip) {
                    drawLine(axisColor, Offset(cx - r, cy), Offset(cx + r, cy), strokeWidth = 1.25f)
                    listOf(0.2, 0.5, 1.0, 2.0, 5.0).forEach { rv ->
                        val cr = r / (1.0 + rv).toFloat()
                        val ccx = cx + r * (rv / (1.0 + rv)).toFloat()
                        drawCircle(gridColor, cr, Offset(ccx, cy), style = Stroke(width = 1.35f))
                    }
                    listOf(0.2, 0.5, 1.0, 2.0, 5.0).forEach { xv ->
                        val rr = r / xv.toFloat()
                        val ccx = cx + r
                        drawCircle(gridColor, rr, Offset(ccx, cy - rr), style = Stroke(width = 1.20f))
                        drawCircle(gridColor, rr, Offset(ccx, cy + rr), style = Stroke(width = 1.20f))
                    }
                    drawCircle(
                        thresholdColor.copy(alpha = 0.75f),
                        r / 3f,
                        Offset(cx, cy),
                        style = Stroke(width = 2.1f)
                    )

                    if (sweepGammas.size >= 2) {
                        // 1.19.58: each impedance interval gets a physical color.
                        // Capacitive X<0 = blue/violet, resonance X~0 = green,
                        // inductive X>0 = yellow/red; better match is brighter.
                        for (i in 0 until sweepGammas.lastIndex) {
                            val a = sweepGammas[i]
                            val b = sweepGammas[i + 1]
                            val ga = a.second
                            val gb = b.second
                            if (!ga.re.isFinite() || !ga.im.isFinite() || !gb.re.isFinite() || !gb.im.isFinite()) continue
                            val pa = pt(ga)
                            val pb = pt(gb)
                            val za = a.first.primary
                            val zb = b.first.primary
                            val rr = 0.5 * (za.rOhm + zb.rOhm)
                            val xx = 0.5 * (za.xOhm + zb.xOhm)
                            drawLine(
                                impedanceSweepColor(rr, xx, z0Ohm),
                                pa, pb,
                                strokeWidth = 5.5f,
                                cap = StrokeCap.Round
                            )
                        }
                    }
                }

                drawCircle(axisColor.copy(alpha = 0.85f), 3.8f, Offset(cx, cy))
                drawContext.canvas.nativeCanvas.drawText("${"%.0f".format(z0Ohm)} Ω", cx + 8f, cy - 8f, paint)
                drawContext.canvas.nativeCanvas.drawText("0", cx - r - 22f, cy - 8f, paint)
                drawContext.canvas.nativeCanvas.drawText("∞", cx + r - 8f, cy - 8f, paint)
                drawContext.canvas.nativeCanvas.drawText("+jX", cx - 16f, cy - r - 6f, paint)
                drawContext.canvas.nativeCanvas.drawText("−jX", cx - 16f, cy + r + 24f, paint)
                drawContext.canvas.nativeCanvas.drawText("VSWR 2", cx + r / 3f + 6f, cy - 8f, paint)

                // 1.19.55: audio-synchronized moving marker on the Smith sweep.
                audioSweepPosition?.let { rawU ->
                    if (sweepGammas.size >= 2) {
                        val u = rawU.coerceIn(0.0, 1.0)
                        val x = u * (sweepGammas.size - 1).toDouble()
                        val i0 = kotlin.math.floor(x).toInt().coerceIn(0, sweepGammas.lastIndex)
                        val i1 = (i0 + 1).coerceAtMost(sweepGammas.lastIndex)
                        val t = x - i0.toDouble()

                        val g0 = sweepGammas[i0].second
                        val g1 = sweepGammas[i1].second
                        val gi = Cpx(
                            g0.re + (g1.re - g0.re) * t,
                            g0.im + (g1.im - g0.im) * t
                        )
                        val p = pt(gi)

                        val f0 = sweepGammas[i0].first.frequencyMHz
                        val f1 = sweepGammas[i1].first.frequencyMHz
                        val fNow = f0 + (f1 - f0) * t

                        val z0p = sweepGammas[i0].first.primary
                        val z1p = sweepGammas[i1].first.primary
                        val rNow = z0p.rOhm + (z1p.rOhm - z0p.rOhm) * t
                        val xNow = z0p.xOhm + (z1p.xOhm - z0p.xOhm) * t
                        val liveColor = impedanceSweepColor(rNow, xNow, z0Ohm)

                        // Halo + palette-colored point makes audio position visible.
                        drawCircle(surfaceColor, 14.0f, p)
                        drawCircle(liveColor, 9.5f, p)
                        drawCircle(axisColor, 2.6f, p)
                        drawContext.canvas.nativeCanvas.drawText(
                            "${maaFmt(fNow, 4)} MHz",
                            p.x + 10f,
                            p.y - 10f,
                            paint
                        )
                    }
                }

                if (sweepGammas.size >= 2) {
                    val first = sweepGammas.first()
                    val last = sweepGammas.last()
                    val pf = pt(first.second)
                    val pl = pt(last.second)
                    drawCircle(surfaceColor, 6.5f, pf)
                    drawCircle(sweepColor, 4.0f, pf)
                    drawCircle(surfaceColor, 6.5f, pl)
                    drawCircle(sweepColor, 4.0f, pl)
                    drawContext.canvas.nativeCanvas.drawText("−5%", pf.x + 7f, pf.y - 6f, paint)
                    drawContext.canvas.nativeCanvas.drawText("+5%", pl.x + 7f, pl.y - 6f, paint)
                }

                bestSweep?.let { best ->
                    val bp = pt(impedanceToGamma(best.primary.rOhm, best.primary.xOhm, z0Ohm))
                    drawCircle(surfaceColor, 8f, bp)
                    drawCircle(extraMarkerColor, 5.2f, bp)
                    drawContext.canvas.nativeCanvas.drawText("MIN", bp.x + 8f, bp.y - 7f, paint)
                }

                if (inputs.size > 1) {
                    inputs.drop(1).take(3).forEachIndexed { idx, input ->
                        val p = pt(impedanceToGamma(input.rOhm, input.xOhm, z0Ohm))
                        drawCircle(surfaceColor, 7f, p)
                        drawCircle(extraMarkerColor.copy(alpha = 0.75f), 4.8f, p)
                        drawContext.canvas.nativeCanvas.drawText("M${idx + 2}", p.x + 8f, p.y - 7f, paint)
                    }
                }

                val q = pt(gamma)
                drawCircle(surfaceColor, 10f, q)
                drawCircle(markerColor, 6.8f, q)
                drawContext.canvas.nativeCanvas.drawText("M1", q.x + 8f, q.y - 7f, paint)
            }
        }

    }
}


private fun impedanceToGamma(rOhm: Double, xOhm: Double, z0Ohm: Double): Cpx {
    val z0 = z0Ohm.coerceAtLeast(1e-9)
    val num = Cpx(rOhm - z0, xOhm)
    val den = Cpx(rOhm + z0, xOhm)
    if (den.mag < 1e-15) return Cpx(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY)
    return num / den
}

private fun maaFmt(v: Double, digits: Int = 3): String =
    if (v.isFinite()) "% .${digits}f".format(v).trim() else "∞"


private fun format3DStep(stepDeg: Double): String =
    if (kotlin.math.abs(stepDeg - kotlin.math.round(stepDeg)) < 1e-9) "%.0f".format(stepDeg) else "%.1f".format(stepDeg).replace('.', ',')
