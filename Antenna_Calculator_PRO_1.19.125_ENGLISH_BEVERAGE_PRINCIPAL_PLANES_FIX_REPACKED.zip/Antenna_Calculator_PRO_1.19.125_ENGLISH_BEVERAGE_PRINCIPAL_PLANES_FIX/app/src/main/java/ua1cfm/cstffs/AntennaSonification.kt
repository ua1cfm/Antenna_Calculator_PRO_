package ua1cfm.cstffs

import android.media.*
import android.os.*
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.concurrent.thread
import kotlin.math.*

enum class AntennaAudioMode(val label:String) {
    COMPLEX_IFFT("Complex IFFT"), FREQUENCY_SWEEP("Frequency Sweep"),
    PHASE_AUDIO("Phase Audio"), GROUP_DELAY("Group Delay Audio"),
    RX_DUAL_TONE("R/X Dual Tone"),
    A_BEACON("A Beacon"),
    COLOR_IMPEDANCE("A/V Color Impedance"),
    HRTF_SMITH("3D HRTF Smith")
}
private data class ASpec(val f:DoubleArray,val re:DoubleArray,val im:DoubleArray,val mag:DoubleArray,val ph:DoubleArray)

private class AntennaAudio4Player(private val context: Context) {
    @Volatile private var fullKemar: FullKemarHrtf? = null
    private fun kemar(): FullKemarHrtf {
        val current = fullKemar
        if (current != null) return current
        val created = FullKemarHrtf(context.applicationContext)
        fullKemar = created
        return created
    }
    @Volatile private var gen=0
    @Volatile private var track:AudioTrack?=null
    fun stop(){ gen++; val t=track; track=null; runCatching{t?.stop()}; runCatching{t?.release()} }

    fun play(
        mode:AntennaAudioMode,
        pts:List<OpenNecFull.SweepPoint>,
        z0:Double,
        speed:Double,
        status:(String)->Unit,
        onPosition:(Double?)->Unit
    ){
        stop(); onPosition(null); val g=gen
        val q=pts.filter{it.frequencyMHz.isFinite()&&it.inputs.isNotEmpty()}.sortedBy{it.frequencyMHz}
        if(q.size<2){status("Run SWEEP SMITH ±5% first");return}
        status("Preparing ${mode.label}…")
        thread(isDaemon=true){
            try{
                val spec=spec(q,z0)
                val safeSpeed=speed.coerceIn(0.25,2.0)
                val durationSeconds=6.0/safeSpeed
                val pcm=when(mode){
                    AntennaAudioMode.COMPLEX_IFFT->ifftAudio(spec,6.0)
                    AntennaAudioMode.FREQUENCY_SWEEP->sweepAudio(spec,durationSeconds)
                    AntennaAudioMode.PHASE_AUDIO->phaseAudio(spec,durationSeconds)
                    AntennaAudioMode.GROUP_DELAY->delayAudio(spec,durationSeconds)
                    AntennaAudioMode.RX_DUAL_TONE->rxDualToneAudio(q,durationSeconds)
                    AntennaAudioMode.A_BEACON->aBeaconAudio(q,durationSeconds)
                    AntennaAudioMode.COLOR_IMPEDANCE->colorImpedanceAudio(q,z0,durationSeconds)
                    AntennaAudioMode.HRTF_SMITH->hrtfSmithAudio(q,z0,durationSeconds)
                }
                if(g==gen) playPcm(pcm,g,mode,status,onPosition)
            }catch(t:Throwable){ if(g==gen) main{status("ANTENNA AUDIO error: ${t.message?:t.javaClass.simpleName}")} }
        }
    }

    private fun spec(p:List<OpenNecFull.SweepPoint>,z0in:Double):ASpec{
        val n=p.size; val f=DoubleArray(n); val re=DoubleArray(n); val im=DoubleArray(n)
        val mag=DoubleArray(n); val ph=DoubleArray(n); val z0=z0in.coerceAtLeast(1e-9)
        for(i in p.indices){
            val z=p[i].primary; f[i]=p[i].frequencyMHz
            val d=(z.rOhm+z0).pow(2)+z.xOhm.pow(2)
            if(d<=1e-30||!d.isFinite()){re[i]=1.0;im[i]=0.0}else{
                re[i]=((z.rOhm-z0)*(z.rOhm+z0)+z.xOhm*z.xOhm)/d
                im[i]=(2.0*z0*z.xOhm)/d
            }
            mag[i]=hypot(re[i],im[i]).coerceAtLeast(1e-15); ph[i]=atan2(im[i],re[i])
        }
        unwrap(ph); return ASpec(f,re,im,mag,ph)
    }

    // Complex Gamma(f) -> uniform spectrum -> Hermitian IFFT -> audible stretched impulse response.
    private fun ifftAudio(s:ASpec,durationSeconds:Double):ShortArray{
        val n=1024; val h=n/2; val r=DoubleArray(n); val ii=DoubleArray(n)
        for(k in 0..h){
            val u=k.toDouble()/h; val w=0.5-0.5*cos(2*PI*u)
            r[k]=interp(s.re,u)*w; ii[k]=interp(s.im,u)*w
        }
        for(k in 1 until h){r[n-k]=r[k];ii[n-k]=-ii[k]}; ii[0]=0.0;ii[h]=0.0
        fft(r,ii,true)
        var pk=0; for(i in r.indices) if(abs(r[i])>abs(r[pk]))pk=i
        val x=DoubleArray(n){r[(it+pk)%n]}; val mx=x.maxOf{abs(it)}.coerceAtLeast(1e-12)
        for(i in x.indices)x[i]/=mx
        return render(durationSeconds){u,frame,sr->
            val v=interp(x,u); val hz=420.0+1180.0*u; val a=.12+.72*abs(v)
            val p=2*PI*hz*frame/sr+(if(v<0)PI else 0.0)
            Pair(a*cos(p),a*sin(p))
        }
    }

    // RF position compressed to 100..10000 Hz; |Gamma| controls loudness.
    private fun sweepAudio(s:ASpec,durationSeconds:Double):ShortArray{
        var acc=0.0
        return render(durationSeconds){u,_,sr->
            val hz=100.0*100.0.pow(u); acc+=2*PI*hz/sr
            val a=.02+.80*interp(s.mag,u).coerceIn(0.0,1.0)
            Pair(a*sin(acc),a*cos(acc))
        }
    }

    // Unwrapped reflection phase -> pitch; wrapped phase -> stereo pan.
    private fun phaseAudio(s:ASpec,durationSeconds:Double):ShortArray{
        val lo=s.ph.minOrNull()?:0.0; val hi=s.ph.maxOrNull()?:1.0; val span=(hi-lo).let{if(abs(it)<1e-12)1.0 else it}
        var acc=0.0
        return render(durationSeconds){u,_,sr->
            val p=interp(s.ph,u); val t=((p-lo)/span).coerceIn(0.0,1.0); val hz=180+2820*t
            acc+=2*PI*hz/sr; val pan=(atan2(sin(p),cos(p))/PI+1)*.5
            val a=.18+.62*interp(s.mag,u).coerceIn(0.0,1.0)
            Pair(a*cos(pan*PI/2)*sin(acc),a*sin(pan*PI/2)*sin(acc))
        }
    }

    // tau = -d(phi)/d(omega), central differences.
    // 1.19.99 unified auditory convention:
    // stronger phase transition / larger |group delay| -> LOWER pitch.
    // Using |tau - median(tau)| removes the sign ambiguity that made measured S1P
    // and NEC sweeps sound inverted around resonance when their phase slopes had
    // opposite signs at the calibration/reference plane.
    private fun delayAudio(s:ASpec,durationSeconds:Double):ShortArray{
        val n=s.f.size; val tau=DoubleArray(n)
        for(i in 0 until n){
            val a=(i-1).coerceAtLeast(0); val b=(i+1).coerceAtMost(n-1)
            val df=(s.f[b]-s.f[a])*1e6
            tau[i]=if(abs(df)>1e-12) -(s.ph[b]-s.ph[a])/(2*PI*df)*1e9 else 0.0
        }

        val tauSorted=tau.sorted()
        fun tauPct(q:Double)=tauSorted[(q*(tauSorted.size-1)).roundToInt().coerceIn(0,tauSorted.lastIndex)]
        val median=tauPct(.50)

        // Auditory cue is the magnitude of the local phase-delay excursion, not its sign.
        val strength=DoubleArray(n){ abs(tau[it]-median) }
        val sorted=strength.sorted()
        fun pct(q:Double)=sorted[(q*(sorted.size-1)).roundToInt().coerceIn(0,sorted.lastIndex)]
        val lo=pct(.05)
        val hi=pct(.95)
        val span=(hi-lo).let{if(abs(it)<1e-12)1.0 else it}

        var acc=0.0
        return render(durationSeconds){u,_,sr->
            val strong=((interp(strength,u).coerceIn(lo,hi)-lo)/span).coerceIn(0.0,1.0)
            // Inverse mapping by design: strongest resonance/phase-delay feature = deepest tone.
            val hz=160.0+3840.0*(1.0-strong)
            acc+=2*PI*hz/sr
            val a=.18+.60*interp(s.mag,u).coerceIn(0.0,1.0)
            Pair(a*sin(acc),a*sin(acc+.35*sin(2*PI*4*u+strong*PI)))
        }
    }


    // Direct impedance sonification: two simultaneous voices.
    // R = low, smooth sine voice. X = brighter harmonic voice.
    // X sign is encoded by pitch band: capacitive below, inductive above.
    private fun rxDualToneAudio(p:List<OpenNecFull.SweepPoint>,durationSeconds:Double):ShortArray{
        val r=DoubleArray(p.size){p[it].primary.rOhm}
        val x=DoubleArray(p.size){p[it].primary.xOhm}

        // Fixed engineering reference ranges make different antennas comparable.
        // Values outside the range are softly clipped only for audio mapping.
        val rRef=200.0
        val xRef=300.0
        var phR=0.0
        var phX=0.0

        return render(durationSeconds){u,_,sr->
            val rv=interp(r,u)
            val xv=interp(x,u)

            // Resistance: 50 ohm sits around 430 Hz.
            // Higher R -> higher pitch and somewhat louder smooth tone.
            val rn=(rv/rRef).coerceIn(0.0,1.0)
            val fR=260.0+680.0*rn
            val aR=0.08+0.40*rn
            phR+=2.0*PI*fR/sr
            if(phR>2.0*PI)phR-=2.0*PI

            // Reactance: near X=0 the bright voice becomes almost silent.
            // Capacitive X<0 uses 1100..1800 Hz.
            // Inductive X>0 uses 2100..3400 Hz.
            val xn=(abs(xv)/xRef).coerceIn(0.0,1.0)
            val fX=if(xv<0.0) 1100.0+700.0*xn else 2100.0+1300.0*xn
            val aX=0.02+0.42*xn
            phX+=2.0*PI*fX/sr
            if(phX>2.0*PI)phX-=2.0*PI

            val smooth=sin(phR)
            val bright=.68*sin(phX)+.22*sin(2.0*phX)+.10*sin(3.0*phX)
            val mix=(aR*smooth+aX*bright)*.72

            // Identical mix in L/R: headphones are not required for this mode.
            Pair(mix,mix)
        }
    }


    // A-BEACON mode:
    // - constant 880 Hz is the audible reference center beacon
    // - R and X are two moving voices around that beacon
    // - each moving voice is limited to exactly one octave below/above A3
    // - timbre changes with distance from the chosen reference values
    //
    // Mapping is deliberately compact and easy to learn by ear.
    private fun aBeaconAudio(p:List<OpenNecFull.SweepPoint>,durationSeconds:Double):ShortArray{
        val r=DoubleArray(p.size){p[it].primary.rOhm}
        val x=DoubleArray(p.size){p[it].primary.xOhm}

        val centerHz=880.0              // A5 beacon center
        val minHz=centerHz/2.0         // 440 Hz
        val maxHz=centerHz*2.0         // 1760 Hz

        // Reference antenna values:
        // R = 50 ohm and X = 0 ohm are both centered on the beacon pitch.
        val rCenter=50.0
        val rSpan=100.0                // +/-100 ohm maps to +/-1 octave
        val xSpan=200.0                // +/-200 ohm maps to +/-1 octave

        var phBeacon=0.0
        var phR=0.0
        var phX=0.0

        fun octaveMap(norm:Double):Double{
            // norm -1..+1 -> one octave down/up around A5.
            val n=norm.coerceIn(-1.0,1.0)
            return (centerHz * 2.0.pow(n)).coerceIn(minHz,maxHz)
        }

        return render(durationSeconds){u,_,sr->
            val rv=interp(r,u)
            val xv=interp(x,u)

            // R=50 ohm gives exactly the same pitch as the beacon.
            val rNorm=((rv-rCenter)/rSpan).coerceIn(-1.0,1.0)
            val fR=octaveMap(rNorm)

            // X=0 gives exactly the same pitch as the beacon.
            val xNorm=(xv/xSpan).coerceIn(-1.0,1.0)
            val fX=octaveMap(xNorm)

            phBeacon+=2.0*PI*centerHz/sr
            phR+=2.0*PI*fR/sr
            phX+=2.0*PI*fX/sr
            if(phBeacon>2.0*PI)phBeacon-=2.0*PI
            if(phR>2.0*PI)phR-=2.0*PI
            if(phX>2.0*PI)phX-=2.0*PI

            // Beacon = clean sine, always audible.
            val beacon=0.18*sin(phBeacon)

            // R voice = warmer / rounder. As R moves away from 50 ohm,
            // a little 2nd harmonic is added.
            val rDist=abs(rNorm)
            val voiceR=(0.82*sin(phR)+0.18*rDist*sin(2.0*phR))
            val ampR=0.20+0.12*rDist

            // X voice = brighter / sharper. Near X=0 it is soft and clean;
            // larger |X| adds 2nd/3rd harmonics and more level.
            val xDist=abs(xNorm)
            val voiceX=(
                0.70*sin(phX)
                +0.20*xDist*sin(2.0*phX)
                +0.10*xDist*sin(3.0*phX)
            )
            val ampX=0.12+0.18*xDist

            // Keep the beacon in both ears. Put R slightly left and X slightly
            // right, while still present in both channels so phone speaker works.
            val left=(beacon + ampR*voiceR + 0.55*ampX*voiceX)*0.78
            val right=(beacon + 0.55*ampR*voiceR + ampX*voiceX)*0.78
            Pair(left,right)
        }
    }



    // A/V COLOR IMPEDANCE mode — deliberately NOT the A-Beacon sound.
    // One continuous voice represents the impedance point:
    //   X -> pitch, 440...1760 Hz with X=0 at 880 Hz.
    //   R relative to Z0 -> timbre and gentle stereo bias.
    //   Match quality |Gamma| -> level: a better match sounds clearer/louder.
    private fun colorImpedanceAudio(p:List<OpenNecFull.SweepPoint>, z0In:Double,durationSeconds:Double):ShortArray{
        val r=DoubleArray(p.size){p[it].primary.rOhm}
        val x=DoubleArray(p.size){p[it].primary.xOhm}
        val z0=z0In.coerceAtLeast(1e-9)
        val centerHz=880.0
        val xSpan=200.0
        val rSpan=150.0
        var ph=0.0

        fun octaveMap(norm:Double):Double =
            (centerHz * 2.0.pow(norm.coerceIn(-1.0,1.0))).coerceIn(440.0,1760.0)

        return render(durationSeconds){u,_,sr->
            val rv=interp(r,u)
            val xv=interp(x,u)
            val xNorm=(xv/xSpan).coerceIn(-1.0,1.0)
            val hz=octaveMap(xNorm)

            val rSigned=((rv-z0)/rSpan).coerceIn(-1.0,1.0)
            val rDist=abs(rSigned)

            val den=(rv+z0).pow(2)+xv.pow(2)
            val gamma=if(den<=1e-30 || !den.isFinite()) 1.0 else {
                val gr=((rv-z0)*(rv+z0)+xv*xv)/den
                val gi=(2.0*z0*xv)/den
                hypot(gr,gi).coerceIn(0.0,1.0)
            }
            val match=1.0-gamma

            ph+=2.0*PI*hz/sr
            if(ph>2.0*PI) ph-=2.0*PI

            // R<Z0 sounds rounder (2nd harmonic), R>Z0 sounds sharper (3rd harmonic).
            val lowR=max(0.0,-rSigned)
            val highR=max(0.0,rSigned)
            val fundamental=sin(ph)
            val second=sin(2.0*ph)
            val third=sin(3.0*ph)
            val voice=(0.84-0.14*rDist)*fundamental + 0.22*lowR*second + 0.24*highR*third

            // Good match is easy to hear; bad match remains audible but softer and rougher.
            val amp=0.14+0.46*match
            val pan=(0.5+0.22*rSigned).coerceIn(0.28,0.72)
            val left=amp*(0.75+0.25*(1.0-pan))*voice
            val right=amp*(0.75+0.25*pan)*voice
            Pair(left,right)
        }
    }



    // 3D HRTF SMITH — full MIT KEMAR measured HRIR renderer.
    // 710 measured directions, stereo 512-tap HRIRs at 44.1 kHz. The measured
    // interaural delays remain inside the HRIRs; no synthetic ITD/ILD is added.
    // Convolution is overlap-add in the frequency domain, with four-neighbour
    // spherical interpolation of the measured HRTFs for each render block.
    private fun hrtfSmithAudio(p:List<OpenNecFull.SweepPoint>, z0In:Double, durationSeconds:Double):ShortArray {
        val z0=z0In.coerceAtLeast(1e-9)
        val gr=DoubleArray(p.size)
        val gi=DoubleArray(p.size)
        for(i in p.indices){
            val z=p[i].primary
            val d=(z.rOhm+z0).pow(2)+z.xOhm.pow(2)
            if(d<=1e-30 || !d.isFinite()){ gr[i]=0.0; gi[i]=0.0 } else {
                gr[i]=((z.rOhm-z0)*(z.rOhm+z0)+z.xOhm*z.xOhm)/d
                gi[i]=(2.0*z0*z.xOhm)/d
            }
        }
        val duration=durationSeconds.coerceIn(3.0,24.0)
        return renderMeasuredHrtf(duration){u->
            val re=interp(gr,u)
            val im=interp(gi,u)
            val mag=hypot(re,im).coerceIn(0.0,0.999999)
            if(mag<1e-6) Pair(0.0,0.0) else {
                // Smith disk -> full sphere. Center is FRONT. Radius controls
                // angular distance from the front (0..180°); Gamma phase chooses
                // which great-circle direction is taken. The rim therefore lands
                // at BACK, making front/back motion much stronger than 1.19.78.
                // Perceptual radial expansion: real antennas often stay near the
                // Smith center, which would otherwise produce only a few degrees
                // of apparent motion. Gamma=0 stays exactly FRONT, while modest
                // mismatch is deliberately expanded over the sphere for audibility.
                val expanded=if(mag<0.008) 0.0 else (mag/0.70).coerceIn(0.0,1.0).pow(0.55)
                val polar=PI*expanded
                val phi=atan2(im,re)
                val x=sin(polar)*cos(phi)      // +right
                val y=sin(polar)*sin(phi)      // +up
                val zf=cos(polar)               // +front
                val az=Math.toDegrees(atan2(x,zf))
                val el=Math.toDegrees(asin(y.coerceIn(-1.0,1.0)))
                Pair(az,el)
            }
        }
    }

    /** Dedicated localization check, independent of the antenna/Smith data. */
    fun playHrtfTest(status:(String)->Unit){
        stop(); val g=gen
        status("Preparing HRTF localization test…")
        thread(isDaemon=true){
            try{
                // Hold each direction long enough to identify it, with a short
                // smooth travel between positions to make the trajectory obvious.
                val dirs=arrayOf(
                    Pair(0.0,0.0),      // FRONT
                    Pair(90.0,0.0),     // RIGHT
                    Pair(180.0,0.0),    // BACK
                    Pair(-90.0,0.0),    // LEFT
                    Pair(0.0,70.0),     // TOP
                    Pair(0.0,-35.0),    // LOW FRONT
                    Pair(0.0,0.0)       // FRONT
                )
                val seg=1.25
                val duration=seg*(dirs.size-1)
                val pcm=renderMeasuredHrtf(duration){u->
                    val x=u.coerceIn(0.0,0.999999)*(dirs.size-1)
                    val i=floor(x).toInt().coerceIn(0,dirs.size-2)
                    val raw=x-i
                    // 70% hold near the start direction, 30% smooth travel.
                    val t=if(raw<0.70) 0.0 else {
                        val q=((raw-0.70)/0.30).coerceIn(0.0,1.0)
                        q*q*(3.0-2.0*q)
                    }
                    val a=dirs[i]; val b=dirs[i+1]
                    var da=b.first-a.first
                    while(da>180.0)da-=360.0
                    while(da< -180.0)da+=360.0
                    Pair(a.first+da*t,a.second+(b.second-a.second)*t)
                }
                if(g==gen) playPcm(pcm,g,AntennaAudioMode.HRTF_SMITH,status){ }
            }catch(t:Throwable){ if(g==gen) main{status("HRTF TEST error: ${t.message?:t.javaClass.simpleName}")} }
        }
    }

    /**
     * High-quality measured-HRIR renderer using block FFT overlap-add.
     * directionAt returns azimuth (0 front, +90 right) and elevation degrees.
     */
    private fun renderMeasuredHrtf(
        durationSeconds:Double,
        directionAt:(Double)->Pair<Double,Double>
    ):ShortArray {
        val h=kemar()
        val sr=FullKemarHrtf.SAMPLE_RATE
        val frames=(sr*durationSeconds).roundToInt().coerceAtLeast(2)
        val block=256
        val fftN=FullKemarHrtf.FFT_SIZE
        val taps=FullKemarHrtf.HRIR_TAPS
        val accL=DoubleArray(frames+taps+block)
        val accR=DoubleArray(frames+taps+block)
        val xRe=DoubleArray(fftN); val xIm=DoubleArray(fftN)
        val lRe=DoubleArray(fftN); val lIm=DoubleArray(fftN)
        val rRe=DoubleArray(fftN); val rIm=DoubleArray(fftN)
        val yLRe=DoubleArray(fftN); val yLIm=DoubleArray(fftN)
        val yRRe=DoubleArray(fftN); val yRIm=DoubleArray(fftN)

        // One stable perceived A5 tone with a deliberately rich harmonic spectrum.
        // The pitch stays at 880 Hz; the upper partials provide pinna cues through 10 kHz.
        val harmonics=intArrayOf(1,2,3,4,5,6,7,8,9,10,11)
        val amps=doubleArrayOf(1.0,.48,.34,.27,.22,.18,.15,.125,.105,.087,.070)
        val phase=DoubleArray(harmonics.size)
        val dry=DoubleArray(frames)
        var noiseState=0x13579BDF
        for(n in 0 until frames){
            var v=0.0
            for(j in harmonics.indices){
                val hz=880.0*harmonics[j]
                if(hz>=sr*0.47) continue
                phase[j]+=2.0*PI*hz/sr
                if(phase[j]>2.0*PI)phase[j]-=2.0*PI
                v+=amps[j]*sin(phase[j])
            }
            // Very low-level deterministic broadband component improves vertical/front-back
            // pinna cues while the sound is still perceived as a single pitched source.
            noiseState=noiseState*1664525+1013904223
            val noise=((noiseState ushr 8) and 0xFFFF)/32768.0-1.0
            dry[n]=0.22*v+0.018*noise
        }

        var start=0
        while(start<frames){
            java.util.Arrays.fill(xRe,0.0); java.util.Arrays.fill(xIm,0.0)
            val valid=minOf(block,frames-start)
            for(i in 0 until valid)xRe[i]=dry[start+i]
            h.fft(xRe,xIm,false)

            val mid=(start+0.5*valid).coerceAtMost(frames-1.0)
            val u=mid/(frames-1).toDouble()
            val (az,el)=directionAt(u)
            h.fillSpectrum(az,el,lRe,lIm,rRe,rIm)

            for(k in 0 until fftN){
                val xr=xRe[k]; val xi=xIm[k]
                yLRe[k]=xr*lRe[k]-xi*lIm[k]
                yLIm[k]=xr*lIm[k]+xi*lRe[k]
                yRRe[k]=xr*rRe[k]-xi*rIm[k]
                yRIm[k]=xr*rIm[k]+xi*rRe[k]
            }
            h.fft(yLRe,yLIm,true); h.fft(yRRe,yRIm,true)
            val convLen=minOf(fftN,valid+taps-1)
            for(i in 0 until convLen){
                val o=start+i
                if(o<accL.size){accL[o]+=yLRe[i];accR[o]+=yRRe[i]}
            }
            start+=block
        }

        // Shared normalization preserves ILD. Do not normalize ears independently.
        var peak=1e-12
        for(i in 0 until frames){peak=max(peak,max(abs(accL[i]),abs(accR[i])))}
        val gain=min(0.84/peak,1.8)
        val edge=(sr*.012).roundToInt().coerceAtLeast(1)
        val out=ShortArray(frames*2)
        for(n in 0 until frames){
            val fade=minOf((n.toDouble()/edge).coerceIn(0.0,1.0),((frames-1-n).toDouble()/edge).coerceIn(0.0,1.0))
            val l=tanh(accL[n]*gain)*0.92*fade
            val r=tanh(accR[n]*gain)*0.92*fade
            out[2*n]=(l*32767.0).roundToInt().coerceIn(-32767,32767).toShort()
            out[2*n+1]=(r*32767.0).roundToInt().coerceIn(-32767,32767).toShort()
        }
        return out
    }

    private fun render(durationSeconds:Double,fn:(Double,Double,Double)->Pair<Double,Double>):ShortArray{
        val sr=44100
        val frames=(sr*durationSeconds.coerceIn(3.0,24.0)).roundToInt().coerceAtLeast(2)
        val out=ShortArray(frames*2); val edge=(sr*.008).roundToInt()
        for(n in 0 until frames){
            val u=n.toDouble()/(frames-1); val (l0,r0)=fn(u,n.toDouble(),sr.toDouble())
            val fade=minOf((n.toDouble()/edge).coerceIn(0.0,1.0),((frames-1-n).toDouble()/edge).coerceIn(0.0,1.0))
            out[2*n]=(l0*fade*32767).roundToInt().coerceIn(-32767,32767).toShort()
            out[2*n+1]=(r0*fade*32767).roundToInt().coerceIn(-32767,32767).toShort()
        }; return out
    }
    private fun interp(a:DoubleArray,u:Double):Double{
        if(a.size==1)return a[0]; val x=u.coerceIn(0.0,1.0)*(a.size-1); val i=floor(x).toInt(); val j=(i+1).coerceAtMost(a.lastIndex)
        return a[i]+(a[j]-a[i])*(x-i)
    }
    private fun unwrap(a:DoubleArray){var off=0.0;var prev=a[0];for(i in 1 until a.size){val raw=a[i];val d=raw-prev;if(d>PI)off-=2*PI else if(d< -PI)off+=2*PI;a[i]=raw+off;prev=raw}}
    private fun fft(r:DoubleArray,i:DoubleArray,inv:Boolean){
        val n=r.size;var j=0
        for(a in 1 until n){var b=n shr 1;while(j and b !=0){j=j xor b;b=b shr 1};j=j xor b;if(a<j){val x=r[a];r[a]=r[j];r[j]=x;val y=i[a];i[a]=i[j];i[j]=y}}
        var len=2;while(len<=n){val ang=(if(inv)2 else -2)*PI/len;val cr=cos(ang);val ci=sin(ang);var base=0
            while(base<n){var wr=1.0;var wi=0.0;for(k in 0 until len/2){val ur=r[base+k];val ui=i[base+k];val vr=r[base+k+len/2]*wr-i[base+k+len/2]*wi;val vi=r[base+k+len/2]*wi+i[base+k+len/2]*wr;r[base+k]=ur+vr;i[base+k]=ui+vi;r[base+k+len/2]=ur-vr;i[base+k+len/2]=ui-vi;val nw=wr*cr-wi*ci;wi=wr*ci+wi*cr;wr=nw};base+=len};len=len shl 1}
        if(inv)for(k in 0 until n){r[k]/=n;i[k]/=n}
    }
    private fun playPcm(
        pcm:ShortArray,
        g:Int,
        mode:AntennaAudioMode,
        status:(String)->Unit,
        onPosition:(Double?)->Unit
    ){
        val sr=44100
        val totalFrames=pcm.size/2
        val min=AudioTrack.getMinBufferSize(
            sr,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)

        val t=AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(max(min,16384))
            .build()

        if(g!=gen){t.release();return}
        track=t
        main{
            status("Playing…")
            if(mode==AntennaAudioMode.COMPLEX_IFFT) onPosition(null) else onPosition(0.0)
        }
        t.play()

        // Feed audio in small chunks. The visible Smith marker is driven from
        // AudioTrack.playbackHeadPosition, not from how fast data is written.
        var o=0
        val chunkShorts=2048*2
        while(o<pcm.size && g==gen){
            val count=minOf(chunkShorts, pcm.size-o)
            val w=t.write(pcm,o,count,AudioTrack.WRITE_BLOCKING)
            if(w<=0) break
            o+=w
            if(mode!=AntennaAudioMode.COMPLEX_IFFT){
                val played=t.playbackHeadPosition.toLong().coerceAtLeast(0L)
                val u=(played.toDouble()/totalFrames.coerceAtLeast(1).toDouble()).coerceIn(0.0,1.0)
                main{onPosition(u)}
            }
        }

        // Wait for the queued sound to be heard, updating the marker against
        // the actual playback head. This also avoids cutting off the tail.
        while(g==gen){
            val played=t.playbackHeadPosition.toLong().coerceAtLeast(0L)
            if(mode!=AntennaAudioMode.COMPLEX_IFFT){
                val u=(played.toDouble()/totalFrames.coerceAtLeast(1).toDouble()).coerceIn(0.0,1.0)
                main{onPosition(u)}
            }
            if(played>=totalFrames.toLong()) break
            try{Thread.sleep(20)}catch(_:InterruptedException){break}
        }

        runCatching{t.stop()}
        runCatching{t.release()}
        if(track===t)track=null
        if(g==gen)main{
            onPosition(null)
            status("ANTENNA AUDIO ready")
        }
    }
    private fun main(f:()->Unit){Handler(Looper.getMainLooper()).post(f)}
}

@Composable
fun AntennaSonificationCard(
    sweepPoints:List<OpenNecFull.SweepPoint>,
    z0Ohm:Double,
    sweepRunning:Boolean,
    onSweepAudioPosition:(Double?)->Unit,
    onModeChanged:(AntennaAudioMode)->Unit = {}
){
    val context=LocalContext.current
    val player=remember(context){AntennaAudio4Player(context.applicationContext)};var mode by remember{mutableStateOf(AntennaAudioMode.COMPLEX_IFFT)}
    var sweepSpeed by remember{mutableStateOf(1.0)}
    var status by remember(sweepPoints.size,sweepRunning){mutableStateOf(if(sweepRunning)"Waiting for NEC sweep…" else if(sweepPoints.size>=2)"ANTENNA AUDIO ready • ${sweepPoints.size} points" else "Run SWEEP SMITH ±5% first")}
    LaunchedEffect(mode){ onModeChanged(mode) }
    DisposableEffect(player){onDispose{player.stop();onSweepAudioPosition(null)}};val ready=sweepPoints.size>=2&&!sweepRunning
    Card(Modifier.fillMaxWidth()){Column(Modifier.padding(10.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
        Text("ANTENNA AUDIO/VISUAL — 8 MODES",style=MaterialTheme.typography.titleSmall)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
            Button({mode=AntennaAudioMode.COMPLEX_IFFT},Modifier.weight(1f)){Text(if(mode==AntennaAudioMode.COMPLEX_IFFT)"✓ IFFT" else "IFFT")}
            Button({mode=AntennaAudioMode.FREQUENCY_SWEEP},Modifier.weight(1f)){Text(if(mode==AntennaAudioMode.FREQUENCY_SWEEP)"✓ SWEEP" else "SWEEP")}
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
            Button({mode=AntennaAudioMode.PHASE_AUDIO},Modifier.weight(1f)){Text(if(mode==AntennaAudioMode.PHASE_AUDIO)"✓ PHASE" else "PHASE")}
            Button({mode=AntennaAudioMode.GROUP_DELAY},Modifier.weight(1f)){Text(if(mode==AntennaAudioMode.GROUP_DELAY)"✓ DELAY" else "DELAY")}
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
            Button({mode=AntennaAudioMode.RX_DUAL_TONE},Modifier.fillMaxWidth()){Text(if(mode==AntennaAudioMode.RX_DUAL_TONE)"✓ R/X DUAL TONE" else "R/X DUAL TONE")}
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
            Button({mode=AntennaAudioMode.A_BEACON},Modifier.fillMaxWidth()){Text(if(mode==AntennaAudioMode.A_BEACON)"✓ A BEACON" else "A BEACON")}
        }
        if(mode==AntennaAudioMode.A_BEACON){
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                Text("440 Hz",style=MaterialTheme.typography.bodySmall)
                Text("880 Hz • BEACON",style=MaterialTheme.typography.bodySmall)
                Text("1760 Hz",style=MaterialTheme.typography.bodySmall)
            }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
            Button({mode=AntennaAudioMode.COLOR_IMPEDANCE},Modifier.fillMaxWidth()){Text(if(mode==AntennaAudioMode.COLOR_IMPEDANCE)"✓ A/V COLOR IMPEDANCE" else "A/V COLOR IMPEDANCE")}
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
            Button({mode=AntennaAudioMode.HRTF_SMITH},Modifier.fillMaxWidth()){Text(if(mode==AntennaAudioMode.HRTF_SMITH)"✓ 3D HRTF SMITH" else "3D HRTF SMITH")}
        }
        Text(when(mode){
            AntennaAudioMode.COMPLEX_IFFT->"Complex IFFT: amplitude + phase → band-limited impulse response → sound."
            AntennaAudioMode.FREQUENCY_SWEEP->"Frequency Sweep: RF span → 100–10000 Hz; |Γ| controls loudness."
            AntennaAudioMode.PHASE_AUDIO->"Phase Audio: ∠Γ controls pitch and stereo position."
            AntennaAudioMode.GROUP_DELAY->"Group Delay: stronger |τ| / phase-delay feature = lower pitch; same cue for NEC and measured S1P."
            AntennaAudioMode.RX_DUAL_TONE->"R/X Dual Tone: smooth low voice = resistance R; bright high voice = reactance X. X≈0 makes the bright voice nearly disappear."
            AntennaAudioMode.A_BEACON->"A Beacon: constant A5 (880 Hz) is the center reference. R and X move from 440 to 1760 Hz around it; timbre changes with deviation."
            AntennaAudioMode.COLOR_IMPEDANCE->"A/V Color Impedance: independent one-voice mode. X controls pitch (440–1760 Hz, 880 Hz at X≈0); R controls timbre; better match sounds clearer/louder. Smith color remains synchronized."
            AntennaAudioMode.HRTF_SMITH->"3D HRTF Smith: HEADPHONES. Full MIT KEMAR: 710 measured directions × stereo 512-tap HRIR. Center Smith = FRONT; moving toward the rim moves the source toward BACK; Γ phase chooses the path around the head."
        },style=MaterialTheme.typography.bodySmall)
        if(mode==AntennaAudioMode.HRTF_SMITH){
            Button(
                onClick={ player.playHrtfTest{status=it} },
                modifier=Modifier.fillMaxWidth(),
                enabled=!sweepRunning
            ){Text("HRTF TEST • FRONT → RIGHT → BACK → LEFT → TOP")}
        }
        if(mode!=AntennaAudioMode.COMPLEX_IFFT){
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                listOf(0.25,0.5,1.0,2.0).forEach{v->
                    Button(
                        onClick={sweepSpeed=v},
                        modifier=Modifier.weight(1f),
                        contentPadding=PaddingValues(horizontal=4.dp,vertical=6.dp)
                    ){Text(if(kotlin.math.abs(sweepSpeed-v)<1e-9) "✓ ${v}×" else "${v}×")}
                }
            }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
            Button({
                player.play(
                    mode=mode,
                    pts=sweepPoints,
                    z0=z0Ohm,
                    speed=sweepSpeed,
                    status={status=it},
                    onPosition=onSweepAudioPosition
                )
            },Modifier.weight(1f),enabled=ready){Text("PLAY")}
            Button({
                player.stop()
                onSweepAudioPosition(null)
                status="ANTENNA AUDIO stopped"
            },Modifier.weight(1f)){Text("STOP")}
        }
    }}
}
