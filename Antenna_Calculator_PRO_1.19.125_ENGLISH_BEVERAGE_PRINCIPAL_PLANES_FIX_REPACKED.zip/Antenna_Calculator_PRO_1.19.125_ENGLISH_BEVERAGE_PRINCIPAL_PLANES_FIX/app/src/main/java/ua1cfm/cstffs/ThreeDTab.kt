package ua1cfm.cstffs

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun ThreeDAndExportTab(dish: DishResult?, ffs: FfsResult?) {
    val context = LocalContext.current
    var systemMode by remember { mutableStateOf(false) }
    var pendingPngState by remember { mutableStateOf<View3DState?>(null) }
    var message by remember { mutableStateOf("") }

    val txtLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && dish != null && ffs != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
                    it.write(ExportUtils.resultsText(dish, ffs))
                } ?: error("Failed to open file for writing")
            }.onSuccess { message = "TXT saved." }
                .onFailure { message = "TXT error: ${it.message}" }
        }
    }

    val csvLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null && ffs != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
                    it.write(ExportUtils.patternCsv(ffs))
                } ?: error("Failed to open file for writing")
            }.onSuccess { message = "CSV saved." }
                .onFailure { message = "CSV error: ${it.message}" }
        }
    }

    val pngLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("image/png")
    ) { uri ->
        val state = pendingPngState
        if (uri != null && state != null && dish != null && ffs != null) {
            val points = if (systemMode) buildSystemPattern3D(dish, ffs) else ffs.surface3D
            runCatching {
                val bitmap = renderRadiation3DPng(points, state)
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) error("PNG encoder error")
                } ?: error("Failed to open file for writing")
                bitmap.recycle()
            }.onSuccess { message = "3D-pattern PNG saved." }
                .onFailure { message = "PNG error: ${it.message}" }
        }
        pendingPngState = null
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("3D pattern", style = MaterialTheme.typography.headlineSmall)
        if (dish == null || ffs == null) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Text("First run an FFS calculation on the ‘Calculation’ tab.", modifier = Modifier.padding(12.dp))
            }
            return@Column
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceButton("FFS", !systemMode) { systemMode = false }
            ChoiceButton("System", systemMode) { systemMode = true }
        }

        val systemPoints = remember(
            dish.diameterM, dish.focalM, dish.wavelengthM,
            ffs.selectedFrequencyGHz, ffs.apertureIllumination
        ) { buildSystemPattern3D(dish, ffs) }

        val points = if (systemMode) systemPoints else ffs.surface3D

        val systemApertureEfficiency = if (ffs.spilloverEfficiency != null && ffs.taperEfficiency != null) {
            (ffs.spilloverEfficiency * ffs.taperEfficiency * dish.ruzeEfficiency).coerceIn(0.0, 1.0)
        } else null
        val systemDirectivityDbi = systemApertureEfficiency?.let {
            10.0 * kotlin.math.log10(dish.idealDirectivityLinear * it)
        }
        val systemGainDbi = if (systemDirectivityDbi != null && ffs.radiationEfficiency != null && ffs.radiationEfficiency > 0.0) {
            systemDirectivityDbi + 10.0 * kotlin.math.log10(ffs.radiationEfficiency)
        } else null

        val absolutePeakDbi = if (systemMode) {
            systemGainDbi ?: systemDirectivityDbi
        } else {
            if (ffs.radiationEfficiency != null && ffs.radiationEfficiency > 0.0) ffs.gainDbi else ffs.directivityDbi
        }
        val absolutePeakLabel = if (systemMode) {
            if (systemGainDbi != null) "Gmax" else "Dmax"
        } else {
            if (ffs.radiationEfficiency != null && ffs.radiationEfficiency > 0.0) "Gmax" else "Dmax"
        }
        val peakTheta = if (systemMode) 0.0 else ffs.peakThetaDeg
        val peakPhi = if (systemMode) 0.0 else ffs.peakPhiDeg

        val subtitle = if (systemMode) {
            "Axisymmetrized aperture model based on the actual FFS: the feed field is mapped to the aperture ρ=2F·tan(θ/2), then the far field is calculated using the Hankel J₀ integral. Feed taper affects the main- and sidelobe shape."
        } else {
            val spread = azimuthSpreadAtTheta(ffs.surface3D, ffs.peakThetaDeg)
            buildString {
                append("Actual 3D shape of the selected CST FFS block (${ffs.surface3D.size} display nodes; integrals use the full ${ffs.usedSampleCount}-point grid). ")
                if (ffs.peakThetaDeg != null && ffs.peakPhiDeg != null) {
                    append("Maximum: θ=${"%.1f".format(ffs.peakThetaDeg)}°, φ=${"%.1f".format(ffs.peakPhiDeg)}°. ")
                }
                if (spread != null && spread < 0.5) append("Near the maximum, the pattern is almost axisymmetric in φ (spread ≈ ${"%.2f".format(spread)} dB). ")
                append("For FFS, linear amplitude radius is selected by default; dB mode can be enabled manually.")
            }
        }

        Radiation3DCard(
            title = if (systemMode) "Feed + paraboloid system" else "Feed FFS",
            points = points,
            subtitle = subtitle,
            initialRadiusScale = if (systemMode) Radius3DScale.DB else Radius3DScale.LINEAR,
            absolutePeakDbi = absolutePeakDbi,
            absolutePeakLabel = absolutePeakLabel,
            peakThetaDeg = peakTheta,
            peakPhiDeg = peakPhi,
            onExportPng = { state ->
                pendingPngState = state
                pngLauncher.launch(if (systemMode) "CST_FFS_system_3D_surface.png" else "CST_FFS_feed_3D_surface.png")
            }
        )

        if (systemMode) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "The system model uses amplitude illumination from the FFS and paraboloid geometry. Phase center/phase errors, support blockage, and cross-polarization are not yet included in this 3D shape.",
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Export", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Button(onClick = { txtLauncher.launch("CST_FFS_results.txt") }) { Text("TXT") }
                    Button(onClick = { csvLauncher.launch("CST_FFS_3D.csv") }) { Text("CSV") }
                }
                Text("The PNG button saves the current 3D view and selected display mode.", style = MaterialTheme.typography.bodySmall)
                if (message.isNotEmpty()) Text(message, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ChoiceButton(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) Button(onClick = onClick) { Text(label, maxLines = 1) }
    else OutlinedButton(onClick = onClick) { Text(label, maxLines = 1) }
}

private fun azimuthSpreadAtTheta(points: List<Pattern3DPoint>, thetaDeg: Double?): Double? {
    if (thetaDeg == null || points.isEmpty()) return null
    val nearestTheta = points.minByOrNull { kotlin.math.abs(it.thetaDeg - thetaDeg) }?.thetaDeg ?: return null
    val row = points.filter { kotlin.math.abs(it.thetaDeg - nearestTheta) < 1.0e-6 }
    if (row.size < 2) return null
    return (row.maxOf { it.db } - row.minOf { it.db }).coerceAtLeast(0.0)
}
