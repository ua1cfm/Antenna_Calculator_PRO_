package ua1cfm.cstffs

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Geometry-only helpers for drawing the physical antenna inside a Near Field slice. */
object NearFieldSliceGeometry {
    data class Segment3(
        val x1: Double, val y1: Double, val z1: Double,
        val x2: Double, val y2: Double, val z2: Double
    )

    fun fixedCoordinate(plane: NearFieldEngine.Plane, x: Double, y: Double, z: Double): Double = when (plane) {
        NearFieldEngine.Plane.XY -> z
        NearFieldEngine.Plane.XZ -> y
        NearFieldEngine.Plane.YZ -> x
    }

    /**
     * Clip one physical wire to a thin slab around the selected plane.
     * Returns null when the wire does not belong to/cross the slice.
     */
    fun clipWireToSlice(
        wire: MaaWire,
        plane: NearFieldEngine.Plane,
        fixedCoordinateM: Double,
        zShiftM: Double,
        sliceCellM: Double
    ): Segment3? {
        val x1 = wire.x1; val y1 = wire.y1; val z1 = wire.z1 + zShiftM
        val x2 = wire.x2; val y2 = wire.y2; val z2 = wire.z2 + zShiftM
        val d1 = fixedCoordinate(plane, x1, y1, z1) - fixedCoordinateM
        val d2 = fixedCoordinate(plane, x2, y2, z2) - fixedCoordinateM
        val tol = max(max(2.5 * wire.radiusM, 0.55 * sliceCellM), 1e-6)
        val dd = d2 - d1
        var t0 = 0.0
        var t1 = 1.0
        if (abs(dd) < 1e-15) {
            if (abs(d1) > tol) return null
        } else {
            val ta = (-tol - d1) / dd
            val tb = ( tol - d1) / dd
            t0 = max(0.0, min(ta, tb))
            t1 = min(1.0, max(ta, tb))
            if (t0 > t1) return null
        }
        fun lerp(a: Double, b: Double, t: Double) = a + (b - a) * t
        return Segment3(
            lerp(x1, x2, t0), lerp(y1, y2, t0), lerp(z1, z2, t0),
            lerp(x1, x2, t1), lerp(y1, y2, t1), lerp(z1, z2, t1)
        )
    }
}
