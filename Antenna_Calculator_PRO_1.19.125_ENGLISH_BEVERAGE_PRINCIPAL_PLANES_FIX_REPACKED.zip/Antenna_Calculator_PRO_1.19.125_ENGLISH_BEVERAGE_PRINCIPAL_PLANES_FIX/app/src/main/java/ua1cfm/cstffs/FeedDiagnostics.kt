package ua1cfm.cstffs

import kotlin.math.abs

data class CutDiagnostics(
    val peakThetaDeg: Double,
    val peakDb: Double,
    val hpbwDeg: Double?,
    val left3DbDeg: Double?,
    val right3DbDeg: Double?,
    val highestSideLobeDb: Double?,
    val sideLobeRelativeDb: Double?
)

data class FeedDiagnostics(
    val e: CutDiagnostics?,
    val h: CutDiagnostics?,
    val beamwidthDifferenceDeg: Double?,
    val peakThetaDifferenceDeg: Double?
)

object FeedDiagnosticsMath {
    fun analyze(result: FfsResult): FeedDiagnostics {
        val e = analyzeCut(result.ePlane)
        val h = analyzeCut(result.hPlane)
        return FeedDiagnostics(
            e = e,
            h = h,
            beamwidthDifferenceDeg = if (e?.hpbwDeg != null && h?.hpbwDeg != null) abs(e.hpbwDeg - h.hpbwDeg) else null,
            peakThetaDifferenceDeg = if (e != null && h != null) abs(e.peakThetaDeg - h.peakThetaDeg) else null
        )
    }

    fun valueAt(points: List<PatternPoint>, thetaDeg: Double): Double? {
        if (points.isEmpty()) return null
        val p = points.sortedBy { it.thetaDeg }
        if (thetaDeg <= p.first().thetaDeg) return p.first().db
        if (thetaDeg >= p.last().thetaDeg) return p.last().db
        val hi = p.indexOfFirst { it.thetaDeg >= thetaDeg }
        if (hi <= 0) return p.first().db
        val a = p[hi - 1]; val b = p[hi]
        val t = (thetaDeg - a.thetaDeg) / (b.thetaDeg - a.thetaDeg).coerceAtLeast(1e-12)
        return a.db + (b.db - a.db) * t
    }

    private fun analyzeCut(raw: List<PatternPoint>): CutDiagnostics? {
        if (raw.size < 5) return null
        val p = raw.sortedBy { it.thetaDeg }
        val peakIndex = p.indices.maxByOrNull { p[it].db } ?: return null
        val peak = p[peakIndex]
        val threshold = peak.db - 3.0

        fun interpolate(a: PatternPoint, b: PatternPoint, y: Double): Double {
            if (b.db == a.db) return a.thetaDeg
            val t = ((y - a.db) / (b.db - a.db)).coerceIn(0.0, 1.0)
            return a.thetaDeg + (b.thetaDeg - a.thetaDeg) * t
        }

        var li: Int? = null
        for (i in peakIndex downTo 1) {
            if (p[i - 1].db < threshold && p[i].db >= threshold) { li = i; break }
        }
        var ri: Int? = null
        for (i in peakIndex until p.lastIndex) {
            if (p[i].db >= threshold && p[i + 1].db < threshold) { ri = i; break }
        }
        val left = li?.let { interpolate(p[it - 1], p[it], threshold) }
        val right = ri?.let { interpolate(p[it], p[it + 1], threshold) }
        val hpbw = if (left != null && right != null && right > left) right - left else null

        // Highest local maximum outside the measured -3 dB main-lobe interval.
        val local = mutableListOf<Int>()
        for (i in 1 until p.lastIndex) {
            if (p[i].db >= p[i - 1].db && p[i].db > p[i + 1].db) local += i
        }
        val side = local
            .filter { idx -> idx != peakIndex && (left == null || p[idx].thetaDeg < left) && (right == null || p[idx].thetaDeg > right) }
            .maxByOrNull { p[it].db }
        val sideDb = side?.let { p[it].db }
        return CutDiagnostics(
            peakThetaDeg = peak.thetaDeg,
            peakDb = peak.db,
            hpbwDeg = hpbw,
            left3DbDeg = left,
            right3DbDeg = right,
            highestSideLobeDb = sideDb,
            sideLobeRelativeDb = sideDb?.let { it - peak.db }
        )
    }
}
