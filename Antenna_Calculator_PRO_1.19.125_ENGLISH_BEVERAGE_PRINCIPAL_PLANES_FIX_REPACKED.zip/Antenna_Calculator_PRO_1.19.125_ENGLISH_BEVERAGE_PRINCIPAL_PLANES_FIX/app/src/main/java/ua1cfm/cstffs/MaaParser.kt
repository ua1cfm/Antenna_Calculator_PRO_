package ua1cfm.cstffs

import java.io.BufferedReader
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

data class MaaWire(
    val x1: Double, val y1: Double, val z1: Double,
    val x2: Double, val y2: Double, val z2: Double,
    val radiusM: Double,
    val tag: Int
) {
    val midX get() = (x1 + x2) * 0.5
    val midY get() = (y1 + y2) * 0.5
    val midZ get() = (z1 + z2) * 0.5
    val dx get() = x2 - x1
    val dy get() = y2 - y1
    val dz get() = z2 - z1
    val lengthM get() = sqrt(dx * dx + dy * dy + dz * dz)
    val axialFractionX get() = if (lengthM > 1e-12) abs(dx) / lengthM else 0.0
    val transverseFraction get() = if (lengthM > 1e-12) sqrt(dy * dy + dz * dz) / lengthM else 0.0
}

data class MaaLoad(
    val wireIndex: Int,
    val position: Char,
    /** Pulse offset relative to B/C/E, e.g. w1c+1 / w1c-1. */
    val segmentOffset: Int = 0,
    /** MMANA: 0 = LC(Q), 1 = fixed R+jX, 2 = Laplace S load. */
    val kind: Int,
    /** kind 0: L in uH; kind 1: R in ohms. */
    val value1: Double,
    /** kind 0: C in pF; kind 1: X in ohms. */
    val value2: Double,
    /** kind 0: Q. */
    val value3: Double,
    val raw: String
)

data class MaaSource(
    val wireIndex: Int,
    val position: Char,
    /** Pulse offset relative to B/C/E. MMANA compact B1/C1/E2 syntax is normalized here. */
    val segmentOffset: Int = 0,
    /** MMANA source phase in degrees. */
    val phaseDeg: Double = 0.0,
    /** MMANA relative source voltage amplitude. */
    val amplitude: Double = 1.0,
    val raw: String = ""
)

data class MaaModel(
    val title: String,
    val frequencyMHz: Double,
    val wires: List<MaaWire>,
    val sourceWireIndex: Int?,
    val sourceDescription: String?,
    val loads: List<MaaLoad>,
    val segmentationDescription: String?,
    val rawWireCount: Int,
    val referenceImpedanceOhms: Double? = null,
    val fileNameHint: String? = null,
    /** All MMANA excitation sources. Legacy sourceWireIndex/sourceDescription mirror sources.firstOrNull(). */
    val sources: List<MaaSource> = emptyList(),
    /** MMANA G field: 0=free space, 1=perfect ground, 2=real ground. */
    val groundType: Int = 0,
    /** MMANA H field: Add height in metres. */
    val addHeightM: Double = 0.0,
    /** MMANA M field: material selector. */
    val materialCode: Int = 0
) {
    val wavelengthM: Double get() = 299.792458 / frequencyMHz
    val totalWireLengthM: Double get() = wires.sumOf { it.lengthM }

    val minX get() = wires.minOfOrNull { min(it.x1, it.x2) } ?: 0.0
    val maxX get() = wires.maxOfOrNull { max(it.x1, it.x2) } ?: 0.0
    val minY get() = wires.minOfOrNull { min(it.y1, it.y2) } ?: 0.0
    val maxY get() = wires.maxOfOrNull { max(it.y1, it.y2) } ?: 0.0
    val minZ get() = wires.minOfOrNull { min(it.z1, it.z2) } ?: 0.0
    val maxZ get() = wires.maxOfOrNull { max(it.z1, it.z2) } ?: 0.0

    val spanX get() = maxX - minX
    val spanY get() = maxY - minY
    val spanZ get() = maxZ - minZ
    val boomLengthM get() = spanX
    val transverseSizeM get() = max(spanY, spanZ)

    /** Main geometric axis. Yagi/LPDA are normally X; axial-mode helices are normally Z. */
    val mainAxis: Char get() = when {
        spanZ > spanX * 1.35 && spanZ > spanY * 1.35 -> 'Z'
        spanY > spanX * 1.35 && spanY > spanZ * 1.35 -> 'Y'
        else -> 'X'
    }

    val isPlanar: Boolean get() {
        val largest = maxOf(spanX, spanY, spanZ)
        val smallest = minOf(spanX, spanY, spanZ)
        return largest > 1e-6 && smallest <= largest * 0.02
    }

    /** Normal to a clearly planar antenna. Useful for loop/delta/halo broadside preview. */
    val planeNormalAxis: Char? get() {
        if (!isPlanar) return null
        return when {
            spanX <= spanY && spanX <= spanZ -> 'X'
            spanY <= spanX && spanY <= spanZ -> 'Y'
            else -> 'Z'
        }
    }


    /** Dominant axis of the driven wire, if the source is a nearly straight axial segment. */
    val sourceAxis: Char? get() {
        val idx = sourceWireIndex ?: return null
        val w = wires.getOrNull(idx) ?: return null
        val len = w.lengthM
        if (len <= 1e-9) return null
        val fx = abs(w.dx) / len
        val fy = abs(w.dy) / len
        val fz = abs(w.dz) / len
        val best = maxOf(fx, fy, fz)
        if (best < 0.92) return null
        return when (best) {
            fx -> 'X'
            fy -> 'Y'
            else -> 'Z'
        }
    }

    /**
     * Axis of rotationally symmetric omni structures such as a discone.
     * Strong title evidence is accepted, otherwise require a driven axial wire and
     * comparable transverse spans so ordinary Yagis/loops are not captured.
     */
    val omniSymmetryAxis: Char? get() {
        val titleHint = title.contains("discon", ignoreCase = true) ||
            title.contains("diskon", ignoreCase = true) ||
            title.contains("дискон", ignoreCase = true)
        val a = sourceAxis ?: return null
        fun span(axis: Char): Double = when (axis) {
            'X' -> spanX
            'Y' -> spanY
            else -> spanZ
        }
        val transverse = listOf('X','Y','Z').filter { it != a }.map(::span)
        val tMax = transverse.maxOrNull() ?: 0.0
        val tMin = transverse.minOrNull() ?: 0.0
        val radialEnough = wires.size >= 8 && tMax > 1e-6 && tMin / tMax >= 0.70
        val sourceShort = sourceWireIndex?.let { wires.getOrNull(it)?.lengthM }?.let {
            it <= maxOf(spanX, spanY, spanZ) * 0.35
        } ?: false
        // 1.17.8: generic radial heuristics produced false positives for Hentenna, Twin-Delta
        // and Split-J models.  Discone-specific field handling is now deliberately conservative:
        // use explicit title evidence; other omni families are classified separately.
        return if (titleHint) a else null
    }

    private fun axialDelta(w: MaaWire): Double = when (mainAxis) { 'Y' -> w.dy; 'Z' -> w.dz; else -> w.dx }
    private fun stationCoord(w: MaaWire): Double = when (mainAxis) { 'Y' -> w.midY; 'Z' -> w.midZ; else -> w.midX }
    private fun axisSpan(): Double = when (mainAxis) { 'Y' -> spanY; 'Z' -> spanZ; else -> spanX }

    /**
     * Geometry stations along the actual main axis. For Yagi/LPDA this remains X. For a helix
     * the larger Z extent is detected and the turns are sampled along Z, so the preview does not
     * disappear or point along the wrong axis.
     */
    val elementStationsM: List<Double> get() {
        val candidate = wires.filter { w ->
            val len = w.lengthM
            len > 1e-6 && (if (len > 1e-12) abs(axialDelta(w)) / len else 0.0) < 0.92
        }.ifEmpty { wires }
        val quantum = max(axisSpan(), 1.0) * 1e-4
        return candidate.map { kotlin.math.round(stationCoord(it) / quantum) * quantum }
            .distinct().sorted()
    }

    val transverseWireCount get() = wires.count { w ->
        val len=w.lengthM; len>1e-12 && abs(axialDelta(w))/len < 0.72
    }
    val longitudinalWireCount get() = wires.count { w ->
        val len=w.lengthM; len>1e-12 && abs(axialDelta(w))/len >= 0.72
    }

    val antennaKind: String get() = MaaGeometryClassifier.classify(this)
    val analysisProfile: String get() = MaaGeometryClassifier.analysisProfile(this)
}

private object MaaGeometryClassifier {
    private fun semanticText(m: MaaModel): String = (m.title + " " + (m.fileNameHint ?: "")).lowercase()

    fun analysisProfile(m: MaaModel): String {
        val k = classify(m)
        return when {
            k.contains("LPDA", true) -> "LPDA_END_FIRE"
            k.contains("Yagi", true) || k.contains("parasitic", true) -> "PARASITIC_ARRAY"
            k.contains("Quad", true) || k.contains("loop", true) || k.contains("Hentenna", true) -> "CLOSED_LOOP"
            k.contains("Helical", true) -> "HELIX_3D"
            k.contains("Discone", true) || k.contains("Ground-plane", true) || k.contains("Vertical", true) || k.contains("Collinear", true) -> "OMNI_VERTICAL"
            k.contains("Beverage", true) || k.contains("Rhomb", true) || k.contains("T2FD", true) || k.contains("Aperiodic", true) -> "TRAVELING_WAVE"
            k.contains("Phased", true) || k.contains("HB9CV", true) || k.contains("Stack", true) -> "PHASED_ARRAY"
            k.contains("Feeder", true) || k.contains("Balun", true) || k.contains("Transformer", true) -> "FEED_NETWORK"
            k.contains("Magnetic", true) || k.contains("DDRR", true) -> "SMALL_LOOP"
            k.contains("Dipole", true) || k.contains("Windom", true) || k.contains("G5RV", true) -> "DIPOLE_FAMILY"
            else -> "GENERAL_WIRE"
        }
    }

    fun classify(m: MaaModel): String {
        if (m.wires.isEmpty()) return "Wire antenna"
        val title = semanticText(m)
        // MMANA filenames often encode element count compactly: 4el6m, 15EL23CM, etc.
        // Keep this hint ahead of matching-network words so a T-match Yagi is not reduced to a
        // generic matched wire antenna (which would rotate its principal cuts to the longest span).
        val elementArrayHint = Regex("""\b\d{1,2}\s*el(?:e)?(?:\d+[a-z]*)?\b""").containsMatchIn(title)
        val yagiSemanticHint = "yagi" in title || elementArrayHint

        // Kotlin when-conditions must be Boolean expressions.  The previous 1.19.105
        // implementation put a nullable Regex MatchResult?.let block directly in `when`,
        // which caused compile errors.  Detect explicit forms such as 2x6el / 2×6el
        // before entering the Boolean `when` table.
        val explicitStackMatch = Regex(
            """\b(\d+)\s*[x×х]\s*(\d+)\s*el(?:e)?""",
            RegexOption.IGNORE_CASE
        ).find(title)
        if (explicitStackMatch != null) {
            val stackCount = explicitStackMatch.groupValues[1].toIntOrNull() ?: 0
            val elementsPerYagi = explicitStackMatch.groupValues[2].toIntOrNull() ?: 0
            if (stackCount >= 2 && elementsPerYagi >= 2) {
                return "$stackCount × $elementsPerYagi-element Yagi stack"
            }
        }

        // 1.17.9: extended semantic taxonomy trained/validated on the complete 722-file ANT corpus.
        // Filename is used as a hint in addition to the MAA title. Geometry still remains the fallback.
        // More specific families MUST precede generic words such as dipole/vertical/loop.
        when {
            "t2fd" in title -> return "T2FD / terminated folded traveling-wave antenna"
            "beverage" in title || "tbev" in title || "bev" in title && "beverage" in title -> return "Beverage / traveling-wave receiving antenna"
            "pennant" in title -> return "Pennant receiving loop"
            Regex("(^|[^a-z])flag([^a-z]|$)").containsMatchIn(title) -> return "Flag receiving loop"
            "rhombic" in title || "rhomb" in title -> return "Rhombic / traveling-wave wire antenna"
            "pyram" in title -> return "Pyramid / aperiodic wire antenna"
            "aperiod" in title -> return "Aperiodic / terminated wire antenna"
            "balun" in title -> return "Balun / feeder-current model"
            "feeder" in title || "trans" in title && ("ohm" in title || "stub" in title || "lambda" in title) -> return "Feeder / impedance-transformer model"
            "hb9cv" in title -> return "HB9CV / phased two-element array"
            "phas" in title || "phased" in title -> return "Phased wire array"
            // Explicit stacked-Yagi names are handled by the pre-check above.
            "stack" in title || "syack" in title -> return "Stacked Yagi / antenna array"
            "ddrr" in title -> return "DDRR / electrically-short loop radiator"
            "magloop" in title || "magn loop" in title || "magnetic loop" in title || "multiturnloop" in title -> return "Magnetic loop antenna"
            "fractal" in title || "piramida" in title -> return "Fractal / folded electrically-short antenna"
            "trap" in title -> return "Trap-loaded multiband antenna"
            "sleeve" in title || "sleve" in title -> return "Open-sleeve / sleeve multiband antenna"
            "g5rv" in title -> return "G5RV multiband dipole"
            "zs6bkw" in title -> return "ZS6BKW multiband dipole"
            "windom" in title || "ocf" in title -> return "Windom / off-center-fed dipole"
            "inverted v" in title || "inv v" in title || "invv" in title -> return "Inverted-V dipole"
            "folded dipole" in title || "fold dipole" in title || "fold. dipole" in title -> return "Folded dipole"
            "hairpin" in title -> return "Hairpin-matched wire antenna"
            ("t-match" in title || "t match" in title) && yagiSemanticHint -> return "T-matched Yagi / parasitic wire array"
            "t-match" in title || "t match" in title -> return "T-matched wire antenna"
            "inverted l" in title || "inv l" in title -> return "Inverted-L antenna"
            "end fed" in title || "end-fed" in title -> return "End-fed wire antenna"
            "top load" in title || "top-load" in title -> return "Top-loaded short antenna"
            "sloper" in title || "slope dip" in title -> return "Sloper / inclined dipole"
            "long wire" in title || "longwire" in title -> return "Long-wire antenna"
            "gamma" in title && ("quad" in title || "yagi" in title) -> return "Gamma-matched parasitic/loop array"
            "gamma" in title -> return "Gamma-matched wire antenna"
            "omega" in title -> return "Omega-matched wire antenna"
            "j-antenna" in title || "j-ant" in title || "j pole" in title || "j-pole" in title || "mod j" in title -> return if ("yagi" in title) "J-fed Yagi / matched array" else "J-pole / J antenna"
            "henten" in title -> return if (Regex("""\b[235]el|yagi""").containsMatchIn(title)) "Hentenna Yagi / loop array" else "Hentenna loop antenna"
            "twin delta" in title || "twind" in title -> return if (Regex("""\b[235]el|yagi""").containsMatchIn(title)) "Twin-delta-loop Yagi / loop array" else "Twin-delta loop antenna"
            "twin loop" in title -> return if (Regex("""\b[235]el|yagi""").containsMatchIn(title)) "Twin-loop Yagi / loop array" else "Twin-loop antenna"
            "delta loop" in title || "delta6" in title || Regex("(^|[^a-z])delta([^a-z]|$)").containsMatchIn(title) -> return if (Regex("""\b[2-9]el|yagi""").containsMatchIn(title)) "Delta-loop Yagi / loop array" else "Delta loop antenna"
            "swiss-quad" in title || "swiss quad" in title -> return "Swiss-Quad / closed-loop array"
            "quad" in title || Regex("""\bcq\b""").containsMatchIn(title) -> if (Regex("""\b[2-9]el|\b1[0-9]el|yagi""").containsMatchIn(title)) return "Quad-loop Yagi / closed-loop array"
            "discon" in title || "diskon" in title || "дискон" in title -> return "Discone / rotationally symmetric omni"
            "helix" in title || "спирал" in title -> return "Helical / axial-mode wire antenna"
            "collinear" in title -> return "Collinear vertical array"
            "ground plane" in title || Regex("(^|[^a-z])gp([^a-z]|$)").containsMatchIn(title) -> return "Ground-plane / monopole antenna"
            "vertical" in title || "vert" in title && !"invert".let { it in title } -> return "Vertical / monopole wire antenna"
            "crosspol" in title || "cross-pol" in title -> return "Cross-polarized Yagi / crossed wire array"
            "corner reflector" in title || "coner reflector" in title || title.startsWith("cr2") -> return "Corner-reflector wire antenna"
            "mirror" in title -> return "Wire-grid reflector antenna"
            "plane-reflector" in title || "plane reflector" in title -> return "Wire-grid reflector antenna"
            "horn yagi" in title -> return "Horn-Yagi / hybrid parasitic array"
            "log" in title && ("yagi" in title || "period" in title || "lpda" in title || "tv" in title) -> return "Log-periodic / LPDA wire antenna"
            "lpda" in title -> return "Log-periodic / LPDA wire antenna"
            yagiSemanticHint &&
                listOf("loop","quad","delta","twin","hent","rhomb","gp").none { it in title } -> return "Linear Yagi / parasitic wire array"
            "dipole" in title || "dipol" in title || ("dp" in title && m.wires.size <= 8) -> return "Dipole / wire radiator"
            "isotrop" in title -> return "Reference test radiator"
            "skydoor" in title -> return "Skydoor loop antenna"
            "big star" in title -> return "Star / radial wire antenna"
        }

        // 1.17.8 topology knowledge distilled from the earlier ANT.ZIP subset.
        when {
            "discon" in title || "diskon" in title || "дискон" in title -> return "Discone / rotationally symmetric omni"
            "log" in title && ("yagi" in title || "period" in title || "tv" in title) -> return "Log-periodic / LPDA wire antenna"
            "helix" in title || "спирал" in title -> return "Helical / axial-mode wire antenna"
            "crosspol" in title || "cross-pol" in title -> return "Cross-polarized Yagi / crossed wire array"
            "corner reflector" in title || "coner reflector" in title || title.startsWith("cr2") -> return "Corner-reflector wire antenna"
            "mirror" in title -> return "Wire-grid reflector antenna"
            "plane-reflector" in title || "plane reflector" in title || "rhomb" in title -> return "Rhomb / wire-reflector antenna"
            "henten" in title -> return if (title.trim().startsWith("3ele")) "Hentenna Yagi / loop array" else "Hentenna loop antenna"
            "twin delta" in title || "twind" in title -> return if ("5ele" in title) "Twin-delta-loop Yagi / loop array" else "Twin-delta loop antenna"
            "twin loop" in title -> return if ("5ele" in title) "Twin-loop Yagi / loop array" else "Twin-loop antenna"
            "delta loop" in title || "delta6" in title -> return "Delta-loop Yagi / loop array"
            "collinear" in title -> return "Collinear vertical array"
            "omni dipol" in title || "gamma-match" in title -> return "Gamma-matched omni dipole"
            "skydoor" in title -> return "Skydoor loop antenna"
            title.startsWith("gp") || " gp " in title || title.endsWith(" gp") || " ground plane" in title -> return "Ground-plane / monopole antenna"
            "j-antenna" in title || "j-ant" in title || "j-yagi" in title -> return if ("yagi" in title) "J-fed Yagi / matched array" else "J-pole / J antenna"
            "big star" in title -> return "Star / radial wire antenna"
            "isotrop" in title -> return "Reference test radiator"
            "horn yagi" in title -> return "Horn-Yagi / hybrid parasitic array"
            "swiss-quad" in title -> return "Swiss-Quad / closed-loop array"
            Regex("(^|\\s)\\d*\\s*el.*quad|\\bcq\\b").containsMatchIn(title) -> return "Quad-loop Yagi / closed-loop array"
        }

        val eps = maxOf(m.spanX, m.spanY, m.spanZ, 1.0) * 0.002

        // Rotationally symmetric vertical omni (for example discone). Detect before Yagi rules:
        // a discone can have X/Y/Z spans of similar size and would otherwise look like a Yagi.
        if (m.omniSymmetryAxis != null) {
            return "Discone / rotationally symmetric omni"
        }

        // Axial helix: one dimension is clearly the axis and many short connected segments wind
        // around it. Detect before Yagi-specific X-axis rules.
        if (!m.isPlanar && m.mainAxis == 'Z' && m.spanZ > max(m.spanX, m.spanY) * 2.2 && m.wires.size >= 8) {
            return "Helical / axial-mode wire antenna"
        }
        if (!m.isPlanar && m.mainAxis == 'Y' && m.spanY > max(m.spanX, m.spanZ) * 2.2 && m.wires.size >= 8) {
            return "Helical / axial-mode wire antenna"
        }

        val tx = m.wires.filter { it.transverseFraction >= 0.72 && it.lengthM > eps }
        val longitudinal = m.wires.filter { it.axialFractionX >= 0.72 && it.lengthM > eps }
        val stations = m.elementStationsM

        val perStation = if (stations.isNotEmpty()) m.wires.size.toDouble() / stations.size else 0.0

        // Closed polygon elements: 4 wires = square/quad, 6+ = polygon/ring approximation.
        // Treat both as the same connected closed-loop family so the dedicated loop-array
        // impedance and pattern paths are available.  This fixes classic Cubical Quad MAA files
        // such as 12CQ430 where every element is exactly four wires.
        if (stations.size >= 3 && longitudinal.isEmpty() && perStation >= 3.5 && m.mainAxis == 'X') {
            return if (perStation >= 6.0) {
                "Ring-loop Yagi / closed-loop array"
            } else {
                "Quad-loop Yagi / closed-loop array"
            }
        }

        // Very dense MMANA wire meshes (e.g. mirror.maa) are reflector/grid structures,
        // not crossed radiators.  Detect before the Cross-Yagi station heuristic.
        if (m.wires.size >= 150) return "Wire-grid reflector antenna"

        // Cross-polarized arrays have sizeable Y- and Z-directed radiators at several common X stations.
        val yRadiators = tx.filter { abs(it.dy) >= abs(it.dz) * 2.0 }
        val zRadiators = tx.filter { abs(it.dz) >= abs(it.dy) * 2.0 }
        val yXs = stationSet(yRadiators, m)
        val zXs = stationSet(zRadiators, m)
        val sharedCrossStations = yXs.intersect(zXs).size
        if (sharedCrossStations >= 2 && yRadiators.size >= 2 && zRadiators.size >= 2) {
            return "Cross-polarized Yagi / crossed wire array"
        }

        // LPDA: many transverse elements of progressively changing length plus one/two long boom chains.
        if (tx.size >= 6 && longitudinal.size >= 4 && stations.size >= 5) {
            val stationLengths = tx.groupBy { stationKey(it.midX, m) }
                .map { (k, ws) -> k to ws.sumOf { it.lengthM } }
                .sortedBy { it.first }
                .map { it.second }
            if (stationLengths.size >= 5) {
                var trendPairs = 0
                var monotonicPairs = 0
                for (i in 1 until stationLengths.size) {
                    val a = stationLengths[i - 1]
                    val b = stationLengths[i]
                    if (max(a, b) > 1e-9) {
                        trendPairs++
                        if (b <= a * 1.10 || a <= b * 1.10) monotonicPairs++
                    }
                }
                val uniqueLengths = stationLengths.map { kotlin.math.round(it * 1000.0) / 1000.0 }.distinct().size
                if (uniqueLengths >= 4 && trendPairs >= 4 && longitudinal.size >= stations.size / 2) {
                    return "Log-periodic / LPDA wire antenna"
                }
            }
        }

        // Conventional Yagi files are often perfectly planar too (for example all elements in XZ).
        // Keep those on the old station-array path instead of treating them as generic planar loops.
        if (m.mainAxis == 'X' && stations.size >= 3 && tx.size >= 3 && m.spanX > 1e-6) {
            return "Linear Yagi / parasitic wire array"
        }

        // Truly planar wire antennas (delta loops, halo, omni loops, planar dipoles).
        // IMPORTANT: check this only AFTER LPDA detection. A real two-boom LPDA can be almost
        // planar (very small Z spacing between booms), and classifying it as a generic planar
        // antenna sends it into the full-wire fallback and distorts the end-fire preview.
        if (m.isPlanar && m.wires.size >= 2) {
            return "Planar loop / dipole / omni wire antenna"
        }

        // Multi-wire closed/folded elements: several wires per X station.
        if (perStation >= 5.0) return "Loop / quad / multi-wire Yagi"
        if (perStation >= 2.2) return "Folded / quad-element Yagi"

        if (stations.size >= 3 && tx.size >= 3) return "Linear Yagi / parasitic wire array"

        return "General MMANA wire antenna"
    }

    private fun stationKey(x: Double, m: MaaModel): Long {
        val q = max(m.spanX, 1.0) * 1e-4
        return kotlin.math.round(x / q).toLong()
    }

    private fun stationSet(ws: List<MaaWire>, m: MaaModel): Set<Long> = ws.map { stationKey(it.midX, m) }.toSet()
}

private data class LegacyStackHeader(
    val horizontalCount: Int,
    val verticalCount: Int,
    val horizontalSpacingM: Double,
    val verticalSpacingM: Double,
    val positionMode: Int
)

object MaaParser {
    fun parse(reader: BufferedReader, fileNameHint: String? = null): MaaModel {
        val lines = reader.readLines()
        require(lines.isNotEmpty()) { "Empty MAA file." }

        val title = lines.firstOrNull { it.trim().isNotEmpty() && !it.trim().startsWith("*") }
            ?.trim().orEmpty().ifBlank { "MMANA antenna" }

        val wiresHeader = findWiresHeader(lines)
        require(wiresHeader >= 0) { "MAA wire section not found (Wires)." }

        val frequencyMHz = lines.subList(0, wiresHeader)
            .mapNotNull { parseNumber(it.trim()) }
            .lastOrNull() ?: error("Failed to determine the MAA frequency.")

        val countLine = nextNonEmpty(lines, wiresHeader + 1)
        // MMANA variants may store extra combined-wire metadata on the same line:
        // "6, 1, 2, 8.0, 8.0, 0". The first field is the actual wire count.
        val wireCountText = lines.getOrNull(countLine)?.trim().orEmpty()
        val wireCountFields = wireCountText.split(',', ';', ' ', '\t').filter { it.isNotBlank() }
        val wireCount = wireCountFields.firstOrNull()?.toIntOrNull()
            ?: error("Invalid wire count after the Wires section: '$wireCountText'.")
        require(wireCount in 1..100000) { "Invalid wire count: $wireCount." }

        // Legacy MMANA compact stack header used by the ANT/Stacks corpus:
        //   baseWires, horizontalCount, verticalCount, horizontalSpacing, verticalSpacing, positionMode
        // Example 4X12.MAA: 17,4,1,0.689195,0.689195,0.
        // Older parser versions intentionally accepted only the first field, which made the model
        // look like ONE Yagi and NEC-2 therefore calculated ONE-Yagi radiation. Preserve the header
        // semantics here and expand the physical geometry/sources/loads before building the NEC deck.
        val stackHeader = if ((fileNameHint ?: "").replace('\\','/').contains("Stacks/", ignoreCase = true) && wireCountFields.size >= 6) {
            val h = wireCountFields.getOrNull(1)?.toIntOrNull() ?: 1
            val v = wireCountFields.getOrNull(2)?.toIntOrNull() ?: 1
            val hs = parseNumber(wireCountFields.getOrNull(3).orEmpty()) ?: 0.0
            val vs = parseNumber(wireCountFields.getOrNull(4).orEmpty()) ?: 0.0
            val mode = wireCountFields.getOrNull(5)?.toIntOrNull() ?: 0
            if (h in 1..8 && v in 1..8 && h * v in 2..64 && hs >= 0.0 && vs >= 0.0)
                LegacyStackHeader(h, v, hs, vs, mode) else null
        } else null

        val wires = ArrayList<MaaWire>(wireCount)
        var i = countLine + 1
        var firstBadWireLine: String? = null
        while (i < lines.size && wires.size < wireCount) {
            val s = lines[i].trim().removePrefix("\uFEFF")
            if (s.isNotEmpty()) {
                if (looksLikeSection(s)) break
                val w = parseWireRecord(s)
                if (w != null) wires += w else if (firstBadWireLine == null) firstBadWireLine = s
            }
            i++
        }
        require(wires.size == wireCount) {
            val tail = firstBadWireLine?.let { " First unrecognized line: '$it'." } ?: ""
            "Expected $wireCount wires, read ${wires.size}.$tail"
        }

        var sourceWire: Int? = null
        var sourceDesc: String? = null
        val sources = ArrayList<MaaSource>()
        val sourceHeader = lines.indexOfFirst { isSection(it, "source", "источ", "feed", "generator") }
        if (sourceHeader >= 0) {
            var j = sourceHeader + 1
            while (j < lines.size && !looksLikeSection(lines[j])) {
                val raw = lines[j].trim()
                // MMANA pulse syntax: W#B(#), W#C(#), W#E(#).
                // Unsigned Bn/Cn means n pulses forward from B/C; unsigned En means n pulses
                // backward from E (e.g. W5E3).  Older builds stopped at the B/C/E letter,
                // accidentally reading the compact offset as source phase and could even set
                // the source amplitude to zero.
                val m = Regex("(?i)w\\s*(\\d+)\\s*([bce])\\s*([+-]?\\s*\\d+)?").find(raw)
                if (m != null) {
                    val wi = m.groupValues[1].toIntOrNull()?.minus(1)
                    val pos = m.groupValues[2].lowercase().firstOrNull() ?: 'c'
                    val offsetText = m.groupValues.getOrNull(3).orEmpty().replace(" ", "")
                    val rawOffset = offsetText.toIntOrNull() ?: 0
                    val segmentOffset = if (offsetText.isNotEmpty() &&
                        !offsetText.startsWith("+") && !offsetText.startsWith("-") && pos == 'e'
                    ) -rawOffset else rawOffset
                    val nums = raw.substring(m.range.last + 1)
                        .trimStart(' ', '\t', ',', ';')
                        .split(',', ';', ' ', '\t')
                        .mapNotNull { parseNumber(it) }
                    if (wi != null && wi in wires.indices) {
                        val phaseDeg = nums.getOrNull(0) ?: 0.0
                        val amplitude = nums.getOrNull(1) ?: 1.0
                        sources += MaaSource(wi, pos, segmentOffset, phaseDeg, amplitude, raw)
                    }
                }
                j++
            }
            sources.firstOrNull()?.let { first ->
                sourceWire = first.wireIndex
                sourceDesc = first.raw
            }
        }


        val loads = ArrayList<MaaLoad>()
        val loadHeader = lines.indexOfFirst { isSection(it, "load", "нагруз") }
        if (loadHeader >= 0) {
            var j = loadHeader + 1
            while (j < lines.size && !looksLikeSection(lines[j])) {
                val raw = lines[j].trim()
                val lm = Regex("(?i)w\\s*(\\d+)\\s*([bce])\\s*([+-]?\\s*\\d+)?\\s*[,;]\\s*(-?\\d+)").find(raw)
                if (lm != null) {
                    val wi = lm.groupValues[1].toIntOrNull()?.minus(1)
                    val pos = lm.groupValues[2].lowercase().firstOrNull() ?: 'c'
                    val offsetText = lm.groupValues[3].replace(" ", "")
                    val rawOffset = offsetText.toIntOrNull() ?: 0
                    // W#E3 = three pulses back from the end; B3/C3 = forward from base.
                    // An explicit + / - keeps its literal sign.
                    val segmentOffset = if (offsetText.isNotEmpty() &&
                        !offsetText.startsWith("+") && !offsetText.startsWith("-") && pos == 'e'
                    ) -rawOffset else rawOffset
                    val kind = lm.groupValues[4].toIntOrNull() ?: 0
                    val nums = raw.substring(lm.range.last + 1)
                        .split(',', ';', ' ', '\t')
                        .mapNotNull { parseNumber(it) }
                    if (wi != null && wi in wires.indices) {
                        // MMANA load encoding:
                        // kind=0 -> LC load: L[uH], C[pF], Q (L and C form a parallel trap; either may be zero).
                        // kind=1 -> fixed R+jX load: R[ohm], X[ohm].
                        val v1 = nums.getOrNull(0) ?: 0.0
                        val v2 = nums.getOrNull(1) ?: 0.0
                        val v3 = nums.getOrNull(2) ?: 0.0
                        loads += MaaLoad(wi, pos, segmentOffset, kind, v1, v2, v3, raw)
                    }
                }
                j++
            }
        }

        var segDesc: String? = null
        val segHeader = lines.indexOfFirst { isSection(it, "segmentation", "автосегм", "сегм", "auto seg") }
        if (segHeader >= 0) {
            val j = nextNonEmpty(lines, segHeader + 1)
            if (j in lines.indices && !looksLikeSection(lines[j])) segDesc = lines[j].trim()
        }

        // MMANA project line: G/H/M/R/AzEl/X
        // G = ground selector, H = Add height [m], M = material selector,
        // R = reference impedance used only for SWR.
        var referenceOhms: Double? = null
        var groundType = 0
        var addHeightM = 0.0
        var materialCode = 0
        for (i in lines.indices) {
            val key = lines[i].lowercase()
            if (key.contains("g/h") || key.contains("azel") || key.contains("az/el")) {
                val j = nextNonEmpty(lines, i + 1)
                if (j in lines.indices) {
                    val nums = lines[j].split(',', ';', ' ', '\t').mapNotNull { parseNumber(it) }
                    groundType = nums.getOrNull(0)?.toInt()?.coerceIn(-1, 2) ?: 0
                    addHeightM = nums.getOrNull(1) ?: 0.0
                    materialCode = nums.getOrNull(2)?.toInt() ?: 0
                    val r0 = nums.getOrNull(3)
                    if (r0 != null && r0 in 5.0..1000.0) referenceOhms = r0
                }
                break
            }
        }

        // Expand the four legacy compact stack files exactly as MMANA's Make Stack tool does.
        // Horizontal spacing is perpendicular to the boom in Y; vertical spacing is Z.
        // positionMode=0 means centred around the original location.  The ANT corpus compact-stack
        // files all use mode 0. Each copy gets its own identical-phase source at V/N, matching the
        // MMANA stack rule; lumped loads are duplicated together with their parent antenna.
        val expanded = stackHeader?.let { sh ->
            expandLegacyStack(wires, sources, loads, sh)
        }
        val finalWires = expanded?.first ?: wires.toList()
        val finalSources = expanded?.second ?: sources.toList()
        val finalLoads = expanded?.third ?: loads.toList()
        val finalSourceWire = finalSources.firstOrNull()?.wireIndex ?: sourceWire?.takeIf { it in finalWires.indices }

        return MaaModel(
            title = title,
            frequencyMHz = frequencyMHz,
            wires = finalWires,
            sourceWireIndex = finalSourceWire,
            sourceDescription = finalSources.firstOrNull()?.raw ?: sourceDesc,
            loads = finalLoads,
            segmentationDescription = segDesc,
            rawWireCount = finalWires.size,
            referenceImpedanceOhms = referenceOhms,
            fileNameHint = fileNameHint,
            sources = finalSources,
            groundType = groundType,
            addHeightM = addHeightM,
            materialCode = materialCode
        )
    }

    private fun expandLegacyStack(
        baseWires: List<MaaWire>,
        baseSources: List<MaaSource>,
        baseLoads: List<MaaLoad>,
        sh: LegacyStackHeader
    ): Triple<List<MaaWire>, List<MaaSource>, List<MaaLoad>> {
        val nCopies = sh.horizontalCount * sh.verticalCount
        if (nCopies <= 1 || baseWires.isEmpty()) return Triple(baseWires, baseSources, baseLoads)

        val outWires = ArrayList<MaaWire>(baseWires.size * nCopies)
        val outSources = ArrayList<MaaSource>(maxOf(1, baseSources.size) * nCopies)
        val outLoads = ArrayList<MaaLoad>(baseLoads.size * nCopies)

        fun verticalOffset(vi: Int): Double = when (sh.positionMode) {
            1 -> vi * sh.verticalSpacingM                       // original + above
            2 -> -vi * sh.verticalSpacingM                      // original + below
            else -> (vi - (sh.verticalCount - 1) / 2.0) * sh.verticalSpacingM
        }
        fun horizontalOffset(hi: Int): Double =
            (hi - (sh.horizontalCount - 1) / 2.0) * sh.horizontalSpacingM

        var copy = 0
        for (vi in 0 until sh.verticalCount) {
            val dz = verticalOffset(vi)
            for (hi in 0 until sh.horizontalCount) {
                val dy = horizontalOffset(hi)
                val wireBase = copy * baseWires.size
                baseWires.forEach { w ->
                    outWires += w.copy(
                        y1 = w.y1 + dy, z1 = w.z1 + dz,
                        y2 = w.y2 + dy, z2 = w.z2 + dz
                    )
                }
                baseSources.forEach { src ->
                    outSources += src.copy(
                        wireIndex = wireBase + src.wireIndex,
                        amplitude = src.amplitude / nCopies.toDouble(),
                        raw = src.raw + " [stack ${copy + 1}/$nCopies]"
                    )
                }
                baseLoads.forEach { ld ->
                    outLoads += ld.copy(
                        wireIndex = wireBase + ld.wireIndex,
                        raw = ld.raw + " [stack ${copy + 1}/$nCopies]"
                    )
                }
                copy++
            }
        }
        return Triple(outWires, outSources, outLoads)
    }

    private fun parseWireRecord(s: String): MaaWire? {
        // Classic MMANA usually uses commas between fields, but some exports use tabs/spaces.
        // Support both without confusing a decimal comma with the field separator.
        val cleaned = s.trim().removePrefix("\uFEFF")
        val p = if (cleaned.contains(',')) {
            cleaned.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        } else {
            cleaned.split(Regex("\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        }
        if (p.size < 7) return null
        val n = p.take(7).map { parseNumber(it) }
        if (n.any { it == null }) return null
        return MaaWire(
            n[0]!!, n[1]!!, n[2]!!,
            n[3]!!, n[4]!!, n[5]!!,
            abs(n[6]!!),
            p.getOrNull(7)?.trim()?.toIntOrNull() ?: -1
        )
    }

    private fun parseNumber(s: String): Double? {
        var t = s.trim().removePrefix("\uFEFF")
        if (t.isEmpty()) return null
        t = t.replace('D', 'E').replace('d', 'e')
        return t.toDoubleOrNull() ?: t.replace(',', '.').toDoubleOrNull()
    }

    private fun findWiresHeader(lines: List<String>): Int {
        val named = lines.indexOfFirst { isSection(it, "wires", "провода", "wire") }
        if (named >= 0) return named

        // Localization-independent structural fallback: section line -> integer count -> valid wire record.
        for (h in lines.indices) {
            if (!looksLikeSection(lines[h])) continue
            val c = nextNonEmpty(lines, h + 1)
            val countText = lines.getOrNull(c)?.trim().orEmpty()
            val count = countText.split(',', ';', ' ', '\t').firstOrNull { it.isNotBlank() }?.toIntOrNull() ?: continue
            if (count <= 0) continue
            val w = nextNonEmpty(lines, c + 1)
            if (parseWireRecord(lines.getOrNull(w)?.trim().orEmpty()) != null) return h
        }
        return -1
    }

    private fun isSection(line: String, vararg names: String): Boolean {
        val t = line.trim().lowercase()
        if (!looksLikeSection(t)) return false
        return names.any { t.contains(it.lowercase()) }
    }

    private fun looksLikeSection(line: String): Boolean = line.trim().startsWith("*")

    private fun nextNonEmpty(lines: List<String>, start: Int): Int {
        var i = start
        while (i < lines.size && lines[i].trim().isEmpty()) i++
        return i
    }
}

data class MaaPatternPoint(val angleDeg: Double, val db: Double)

data class MaaPatternPreview(
    val points: List<MaaPatternPoint>,
    val hpbwDeg: Double?,
    val frontBackDb: Double?,
    val maxSideLobeDb: Double?
)
