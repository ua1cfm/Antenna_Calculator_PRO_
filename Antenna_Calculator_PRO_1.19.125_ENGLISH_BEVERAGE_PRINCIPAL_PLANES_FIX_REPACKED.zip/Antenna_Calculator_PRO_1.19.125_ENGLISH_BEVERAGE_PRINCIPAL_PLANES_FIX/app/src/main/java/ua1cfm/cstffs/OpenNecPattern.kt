package ua1cfm.cstffs

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Far-field pattern reconstructed directly from the complex segment currents solved by OpenNEC.
 *
 * NEC-2 FULL remains responsible for the electromagnetic solution (impedance + currents).  This
 * class only evaluates the standard thin-wire radiation integral for two display cuts.  Unlike the
 * old NEC2-alpha preview it never re-solves or calibrates the currents, so a Yagi pattern uses the
 * same complex currents that produced the displayed FULL input impedance.
 */
object OpenNecPattern {
    data class Result(
        val previewTop: MaaPatternPreview,
        val previewSide: MaaPatternPreview,
        val principalPlane1Label: String,
        val principalPlane2Label: String,
        val note: String
    )

    private data class C(val re: Double, val im: Double) {
        operator fun plus(o: C) = C(re + o.re, im + o.im)
        operator fun times(o: C) = C(re * o.re - im * o.im, re * o.im + im * o.re)
        operator fun times(v: Double) = C(re * v, im * v)
        fun mag2(): Double = re * re + im * im
    }

    private data class PlaneCut(val a: DoubleArray, val b: DoubleArray, val label: String)
    private data class RawCut(val power: DoubleArray, val peak: Double)

    fun calculate(model: MaaModel, solved: OpenNecFull.Result): Result {
        require(solved.segments.isNotEmpty()) { "NEC-2 FULL returned no currents for the radiation pattern." }
        require(model.frequencyMHz > 0.0) { "Invalid frequency." }

        val sampler = nativeSamplerOrNull(solved.nativePattern)
        val k = 2.0 * PI / model.wavelengthM
        val cuts = principalCuts(model, sampler, solved.segments, k)
        val raw1 = if (sampler != null)
            farFieldNativeRaw(sampler, model.groundType != 0, cuts.first.a, cuts.first.b)
        else
            farFieldRaw(solved.segments, k, cuts.first.a, cuts.first.b, model.groundType == 1 || model.groundType == 2)
        val raw2 = if (sampler != null)
            farFieldNativeRaw(sampler, model.groundType != 0, cuts.second.a, cuts.second.b)
        else
            farFieldRaw(solved.segments, k, cuts.second.a, cuts.second.b, model.groundType == 1 || model.groundType == 2)
        // Both 2D cuts use one common normalization.  Since adaptive principal cuts pass through
        // the same full-pattern main lobe, this preserves the real relative level between planes.
        val commonPeak = max(raw1.peak, raw2.peak).coerceAtLeast(1e-30)
        val p1 = finishPreview(raw1.power, commonPeak)
        val p2 = finishPreview(raw2.power, commonPeak)
        val basisNote = if (sampler != null)
            "native OpenNEC RP / far_e_field coherent Eθ/Eφ"
        else if (solved.segments.all { it.hasNecCurrentBasis })
            "fallback OpenNEC NEC A/B/C current basis"
        else
            "legacy centre-current fallback"
        val groundNote = when (model.groundType) {
            0 -> "native Free Space"
            1 -> "native Perfect Ground"
            2 -> "native Real Ground epsr=13, sigma=0.005 S/m"
            -1 -> "native Sommerfeld-Norton ground"
            else -> "native OpenNEC ground"
        }
        return Result(
            previewTop = p1,
            previewSide = p2,
            principalPlane1Label = cuts.first.label,
            principalPlane2Label = cuts.second.label,
            note = "NEC-2 FULL pattern: $basisNote; $groundNote."
        )
    }



    private data class FixedMatchAxes(
        val forward: DoubleArray,
        val transverse1: DoubleArray,
        val transverse2: DoubleArray,
        val label1: String,
        val label2: String,
        val note: String
    )

    /**
     * 1.19.116: The Match corpus contains several electrically very different families under
     * one folder: T/Gamma/Omega matched Yagis, horizontal dipoles, vertical/GP radiators,
     * D/Delta/Quad loops and pure transformer examples.  Matching-network words must never be
     * allowed to redefine the radiation axis.  This helper recovers the radiator family first,
     * then defines the two physical principal planes from geometry.  It is used by BOTH the
     * direct 2D path and the 2D-from-3D path.
     */
    /**
     * 1.19.125: Beverage antennas must use MMANA-style physical principal planes.
     * The ground-reflected 3D maximum is allowed to rise in elevation, but it must NOT
     * rotate/re-center the 2D coordinate system.  P1 is the horizontal azimuth plane
     * containing the long wire; P2 is the vertical elevation plane containing the same
     * wire and +Z.  The forward/back sign is taken from the real NEC 3D maximum.
     */
    private fun fixedBeverageAxes(model: MaaModel, peakVector: DoubleArray): FixedMatchAxes? {
        val semantic = (model.title + " " + model.fileNameHint.orEmpty()).lowercase(java.util.Locale.ROOT)
        val isBeverage = model.analysisProfile == "TRAVELING_WAVE" && semantic.contains("beverage") ||
            semantic.contains("beverage") || semantic.contains("beveridge")
        if (!isBeverage) return null

        fun axisExtent(w: MaaWire, axis: Char): Double = when (axis) {
            'X' -> kotlin.math.abs(w.dx)
            'Y' -> kotlin.math.abs(w.dy)
            else -> kotlin.math.abs(w.dz)
        }
        // A Beverage is defined by its long travelling-wave conductor, not by the short
        // feed/termination drops.  Recover the physical wire direction from the longest wire.
        val mainWire = model.wires.maxByOrNull { it.lengthM } ?: return null
        val wireAxis = listOf('X','Y','Z').maxByOrNull { axisExtent(mainWire, it) } ?: 'X'
        var forward = axisVector(wireAxis)
        if (wireAxis == 'Z') {
            // Defensive fallback: Beverage should be horizontal. Use the dominant horizontal
            // component if a malformed model makes Z look longest.
            val hAxis = if (kotlin.math.abs(mainWire.dx) >= kotlin.math.abs(mainWire.dy)) 'X' else 'Y'
            forward = axisVector(hAxis)
        }
        // Forward sign from the actual NEC solution. Ignore vertical component when selecting it.
        val peakHorizontal = doubleArrayOf(peakVector[0], peakVector[1], 0.0)
        if (norm(peakHorizontal) > 1e-9 && dot(peakHorizontal, forward) < 0.0) {
            forward = scale(forward, -1.0)
        }
        val z = axisVector('Z')
        var azTransverse = normalize(cross(z, forward))
        if (norm(azTransverse) < 1e-8) azTransverse = axisVector('Y')

        val az = Math.toDegrees(kotlin.math.atan2(forward[1], forward[0])).let { if (it < 0.0) it + 360.0 else it }
        val dir = "AZ %.1f° HORIZONTAL".format(java.util.Locale.US, az)
        return FixedMatchAxes(
            forward = forward,
            transverse1 = azTransverse,
            transverse2 = z,
            label1 = "P1 BEVERAGE AZ • $dir",
            label2 = "P2 BEVERAGE EL • $dir",
            note = "Beverage: MMANA-style fixed physical planes; P1 is horizontal azimuth along the wire, P2 is vertical elevation along the wire; the real elevation maximum remains inside P2."
        )
    }

    private fun fixedMatchAxes(model: MaaModel, peakVector: DoubleArray): FixedMatchAxes? {
        val path = model.fileNameHint.orEmpty().replace('\\', '/')
        val inMatchFolder = path.contains("/Match/", ignoreCase = true) || path.startsWith("Match/", ignoreCase = true)
        if (!inMatchFolder) return null

        val semantic = (model.title + " " + path).lowercase(java.util.Locale.ROOT)
        fun span(axis: Char): Double = when (axis) {
            'X' -> model.spanX
            'Y' -> model.spanY
            else -> model.spanZ
        }
        fun signedAxis(axis: Char): DoubleArray {
            val v = axisVector(axis)
            return if (dot(peakVector, v) >= 0.0) v else scale(v, -1.0)
        }
        fun longestAxis(exclude: Set<Char> = emptySet()): Char =
            listOf('X','Y','Z').filter { it !in exclude }.maxByOrNull(::span) ?: 'X'

        val explicitYagi = model.analysisProfile == "PARASITIC_ARRAY" ||
            semantic.contains("yagi") ||
            Regex("""\\b\\d{1,2}\\s*el(?:e)?""", RegexOption.IGNORE_CASE).containsMatchIn(semantic)
        val explicitLoop = semantic.contains("d-match") || semantic.contains("d match") ||
            semantic.contains("quad") || semantic.contains("delta")
        val explicitDipole = (semantic.contains("dipole") ||
            ((semantic.contains("t-match") || semantic.contains("t match")) && !explicitYagi && model.isPlanar)) && !explicitYagi
        val explicitVertical = !explicitYagi && !explicitLoop && !explicitDipole && (
            Regex("""(^|[^a-z])gp([^a-z]|$)""", RegexOption.IGNORE_CASE).containsMatchIn(semantic) ||
            semantic.contains("vertical") || semantic.contains("vert20") || semantic.contains("broadcast") ||
            // Geometry fallback for matching-network verticals whose filenames omit GP/Vertical.
            (model.groundType != 0 && model.spanZ > 0.0 && model.spanZ >= max(model.spanX, model.spanY) * 0.62 && model.sourceAxis == 'Z')
        )

        if (explicitYagi) {
            // A Yagi's longest overall span is often an element, not its boom (e.g. T-match Yagi).
            // Score each candidate boom axis by long wires transverse to it appearing at several
            // distinct stations.  This recovers X for the Match-folder Yagis even when spanY > spanX.
            fun boomScore(axis: Char): Double {
                val axisSpan = span(axis).coerceAtLeast(1e-9)
                val transverse = model.wires.filter { w ->
                    val len = w.lengthM
                    if (len <= 1e-7) false else {
                        val d = when (axis) { 'X' -> abs(w.dx); 'Y' -> abs(w.dy); else -> abs(w.dz) }
                        d / len < 0.35
                    }
                }
                if (transverse.size < 2) return -1.0
                val coords = transverse.map { w -> when (axis) { 'X' -> w.midX; 'Y' -> w.midY; else -> w.midZ } }.sorted()
                val tol = max(axisSpan * 0.025, model.wavelengthM * 0.002)
                var stations = 0
                var last = Double.NaN
                coords.forEach { c ->
                    if (!last.isFinite() || abs(c - last) > tol) { stations++; last = c }
                }
                val longTransverse = transverse.sumOf { it.lengthM }
                return stations * 1000.0 + longTransverse / model.wavelengthM.coerceAtLeast(1e-9)
            }
            val boom = listOf('X','Y','Z').maxByOrNull(::boomScore) ?: model.mainAxis
            val forward = signedAxis(boom)
            val other = listOf('X','Y','Z').filter { it != boom }
            // Element plane: the transverse axis carrying most physical element extent.
            val elemAxis = other.maxByOrNull { a ->
                model.wires.sumOf { w ->
                    val len = w.lengthM.coerceAtLeast(1e-12)
                    val comp = when (a) { 'X' -> abs(w.dx); 'Y' -> abs(w.dy); else -> abs(w.dz) }
                    len * (comp / len)
                }
            } ?: other.first()
            val t1 = axisVector(elemAxis)
            val t2 = normalize(cross(forward, t1))
            val az = Math.toDegrees(kotlin.math.atan2(forward[1], forward[0])).let { if (it < 0.0) it + 360.0 else it }
            val el = Math.toDegrees(kotlin.math.asin(forward[2].coerceIn(-1.0, 1.0)))
            val dir = "AZ %.1f° EL %.1f°".format(java.util.Locale.US, az, el)
            return FixedMatchAxes(
                forward, t1, t2,
                "P1 YAGI • $dir",
                "P2 YAGI ORTHO • $dir",
                "Match/Yagi: boresight from geometric boom stations; matching network cannot rotate the 2D planes."
            )
        }

        if (explicitLoop && model.isPlanar && model.planeNormalAxis != null) {
            val normal = model.planeNormalAxis!!
            val forward = signedAxis(normal)
            val inPlane = listOf('X','Y','Z').filter { it != normal }
            val p1 = inPlane.maxByOrNull(::span) ?: inPlane.first()
            val p2 = inPlane.first { it != p1 }
            return FixedMatchAxes(
                forward, axisVector(p1), axisVector(p2),
                "P1 BROADSIDE • ${normal}-normal",
                "P2 BROADSIDE • ${normal}-normal",
                "Match/loop: broadside is locked to the normal of the physical wire plane."
            )
        }

        if (explicitVertical) {
            // MMANA ground plane is XY; Z is physical vertical.  A matching wire may be longer
            // laterally than the radiator, so never infer H/E planes from the full bounding box.
            return FixedMatchAxes(
                axisVector('X'), axisVector('Y'), axisVector('Z'),
                "P1 H-PLANE • XY",
                "P2 E-PLANE • XZ",
                "Match/vertical: fixed physical H-plane (XY) and E-plane (XZ); network geometry ignored for orientation."
            )
        }

        if (explicitDipole) {
            val dipoleAxis = longestAxis()
            if (dipoleAxis == 'Z') {
                return FixedMatchAxes(
                    axisVector('X'), axisVector('Y'), axisVector('Z'),
                    "P1 H-PLANE • XY",
                    "P2 E-PLANE • XZ",
                    "Match/vertical dipole: physical H/E planes."
                )
            }
            // Horizontal dipoles in the corpus are normally aligned X or Y.  Use the horizontal
            // broadside normal for angle zero and show any ground-induced elevation inside P2.
            val d = axisVector(dipoleAxis)
            var broadside = normalize(cross(d, axisVector('Z')))
            if (norm(broadside) < 1e-8) broadside = axisVector('X')
            if (dot(peakVector, broadside) < 0.0) broadside = scale(broadside, -1.0)
            return FixedMatchAxes(
                broadside, d, axisVector('Z'),
                "P1 DIPOLE • horizontal",
                "P2 DIPOLE • elevation",
                "Match/dipole: zero angle is physical horizontal broadside; ground tilt remains visible in the elevation cut."
            )
        }

        return null
    }

    /**
     * 1.19.113: build the displayed 2D principal cuts directly from the already-calculated
     * coherent 3D pattern. This guarantees that a legacy MMANA stack cannot show a correct
     * summed 3D surface while the 2D panel accidentally follows a separate/single-array path.
     * Interpolation is performed in linear power, never directly in dB.
     */
    fun calculateFrom3D(model: MaaModel, points3D: List<Pattern3DPoint>): Result {
        require(points3D.isNotEmpty()) { "3D radiation pattern is empty." }

        data class GridPoint(val theta: Double, val phi: Double, val power: Double)
        val grid = points3D.map { p ->
            GridPoint(p.thetaDeg, p.phiDeg, Math.pow(10.0, p.db / 10.0))
        }
        val peakPoint = points3D.maxByOrNull { it.db } ?: points3D.first()
        val th0 = Math.toRadians(peakPoint.thetaDeg)
        val ph0 = Math.toRadians(peakPoint.phiDeg)
        val peakVector = normalize(doubleArrayOf(sin(th0) * cos(ph0), sin(th0) * sin(ph0), cos(th0)))
        val fixedMatch = fixedBeverageAxes(model, peakVector) ?: fixedMatchAxes(model, peakVector)

        // 1.19.113: legacy MMANA Yagi stacks are broadside/boresight arrays whose
        // electrical forward direction must remain on the geometric boom axis.  Using the
        // single maximum sample of a coarse 3D grid can move a wide main lobe by 5..15 deg
        // and makes the displayed 2D cuts look tilted relative to the antenna/ground plane.
        // Keep the sign from the actual coherent 3D maximum, but lock the axis itself to
        // the model geometry.  Non-stack/phased antennas keep the adaptive 3D direction.
        val isExpandedStack = model.antennaKind.contains("stack", ignoreCase = true) ||
            (model.sources.size > 1 && model.sources.all { it.raw.contains("[stack ") })
        // 1.19.114: a Yagi/parasitic array has a geometric boresight fixed by its boom.
        // Do NOT rotate the displayed coordinate system so that angle 0 follows the
        // strongest ground-reflected ray.  For a horizontal Yagi above real ground the
        // physical main lobe may be +10..20 deg elevation; the 2D vertical cut must show
        // that elevation RELATIVE TO THE HORIZONTAL BOOM/GROUND PLANE.  Re-centering the
        // cut on the peak made T-match Yagis look as if their whole pattern was tilted.
        val isParasiticYagi = model.analysisProfile == "PARASITIC_ARRAY" ||
            model.antennaKind.contains("Yagi", ignoreCase = true) ||
            model.antennaKind.contains("parasitic", ignoreCase = true)
        // 1.19.115: D-match is a strongly planar broadside antenna.  Its longest in-plane
        // dimension is NOT the radiation axis.  The correct boresight is the normal to the
        // wire plane; using mainAxis/peak-adaptive axes can make one of the two 2D cuts look
        // rotated or collapse onto the wrong plane.
        val isDMatch = model.title.contains("D-match", ignoreCase = true) ||
            model.title.contains("D match", ignoreCase = true) ||
            (model.fileNameHint?.contains("D-match", ignoreCase = true) == true) ||
            (model.fileNameHint?.contains("D match", ignoreCase = true) == true)
        val planarBroadside = isDMatch && model.isPlanar && model.planeNormalAxis != null
        // 1.19.113: for a compact MMANA stack the full expanded bounding box must NOT
        // be used to infer the boom axis.  Example: 4X12.MAA has four copies spaced in Y,
        // so spanY is larger than the boom spanX and the generic mainAxis heuristic would
        // incorrectly select Y as boresight.  Recover the original one-Yagi geometry from
        // the first repeated wire block and infer its axis independently.
        fun spanOf(ws: List<MaaWire>, axis: Char): Double {
            if (ws.isEmpty()) return 0.0
            return when (axis) {
                'X' -> ws.maxOf { max(it.x1, it.x2) } - ws.minOf { minOf(it.x1, it.x2) }
                'Y' -> ws.maxOf { max(it.y1, it.y2) } - ws.minOf { minOf(it.y1, it.y2) }
                else -> ws.maxOf { max(it.z1, it.z2) } - ws.minOf { minOf(it.z1, it.z2) }
            }
        }
        fun inferAxisFromWireBlock(ws: List<MaaWire>): Char {
            val sx = spanOf(ws, 'X')
            val sy = spanOf(ws, 'Y')
            val sz = spanOf(ws, 'Z')
            return when {
                sz > sx * 1.35 && sz > sy * 1.35 -> 'Z'
                sy > sx * 1.35 && sy > sz * 1.35 -> 'Y'
                else -> 'X'
            }
        }
        val stackCopies = if (isExpandedStack) model.sources.size.coerceAtLeast(1) else 1
        val baseWireCount = if (isExpandedStack && model.wires.size % stackCopies == 0) {
            model.wires.size / stackCopies
        } else model.wires.size
        val baseWires = model.wires.take(baseWireCount)
        val boomAxis = if (isExpandedStack) inferAxisFromWireBlock(baseWires) else model.mainAxis
        val geometricForward = axisVector(boomAxis)
        val broadsideForward = if (planarBroadside) axisVector(model.planeNormalAxis!!) else geometricForward
        val lockToBoom = isExpandedStack || isParasiticYagi || planarBroadside
        val forward = fixedMatch?.forward ?: if (lockToBoom) {
            // Preserve the real forward/back sign from the coherent 3D solution, but keep
            // boresight on the physical geometric axis. For D-match this is the normal to
            // its wire plane; for Yagi/stack it is the boom axis.
            if (dot(peakVector, broadsideForward) >= 0.0) broadsideForward else scale(broadsideForward, -1.0)
        } else {
            peakVector
        }

        val transverse1: DoubleArray
        val transverse2: DoubleArray
        if (fixedMatch != null) {
            transverse1 = fixedMatch.transverse1
            transverse2 = fixedMatch.transverse2
        } else if (planarBroadside) {
            // D-match: both display cuts must contain the broadside normal and one of the
            // two real in-plane axes. Choose P1 along the larger in-plane dimension and
            // P2 along the remaining orthogonal in-plane dimension.
            val normalAxis = model.planeNormalAxis!!
            val inPlane = listOf('X', 'Y', 'Z').filter { it != normalAxis }
            val p1Axis = inPlane.maxByOrNull { spanOf(model.wires, it) } ?: inPlane.first()
            val p2Axis = inPlane.first { it != p1Axis }
            transverse1 = axisVector(p1Axis)
            transverse2 = axisVector(p2Axis)
        } else if (isExpandedStack || isParasiticYagi) {
            // Principal planes of the ORIGINAL Yagi geometry.  For a normal horizontal
            // Yagi this gives P1 = boom/element plane and P2 = boom/vertical plane.
            // For compact stacks use only one base copy so stack spacing cannot masquerade
            // as the boom or element axis.
            val principalWires = if (isExpandedStack) baseWires else model.wires
            val candidates = listOf('X', 'Y', 'Z').filter { it != boomAxis }
            val p1Axis = candidates.maxByOrNull { spanOf(principalWires, it) } ?: candidates.first()
            transverse1 = axisVector(p1Axis)
            transverse2 = normalize(cross(forward, transverse1))
        } else if (model.isPlanar && model.planeNormalAxis != null) {
            val normalAxis = model.planeNormalAxis!!
            val inPlaneAxis = listOf('X', 'Y', 'Z').first { it != model.mainAxis && it != normalAxis }
            transverse1 = axisVector(inPlaneAxis)
            transverse2 = axisVector(normalAxis)
        } else {
            val refs = listOf('X', 'Y', 'Z').map { axis ->
                val sp = when (axis) {
                    'X' -> model.spanX
                    'Y' -> model.spanY
                    else -> model.spanZ
                }
                axisVector(axis) to sp
            }
            val ref = refs.maxByOrNull { (v, sp) ->
                val proj2 = (1.0 - dot(v, forward) * dot(v, forward)).coerceAtLeast(0.0)
                sp * sp * proj2
            }?.first ?: axisVector('Z')
            var t1 = subtract(ref, scale(forward, dot(ref, forward)))
            if (norm(t1) < 1e-8) {
                val fallback = if (abs(forward[2]) < 0.9) axisVector('Z') else axisVector('Y')
                t1 = subtract(fallback, scale(forward, dot(fallback, forward)))
            }
            transverse1 = normalize(t1)
            transverse2 = normalize(cross(forward, transverse1))
        }

        val thetaVals = points3D.map { it.thetaDeg }.distinct().sorted()
        val phiVals = points3D.map { it.phiDeg }.distinct().sorted()
        val thStep = thetaVals.zipWithNext().map { it.second - it.first }.filter { it > 1e-9 }.minOrNull() ?: 5.0
        val phStep = phiVals.zipWithNext().map { it.second - it.first }.filter { it > 1e-9 }.minOrNull() ?: 5.0
        val nTheta = thetaVals.size
        val nPhi = phiVals.size
        val power = DoubleArray(nTheta * nPhi) { 0.0 }
        val thetaIndex = thetaVals.withIndex().associate { it.value to it.index }
        val phiIndex = phiVals.withIndex().associate { it.value to it.index }
        grid.forEach { g ->
            val ti = thetaIndex[g.theta] ?: return@forEach
            val pi = phiIndex[g.phi] ?: return@forEach
            power[pi * nTheta + ti] = g.power
        }

        fun sampleDirection(n: DoubleArray): Double {
            val nz = n[2].coerceIn(-1.0, 1.0)
            val theta = Math.toDegrees(kotlin.math.acos(nz)).coerceIn(thetaVals.first(), thetaVals.last())
            var phi = Math.toDegrees(kotlin.math.atan2(n[1], n[0]))
            if (phi < 0.0) phi += 360.0
            if (phi >= 360.0) phi -= 360.0

            val tf = (theta - thetaVals.first()) / thStep
            val t0 = kotlin.math.floor(tf).toInt().coerceIn(0, nTheta - 1)
            val t1 = (t0 + 1).coerceAtMost(nTheta - 1)
            val ft = (tf - t0).coerceIn(0.0, 1.0)

            val pf = phi / phStep
            val p0raw = kotlin.math.floor(pf).toInt()
            val p0 = ((p0raw % nPhi) + nPhi) % nPhi
            val p1 = (p0 + 1) % nPhi
            val fp = (pf - kotlin.math.floor(pf)).coerceIn(0.0, 1.0)

            fun v(ti: Int, pi: Int) = power[pi * nTheta + ti]
            val a = v(t0, p0) * (1.0 - ft) + v(t1, p0) * ft
            val b = v(t0, p1) * (1.0 - ft) + v(t1, p1) * ft
            return (a * (1.0 - fp) + b * fp).coerceAtLeast(1e-30)
        }

        fun cut(axisB: DoubleArray): RawCut {
            val raw = DoubleArray(361)
            var peak = 0.0
            for (idx in raw.indices) {
                val a = Math.toRadians(idx - 180.0)
                val n = normalize(add(scale(forward, cos(a)), scale(axisB, sin(a))))
                val p = sampleDirection(n)
                raw[idx] = p
                if (p > peak) peak = p
            }
            return RawCut(raw, peak)
        }

        val raw1 = cut(transverse1)
        val raw2 = cut(transverse2)
        val commonPeak = max(raw1.peak, raw2.peak).coerceAtLeast(1e-30)
        val az = Math.toDegrees(kotlin.math.atan2(forward[1], forward[0])).let { if (it < 0.0) it + 360.0 else it }
        val el = Math.toDegrees(kotlin.math.asin(forward[2].coerceIn(-1.0, 1.0)))
        val dir = "AZ %.1f° EL %.1f°".format(java.util.Locale.US, az, el)
        return Result(
            previewTop = finishPreview(raw1.power, commonPeak),
            previewSide = finishPreview(raw2.power, commonPeak),
            principalPlane1Label = fixedMatch?.label1 ?: "P1 MAIN • $dir",
            principalPlane2Label = fixedMatch?.label2 ?: "P2 ORTHO • $dir",
            note = when {
                fixedMatch != null -> "2D cuts from coherent 3D NEC-2 FULL field; ${fixedMatch.note} Linear-power interpolation."
                isExpandedStack -> "2D cuts from coherent 3D NEC-2 FULL field; stack boresight recovered from original one-Yagi wire block; linear-power interpolation."
                planarBroadside -> "2D cuts from coherent 3D NEC-2 FULL field; D-match broadside locked to the physical normal of the antenna plane; P1/P2 use the two in-plane axes; linear-power interpolation."
                isParasiticYagi -> "2D cuts from coherent 3D NEC-2 FULL field; Yagi boresight locked to the physical boom/ground reference so real elevation tilt is shown inside P2; linear-power interpolation."
                else -> "2D cuts extracted from the same coherent 3D NEC-2 FULL field; linear-power interpolation."
            }
        )
    }

    /** Spatial display surface. 1.19.35 prefers the solver-native OpenNEC RP grid. */
    fun calculate3D(
        model: MaaModel,
        solved: OpenNecFull.Result,
        thetaStepDeg: Double = 5.0,
        phiStepDeg: Double = 5.0,
        onProgress: ((doneRows: Int, totalRows: Int) -> Unit)? = null
    ): List<Pattern3DPoint> {
        require(solved.segments.isNotEmpty()) { "NEC-2 FULL returned no currents for the 3D radiation pattern." }
        require(model.frequencyMHz > 0.0) { "Invalid frequency." }
        val thStep = thetaStepDeg.coerceIn(0.5, 30.0)
        val phStep = phiStepDeg.coerceIn(0.5, 30.0)
        val thetas = mutableListOf<Double>().apply {
            var v = 0.0
            while (v < 180.0 - 1e-9) { add(v); v += thStep }
            if (lastOrNull()?.let { kotlin.math.abs(it - 180.0) > 1e-9 } != false) add(180.0)
        }
        val phis = mutableListOf<Double>().apply {
            var v = 0.0
            while (v < 360.0 - 1e-9) { add(v); v += phStep }
        }

        val sampler = nativeSamplerOrNull(solved.nativePattern)
        data class Raw3D(val theta: Double, val phi: Double, val power: Double)
        val raw = ArrayList<Raw3D>(thetas.size * phis.size)
        var peak = 0.0

        if (sampler != null) {
            phis.forEachIndexed { rowIndex, phiDeg ->
                val phi = Math.toRadians(phiDeg)
                val cp = cos(phi)
                val sp = sin(phi)
                for (thetaDeg in thetas) {
                    val theta = Math.toRadians(thetaDeg)
                    val st = sin(theta)
                    val n = doubleArrayOf(st * cp, st * sp, cos(theta))
                    val power = sampler.powerForDirection(n, model.groundType != 0)
                    raw += Raw3D(thetaDeg, phiDeg, power)
                    if (power > peak) peak = power
                }
                onProgress?.invoke(rowIndex + 1, phis.size)
            }
        } else {
            // Compatibility fallback for an older native library/payload.
            val k = 2.0 * PI / model.wavelengthM
            phis.forEachIndexed { rowIndex, phiDeg ->
                val phi = Math.toRadians(phiDeg)
                val cp = cos(phi)
                val sp = sin(phi)
                for (thetaDeg in thetas) {
                    val theta = Math.toRadians(thetaDeg)
                    val st = sin(theta)
                    val n = doubleArrayOf(st * cp, st * sp, cos(theta))
                    val power = fieldPower(solved.segments, k, n, model.groundType == 1 || model.groundType == 2)
                    raw += Raw3D(thetaDeg, phiDeg, power)
                    if (power > peak) peak = power
                }
                onProgress?.invoke(rowIndex + 1, phis.size)
            }
        }

        val norm = peak.coerceAtLeast(1e-30)
        return raw.map { q ->
            val db = (10.0 * log10((q.power / norm).coerceAtLeast(1e-8))).coerceAtLeast(-80.0)
            Pattern3DPoint(q.theta, q.phi, db)
        }
    }


    /**
     * A JNI/native RP payload is used only when it contains a meaningful set of finite gain
     * samples.  This prevents a partially initialized OpenNEC rpat buffer from collapsing the
     * whole 3D surface to the -80 dB floor.  The exact NEC A/B/C renderer remains the fail-safe.
     */
    private fun nativeSamplerOrNull(points: List<OpenNecFull.NativePatternPoint>): NativePatternSampler? {
        if (points.isEmpty()) return null
        val usable = points.filter { p ->
            p.thetaDeg.isFinite() && p.phiDeg.isFinite() && p.gainDb.isFinite() && p.gainDb > -290.0
        }
        return if (usable.size >= 100) NativePatternSampler(usable) else null
    }

    /**
     * Regular 2.5° native RP sampler. OpenNEC reports theta=0..180 and phi=0..360.
     * Interpolation is done in LINEAR power, never in dB, so cuts at 1° stay smooth without
     * inventing a second phase-summation path. Missing lower-hemisphere ground points are zero.
     */
    private class NativePatternSampler(points: List<OpenNecFull.NativePatternPoint>) {
        private val step = 2.5
        private val nTheta = 73
        private val nPhi = 145
        private val power = DoubleArray(nTheta * nPhi) { Double.NaN }

        init {
            points.forEach { p ->
                val ti = kotlin.math.round(p.thetaDeg / step).toInt()
                val pi = kotlin.math.round(p.phiDeg / step).toInt()
                if (ti in 0 until nTheta && pi in 0 until nPhi) {
                    val db = p.gainDb.coerceIn(-300.0, 300.0)
                    power[pi * nTheta + ti] = Math.pow(10.0, db / 10.0)
                }
            }
        }

        fun powerForDirection(n: DoubleArray, hasGround: Boolean): Double {
            if (hasGround && n[2] < -1e-10) return 0.0
            val nz = n[2].coerceIn(-1.0, 1.0)
            val theta = Math.toDegrees(kotlin.math.acos(nz)).coerceIn(0.0, 180.0)
            var phi = Math.toDegrees(kotlin.math.atan2(n[1], n[0]))
            if (phi < 0.0) phi += 360.0
            if (phi >= 360.0) phi -= 360.0
            return interpolate(theta, phi)
        }

        private fun value(ti: Int, pi: Int): Double {
            val v = power[pi.coerceIn(0, nPhi - 1) * nTheta + ti.coerceIn(0, nTheta - 1)]
            return if (v.isFinite()) v else 0.0
        }

        private fun interpolate(theta: Double, phi: Double): Double {
            val tf = theta / step
            val pf = phi / step
            val t0 = kotlin.math.floor(tf).toInt().coerceIn(0, nTheta - 1)
            val t1 = (t0 + 1).coerceAtMost(nTheta - 1)
            val p0 = kotlin.math.floor(pf).toInt().coerceIn(0, nPhi - 2)
            val p1 = (p0 + 1).coerceAtMost(nPhi - 1)
            val ft = (tf - t0).coerceIn(0.0, 1.0)
            val fp = (pf - p0).coerceIn(0.0, 1.0)
            val a = value(t0, p0) * (1.0 - ft) + value(t1, p0) * ft
            val b = value(t0, p1) * (1.0 - ft) + value(t1, p1) * ft
            return (a * (1.0 - fp) + b * fp).coerceAtLeast(0.0)
        }
    }

    private fun farFieldNativeRaw(
        sampler: NativePatternSampler,
        hasGround: Boolean,
        axisA: DoubleArray,
        axisB: DoubleArray
    ): RawCut {
        val raw = DoubleArray(361)
        var peak = 0.0
        for (idx in raw.indices) {
            val angle = Math.toRadians(idx - 180.0)
            val n = add(scale(axisA, cos(angle)), scale(axisB, sin(angle)))
            val p = sampler.powerForDirection(n, hasGround)
            raw[idx] = p
            if (p > peak) peak = p
        }
        return RawCut(raw, peak)
    }

    private fun farFieldRaw(
        segments: List<OpenNecFull.SegmentCurrent>,
        k: Double,
        axisA: DoubleArray,
        axisB: DoubleArray,
        usePerfectGroundImage: Boolean
    ): RawCut {
        val raw = DoubleArray(361)
        var peak = 0.0
        for (idx in raw.indices) {
            val angle = Math.toRadians(idx - 180.0)
            val n = add(scale(axisA, cos(angle)), scale(axisB, sin(angle)))
            val power = fieldPower(segments, k, n, usePerfectGroundImage)
            raw[idx] = power
            if (power > peak) peak = power
        }
        return RawCut(raw, peak)
    }

    /**
     * Far-field power in direction n from the solved NEC solution.
     *
     * Since 1.19.30 the preferred path reproduces NEC's segment radiation integral from the
     * solver's A/B/C sinusoidal current-expansion coefficients. A single complex centre current
     * multiplied by a finite-segment sinc is only exact for a uniform-current segment and can
     * noticeably corrupt phase-sensitive end-fire arrays (Yagi/LPDA) even when input Z is right.
     *
     * OpenNEC uses, for each segment (geometry lengths are in wavelengths internally):
     *   omega = -(n dot u), el = pi * halfLengthLambda
     *   rr = a*A.re + b*B.im + c*C.re
     *   ri = a*A.im - b*B.re + c*C.im
     * followed by exp(+j 2*pi n dot r/lambda).
     *
     * If an old native payload without A/B/C is ever parsed, all segments fall back together to
     * the previous centre-current approximation; exact and approximate amplitudes are never mixed.
     *
     * For MMANA G=1/G=2 the FULL deck uses ideal PEC (`GN 1`). The image current is
     * J_image=(-Jx,-Jy,+Jz) at z -> -z. Radiation below the PEC plane is blocked.
     */
    private fun fieldPower(
        segments: List<OpenNecFull.SegmentCurrent>,
        k: Double,
        n: DoubleArray,
        usePerfectGroundImage: Boolean
    ): Double {
        if (usePerfectGroundImage && n[2] < -1e-10) return 0.0

        var ex = C(0.0, 0.0)
        var ey = C(0.0, 0.0)
        var ez = C(0.0, 0.0)
        val useNecBasis = segments.all { it.hasNecCurrentBasis }

        fun sinc(x: Double): Double = if (abs(x) < 1.0e-7) 1.0 - x * x / 6.0 else sin(x) / x

        fun necBasisAmplitude(s: OpenNecFull.SegmentCurrent, ndotu: Double): C {
            val omega = -ndotu
            // OpenNEC geometry.half_len is half segment length in wavelengths.
            // lambda = 2*pi/k => pi*halfLen/lambda = k*length/4.
            val el = 0.25 * k * s.lengthM
            val sill = omega * el
            val top = el + sill
            val bot = el - sill
            val a = if (abs(omega) >= 1.0e-7) {
                2.0 * sin(sill) / omega
            } else {
                (2.0 - omega * omega * el * el / 3.0) * el
            }
            val too = sinc(top)
            val boo = sinc(bot)
            val b = el * (boo - too)
            val c = el * (boo + too)
            return C(
                a * s.basisARe + b * s.basisBIm + c * s.basisCRe,
                a * s.basisAIm - b * s.basisBRe + c * s.basisCIm
            )
        }

        fun accumulate(
            s: OpenNecFull.SegmentCurrent,
            zM: Double,
            ux: Double,
            uy: Double,
            uz: Double,
            currentSign: Double
        ) {
            val ndotu = n[0] * ux + n[1] * uy + n[2] * uz
            // n x (u x n): only the transverse part radiates.
            val vx = ux - n[0] * ndotu
            val vy = uy - n[1] * ndotu
            val vz = uz - n[2] * ndotu
            val phase = k * (n[0] * s.xM + n[1] * s.yM + n[2] * zM)
            val phasor = C(cos(phase), sin(phase))

            val segmentAmp = if (useNecBasis) {
                necBasisAmplitude(s, ndotu) * currentSign
            } else {
                // Compatibility only: 1.19.29 and earlier payloads had one centre current/segment.
                val current = C(s.currentReA * currentSign, s.currentImA * currentSign)
                val q = 0.5 * k * s.lengthM * ndotu
                val finiteSegment = if (abs(q) < 1e-8) 1.0 else sin(q) / q
                current * (s.lengthM * finiteSegment)
            }
            val amp = segmentAmp * phasor
            ex = ex + amp * vx
            ey = ey + amp * vy
            ez = ez + amp * vz
        }

        for (s in segments) {
            accumulate(s, s.zM, s.ux, s.uy, s.uz, +1.0)
            if (usePerfectGroundImage) {
                // Mirror direction + reverse scalar current => Jimg=(-Jx,-Jy,+Jz).
                accumulate(s, -s.zM, s.ux, s.uy, -s.uz, -1.0)
            }
        }
        return ex.mag2() + ey.mag2() + ez.mag2()
    }

    private fun finishPreview(raw: DoubleArray, peakIn: Double): MaaPatternPreview {
        val peak = peakIn.coerceAtLeast(1e-30)
        val points = raw.indices.map { idx ->
            val db = (10.0 * log10((raw[idx] / peak).coerceAtLeast(1e-6))).coerceAtLeast(-60.0)
            MaaPatternPoint(idx - 180.0, db)
        }
        val peakIdx = raw.indices.maxByOrNull { raw[it] } ?: 180
        val oppositeIdx = (peakIdx + 180).let { if (it > 360) it - 360 else it }
        val fb = points[peakIdx].db - points[oppositeIdx].db

        fun crossing(start: Int, step: Int): Double? {
            var i = start + step
            while (i in 0..360) {
                if (points[i].db <= -3.0) {
                    val j = i - step
                    val a = points[j]
                    val b = points[i]
                    val den = b.db - a.db
                    if (abs(den) < 1e-12) return b.angleDeg
                    val t = (-3.0 - a.db) / den
                    return a.angleDeg + (b.angleDeg - a.angleDeg) * t
                }
                i += step
            }
            return null
        }

        val left = crossing(peakIdx, -1)
        val right = crossing(peakIdx, 1)
        val hpbw = if (left != null && right != null && right >= left) right - left else null
        val peakAngle = points[peakIdx].angleDeg
        val exclusion = ((hpbw ?: 30.0) * 0.75).coerceAtLeast(10.0)
        fun angularDistance(a: Double, b: Double): Double {
            var d = abs(a - b) % 360.0
            if (d > 180.0) d = 360.0 - d
            return d
        }
        var side = -60.0
        for (i in 1 until points.lastIndex) {
            if (angularDistance(points[i].angleDeg, peakAngle) >= exclusion &&
                points[i].db >= points[i - 1].db && points[i].db >= points[i + 1].db
            ) {
                side = max(side, points[i].db)
            }
        }
        return MaaPatternPreview(points, hpbw, fb, side)
    }

    private fun principalCuts(
        model: MaaModel,
        sampler: NativePatternSampler?,
        segments: List<OpenNecFull.SegmentCurrent>,
        k: Double
    ): Pair<PlaneCut, PlaneCut> {
        val omni = model.omniSymmetryAxis
        if (omni != null) {
            val transverse = listOf('X', 'Y', 'Z').filter { it != omni }
            fun span(axis: Char): Double = when (axis) {
                'X' -> model.spanX
                'Y' -> model.spanY
                else -> model.spanZ
            }
            val t1 = transverse.maxByOrNull(::span) ?: transverse.first()
            val t2 = transverse.first { it != t1 }
            return PlaneCut(axisVector(t1), axisVector(t2), "AZ $t1-$t2") to
                PlaneCut(axisVector(t1), axisVector(omni), "EL $t1-$omni")
        }

        // 1.19.116: Match-folder models use the same physical plane policy as 2D-from-3D.
        // This prevents Gamma/Omega/T/D matching wires from masquerading as the radiator axis.
        val matchPeak = findMainLobeDirection(model, sampler, segments, k)
        (fixedBeverageAxes(model, matchPeak) ?: fixedMatchAxes(model, matchPeak))?.let { m ->
            return PlaneCut(m.forward, m.transverse1, m.label1) to
                PlaneCut(m.forward, m.transverse2, m.label2)
        }

        // For every non-omnidirectional topology, derive the two displayed principal cuts from
        // the ACTUAL full-field main-lobe direction. This fixes rotated/crossed/phased arrays
        // whose lobe is not contained in one of the global XY/XZ/YZ planes.
        val forward = findMainLobeDirection(model, sampler, segments, k)

        // Pick the geometrically most meaningful transverse reference axis. The projection makes
        // it exactly perpendicular to the full-pattern main-lobe vector.
        val refs = listOf('X', 'Y', 'Z').map { axis ->
            val sp = when (axis) {
                'X' -> model.spanX
                'Y' -> model.spanY
                else -> model.spanZ
            }
            axisVector(axis) to sp
        }
        val ref = refs.maxByOrNull { (v, sp) ->
            val proj2 = (1.0 - dot(v, forward) * dot(v, forward)).coerceAtLeast(0.0)
            sp * sp * proj2
        }?.first ?: axisVector('Z')
        var transverse1 = subtract(ref, scale(forward, dot(ref, forward)))
        if (norm(transverse1) < 1e-8) {
            val fallback = if (abs(forward[2]) < 0.9) axisVector('Z') else axisVector('Y')
            transverse1 = subtract(fallback, scale(forward, dot(fallback, forward)))
        }
        transverse1 = normalize(transverse1)
        val transverse2 = normalize(cross(forward, transverse1))

        val az = Math.toDegrees(kotlin.math.atan2(forward[1], forward[0])).let { if (it < 0.0) it + 360.0 else it }
        val el = Math.toDegrees(kotlin.math.asin(forward[2].coerceIn(-1.0, 1.0)))
        val dir = "AZ %.1f° EL %.1f°".format(java.util.Locale.US, az, el)
        return PlaneCut(forward, transverse1, "P1 MAIN • $dir") to
            PlaneCut(forward, transverse2, "P2 ORTHO • $dir")
    }

    private fun findMainLobeDirection(
        model: MaaModel,
        sampler: NativePatternSampler?,
        segments: List<OpenNecFull.SegmentCurrent>,
        k: Double
    ): DoubleArray {
        if (sampler != null) {
            var best = axisVector(model.mainAxis)
            var bestPower = -1.0
            var theta = 0.0
            while (theta <= 180.0 + 1e-9) {
                val th = Math.toRadians(theta)
                var phi = 0.0
                while (phi < 360.0 - 1e-9) {
                    val ph = Math.toRadians(phi)
                    val n = doubleArrayOf(sin(th) * cos(ph), sin(th) * sin(ph), cos(th))
                    val p = sampler.powerForDirection(n, model.groundType != 0)
                    if (p > bestPower) { bestPower = p; best = n }
                    phi += 2.5
                }
                theta += 2.5
            }
            return normalize(best)
        }

        // Compatibility fallback for old native payloads: a 10° full-sphere search is enough to
        // orient the 1° display cuts; the cuts themselves still use the exact coherent field sum.
        var best = axisVector(model.mainAxis)
        var bestPower = -1.0
        var theta = 0.0
        while (theta <= 180.0 + 1e-9) {
            val th = Math.toRadians(theta)
            var phi = 0.0
            while (phi < 360.0 - 1e-9) {
                val ph = Math.toRadians(phi)
                val n = doubleArrayOf(sin(th) * cos(ph), sin(th) * sin(ph), cos(th))
                val p = fieldPower(segments, k, n, model.groundType == 1 || model.groundType == 2)
                if (p > bestPower) { bestPower = p; best = n }
                phi += 10.0
            }
            theta += 10.0
        }
        return normalize(best)
    }

    private fun axisVector(axis: Char): DoubleArray = when (axis) {
        'X' -> doubleArrayOf(1.0, 0.0, 0.0)
        'Y' -> doubleArrayOf(0.0, 1.0, 0.0)
        else -> doubleArrayOf(0.0, 0.0, 1.0)
    }

    private fun dot(a: DoubleArray, b: DoubleArray) = a[0]*b[0] + a[1]*b[1] + a[2]*b[2]
    private fun norm(a: DoubleArray) = sqrt(dot(a, a))
    private fun normalize(a: DoubleArray): DoubleArray {
        val n = norm(a).coerceAtLeast(1e-30)
        return doubleArrayOf(a[0]/n, a[1]/n, a[2]/n)
    }
    private fun scale(a: DoubleArray, s: Double) = doubleArrayOf(a[0]*s, a[1]*s, a[2]*s)
    private fun subtract(a: DoubleArray, b: DoubleArray) = doubleArrayOf(a[0]-b[0], a[1]-b[1], a[2]-b[2])
    private fun cross(a: DoubleArray, b: DoubleArray) = doubleArrayOf(
        a[1]*b[2] - a[2]*b[1],
        a[2]*b[0] - a[0]*b[2],
        a[0]*b[1] - a[1]*b[0]
    )
    private fun add(a: DoubleArray, b: DoubleArray) =
        doubleArrayOf(a[0] + b[0], a[1] + b[1], a[2] + b[2])
}
