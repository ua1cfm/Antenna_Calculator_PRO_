package ua1cfm.cstffs

import java.util.Locale

object ExportUtils {
    fun resultsText(dish: DishResult, ffs: FfsResult): String {
        val spill = ffs.spilloverEfficiency
        val taper = ffs.taperEfficiency
        val phase = ffs.phaseAnalysis?.phaseEfficiency
        val phaseOpt = ffs.phaseAnalysis?.optimizedPhaseEfficiency
        val apertureNoPhase = if (spill != null && taper != null) spill * taper * dish.ruzeEfficiency else null
        val apertureCurrent = if (apertureNoPhase != null && phase != null) apertureNoPhase * phase else apertureNoPhase
        val apertureOpt = if (apertureNoPhase != null && phaseOpt != null) apertureNoPhase * phaseOpt else null
        fun directivity(eta: Double?) = eta?.let { 10.0 * kotlin.math.log10(dish.idealDirectivityLinear * it) }
        fun gain(d: Double?) = if (d != null && ffs.radiationEfficiency != null && ffs.radiationEfficiency > 0.0)
            d + 10.0 * kotlin.math.log10(ffs.radiationEfficiency) else d
        val dCurrent = directivity(apertureCurrent)
        val dOpt = directivity(apertureOpt)
        return buildString {
            appendLine("Antenna Calculator PRO v1.19.125")
            appendLine("© 2026 UA1CFM")
            appendLine()
            appendLine("Frequency_GHz=${n(ffs.selectedFrequencyGHz)}")
            appendLine("Available_frequencies_GHz=${ffs.availableFrequenciesGHz.joinToString(";")}")
            appendLine("FFS_Origin_X_m=${n(ffs.sourcePositionXM)}")
            appendLine("FFS_Origin_Y_m=${n(ffs.sourcePositionYM)}")
            appendLine("FFS_Origin_Z_m=${n(ffs.sourcePositionZM)}")
            appendLine("Phase_center_absolute_Z_m=${n(
                if (ffs.sourcePositionZM != null && ffs.phaseAnalysis != null)
                    ffs.sourcePositionZM + ffs.phaseAnalysis.optimalPhaseCenterZM
                else null
            )}")
            appendLine("D_m=${n(dish.diameterM)}")
            appendLine("F_m=${n(dish.focalM)}")
            appendLine("F_D=${n(dish.focalM / dish.diameterM)}")
            appendLine("Theta_edge_deg=${n(dish.edgeAngleDeg)}")
            appendLine("Feed_Directivity_dBi=${n(ffs.directivityDbi)}")
            appendLine("Feed_Gain_dBi=${n(ffs.gainDbi)}")
            appendLine("Spillover_efficiency=${n(spill)}")
            appendLine("Taper_efficiency=${n(taper)}")
            appendLine("Ruze_efficiency=${n(dish.ruzeEfficiency)}")
            appendLine("Phase_efficiency_reference=${n(phase)}")
            appendLine("Phase_center_Z_m=${n(ffs.phaseAnalysis?.optimalPhaseCenterZM)}")
            appendLine("Phase_efficiency_optimized=${n(phaseOpt)}")
            appendLine("Phase_RMS_reference_deg=${n(ffs.phaseAnalysis?.referenceRmsPhaseDeg)}")
            appendLine("Phase_RMS_optimized_deg=${n(ffs.phaseAnalysis?.optimizedRmsPhaseDeg)}")
            appendLine("Aperture_efficiency_no_phase=${n(apertureNoPhase)}")
            appendLine("Aperture_efficiency_reference=${n(apertureCurrent)}")
            appendLine("Aperture_efficiency_optimized=${n(apertureOpt)}")
            appendLine("System_Directivity_reference_dBi=${n(dCurrent)}")
            appendLine("System_Gain_reference_dBi=${n(gain(dCurrent))}")
            appendLine("System_Directivity_optimized_dBi=${n(dOpt)}")
            appendLine("System_Gain_optimized_dBi=${n(gain(dOpt))}")
        }
    }

    fun patternCsv(ffs: FfsResult): String = buildString {
        appendLine("theta_deg,phi_deg,normalized_dB")
        ffs.surface3D.forEach { appendLine("${f(it.thetaDeg)},${f(it.phiDeg)},${f(it.db)}") }
    }

    private fun n(v: Double?): String = v?.let { f(it) } ?: ""
    private fun f(v: Double): String = String.format(Locale.US, "%.8f", v)
}
