package ua1cfm.cstffs

import kotlin.math.ln

/**
 * 1.19.106 corpus-learning layer for MMANA models.
 *
 * The bundled 722-model archive is already curated into meaningful folders.  Instead of
 * throwing that information away, this small learner treats the folder/category layout as
 * labels and learns which filename/title tokens are associated with each corpus category.
 *
 * Important: this layer does NOT replace NEC-2 and does not manufacture impedance or pattern
 * data.  It is used only to interpret/present a model and to provide semantic hints to the
 * existing geometry-aware classifier.
 */
data class MaaCorpusSeed(
    val path: String,
    val title: String,
    val frequencyMHz: Double?,
    val category: String
)

data class MaaCorpusProfile(
    val category: String,
    val confidencePercent: Int,
    val role: String,
    val feedVariant: String,
    val shortening: String,
    val ground: String,
    val evidence: String
)

class MaaCorpusLearner(seeds: List<MaaCorpusSeed>) {
    private val stopWords = setOf(
        "mhz", "antenna", "ant", "the", "with", "for", "and", "maa", "model", "wire",
        "hf", "vhf", "m", "cm", "mm", "of", "in", "to"
    )

    private val normalizedSeeds = seeds.toList()
    private val categories = normalizedSeeds.map { it.category }.distinct().sorted()
    private val byExactPath = normalizedSeeds.associateBy { normalizePath(it.path) }
    private val tokenCategoryCount: Map<String, Map<String, Int>>

    init {
        val tmp = linkedMapOf<String, MutableMap<String, Int>>()
        for (seed in normalizedSeeds) {
            val text = "${seed.path} ${seed.title}"
            for (token in tokens(text)) {
                val perCategory = tmp.getOrPut(token) { linkedMapOf() }
                perCategory[seed.category] = (perCategory[seed.category] ?: 0) + 1
            }
        }
        tokenCategoryCount = tmp.mapValues { it.value.toMap() }
    }

    fun profile(model: MaaModel, sourcePath: String?): MaaCorpusProfile {
        val path = sourcePath.orEmpty()
        val exact = byExactPath[normalizePath(path)]
        val categoryPrediction = if (exact != null) {
            exact.category to 100
        } else {
            predictCategory(model, path)
        }

        val semantic = (path + " " + model.fileNameHint.orEmpty() + " " + model.title).lowercase()
        val category = categoryPrediction.first
        val stackInfo = inferStackInfo(category, semantic)
        val role = stackInfo ?: inferRole(category, semantic)
        val feed = if (stackInfo != null && model.sources.size <= 1) {
            "single MMANA source for stacked system"
        } else inferFeed(semantic, model)
        val shortening = inferShortening(category, semantic, model)
        val ground = when (model.groundType) {
            1 -> "perfect ground"
            2 -> "real ground"
            else -> "free space"
        }

        val evidenceParts = mutableListOf<String>()
        if (exact != null) evidenceParts += "archive folder"
        if (path.isNotBlank()) evidenceParts += "path/name"
        if (model.title.isNotBlank()) evidenceParts += "MAA title"
        evidenceParts += "geometry"
        if (model.sources.isNotEmpty() || model.sourceWireIndex != null) evidenceParts += "source"
        if (model.loads.isNotEmpty()) evidenceParts += "${model.loads.size} load(s)"

        return MaaCorpusProfile(
            category = category,
            confidencePercent = categoryPrediction.second,
            role = role,
            feedVariant = feed,
            shortening = shortening,
            ground = ground,
            evidence = evidenceParts.distinct().joinToString(" + ")
        )
    }

    private fun predictCategory(model: MaaModel, path: String): Pair<String, Int> {
        if (categories.isEmpty()) return "Unclassified" to 0
        val score = categories.associateWith { 0.0 }.toMutableMap()
        val inputTokens = tokens("$path ${model.fileNameHint.orEmpty()} ${model.title}")

        for (token in inputTokens) {
            val counts = tokenCategoryCount[token] ?: continue
            val total = counts.values.sum().coerceAtLeast(1)
            // Rare/category-specific words receive more weight than generic words.
            for ((category, count) in counts) {
                val purity = count.toDouble() / total.toDouble()
                score[category] = (score[category] ?: 0.0) + ln(1.0 + count) * (0.35 + 1.65 * purity)
            }
        }

        // Geometry-aware priors. These are deliberately weak; NEC geometry remains authoritative.
        val kind = model.antennaKind.lowercase()
        fun boost(category: String, amount: Double) {
            if (category in score) score[category] = (score[category] ?: 0.0) + amount
        }
        when {
            "feeder" in kind || "balun" in kind || "transformer" in kind -> {
                boost("Feeders", 3.0); boost("Radiation of feeder", 2.0); boost("Match", 1.0)
            }
            "yagi" in kind || "parasitic" in kind || "lpda" in kind -> {
                boost("HF beams", 1.5); boost("VHF beams", 1.5)
            }
            "phased" in kind -> boost("Phased", 2.5)
            "stack" in kind -> boost("Stacks", 2.5)
            "aperiodic" in kind || "beverage" in kind || "rhomb" in kind -> boost("Aperiodic", 2.0)
        }
        if (model.loads.isNotEmpty()) {
            boost("Short", 0.8)
            boost("Match", 0.8)
            boost("HF multibands", 0.4)
        }

        val ordered = score.entries.sortedByDescending { it.value }
        val best = ordered.firstOrNull() ?: return "Unclassified" to 0
        val second = ordered.getOrNull(1)?.value ?: 0.0
        if (best.value <= 0.0) return "Unclassified" to 25
        val margin = ((best.value - second) / best.value).coerceIn(0.0, 1.0)
        val evidenceStrength = (best.value / 8.0).coerceIn(0.0, 1.0)
        val confidence = (50.0 + 30.0 * margin + 15.0 * evidenceStrength).toInt().coerceIn(50, 95)
        return best.key to confidence
    }


    private fun inferStackInfo(category: String, s: String): String? {
        if (!category.equals("Stacks", true) && "stack" !in s) return null
        val m = Regex("""\b(\d+)\s*[x×х]\s*(\d+)\s*el(?:e)?""", RegexOption.IGNORE_CASE).find(s)
            ?: return null
        val stackCount = m.groupValues[1].toIntOrNull() ?: return null
        val elements = m.groupValues[2].toIntOrNull() ?: return null
        if (stackCount < 2 || elements < 2) return null
        return "$stackCount × $elements-element Yagi stack (${stackCount * elements} radiating elements total)"
    }

    private fun inferRole(category: String, s: String): String = when {
        category.equals("Feeders", true) -> "feeder / transmission-line model"
        category.equals("Radiation of feeder", true) -> "feeder-radiation model"
        category.equals("Match", true) -> "matching / feed-network variant"
        category.equals("Receive", true) -> "receiving-antenna variant"
        category.equals("Short", true) -> "electrically-short antenna variant"
        category.equals("Phased", true) -> "phased-array variant"
        category.equals("Stacks", true) -> "stacked-array variant"
        "tuner" in s || "match" in s -> "antenna with matching network"
        else -> "radiating antenna model"
    }

    private fun inferFeed(s: String, model: MaaModel): String = when {
        "gamma" in s -> "gamma match"
        "omega" in s -> "omega match"
        "hairpin" in s -> "hairpin match"
        "t-match" in s || "t match" in s -> "T-match"
        "balun" in s -> "balun"
        "tuner" in s || "ant+tuner" in s -> "antenna tuner / matching network"
        "open sleeve" in s || "opensleeve" in s || "sleeve" in s || "sleve" in s -> "open-sleeve coupling"
        "end-fed" in s || "end fed" in s -> "end-fed"
        "windom" in s || "ocf" in s || "offset" in s -> "off-centre feed"
        "j-ant" in s || "j pole" in s || "j-pole" in s -> "J-type matching section"
        "feeder" in s || "feeders" in s -> "explicit feeder section"
        model.sources.size > 1 -> "${model.sources.size}-source / phased feed"
        model.sourceWireIndex != null -> "single MMANA source"
        else -> "source not explicitly identified"
    }

    private fun inferShortening(category: String, s: String, model: MaaModel): String = when {
        "trap" in s -> "trap-loaded / multiband"
        "coil" in s || "loading coil" in s -> "inductively loaded"
        "/short/" in normalizePath("/$s/") || category.equals("Short", true) || " short" in s -> {
            if (model.loads.isNotEmpty()) "shortened, explicit load(s)" else "shortened by geometry"
        }
        model.loads.any { it.kind == 0 && kotlin.math.abs(it.value1) > 0.0 } -> "inductively/capacitively loaded"
        model.loads.isNotEmpty() -> "loaded / matched"
        else -> "no shortening cue"
    }

    private fun normalizePath(s: String): String = s.replace('\\', '/').trim('/').lowercase()

    private fun tokens(s: String): Set<String> = s.lowercase()
        .replace('\\', '/')
        .split(Regex("[^a-z0-9а-яё+.-]+"))
        .map { it.trim('.', '-', '_') }
        .filter { it.length >= 2 && it !in stopWords }
        .toSet()

}
