package ua1cfm.cstffs

import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Near electromagnetic-field viewer fed by complex NEC segment currents (NEC-2 FULL preferred).
 *
 * Solved segment-centre currents are interpolated in complex form and each NEC segment is split
 * into a few shorter integration cells. This suppresses artificial "beads" at segment centres
 * without changing the NEC solution or the displayed input impedance. H keeps the 1/r^2 and 1/r
 * terms. E uses the matching Hertzian-current-element vector kernel and keeps 1/r^3, 1/r^2 and
 * 1/r terms. The same complex segment current is used for both fields, preserving phase between
 * all contributors.
 *
 * This is an engineering near-field visualization, not a replacement for a reference NEC
 * finite-segment near-field solution. Values extremely close to a thin wire are regularized.
 */
object NearFieldEngine {
    enum class Plane { XY, XZ, YZ }

    /**
     * Automatic square observation frame for the selected 2D plane.
     *
     * 1.19.15 deliberately keeps the antenna away from the frame edges:
     *   margin on EACH side = max(0.5 * projected antenna span, 0.5 * wavelength).
     * Thus the antenna occupies at most 50% of the frame and even a short dipole gets at least
     * half a wavelength of surrounding field on every side. This changes only observation-window
     * coordinates; NEC currents and the E/H/B/S kernels are untouched.
     */
    fun autoHalfSpanLambda(
        model: MaaModel,
        plane: Plane
    ): Double {
        val projectedMaxSpanM = when (plane) {
            Plane.XY -> max(model.spanX, model.spanY)
            Plane.XZ -> max(model.spanX, model.spanZ)
            Plane.YZ -> max(model.spanY, model.spanZ)
        }.coerceAtLeast(0.0)
        val lambda = model.wavelengthM
        if (lambda <= 0.0) return 0.5
        val marginEachSideM = max(0.5 * projectedMaxSpanM, 0.5 * lambda)
        val halfSpanM = 0.5 * projectedMaxSpanM + marginEachSideM
        return (halfSpanM / lambda).coerceAtLeast(0.5)
    }

    data class Progress(
        val percent: Int,
        val completedRows: Int,
        val totalRows: Int
    )

    class Cancelled : RuntimeException("Field calculation was canceled by the user.")

    data class Grid(
        val plane: Plane,
        val size: Int,
        val halfSpanM: Double,
        val fixedCoordinateM: Double,
        /** Signed displacement of the slice from the antenna bounding-box centre, metres. */
        val sliceOffsetM: Double,
        val centerX: Double,
        val centerY: Double,
        val centerZ: Double,
        /** Complex H phasor components, row-major, A/m. Retained for phase animation. */
        val hxRe: DoubleArray,
        val hxIm: DoubleArray,
        val hyRe: DoubleArray,
        val hyIm: DoubleArray,
        val hzRe: DoubleArray,
        val hzIm: DoubleArray,
        /** Complex E phasor components, row-major, V/m. Retained for phase animation. */
        val exRe: DoubleArray,
        val exIm: DoubleArray,
        val eyRe: DoubleArray,
        val eyIm: DoubleArray,
        val ezRe: DoubleArray,
        val ezIm: DoubleArray,
        /** Row-major |H| in A/m. */
        val hAmpPerM: DoubleArray,
        /** Row-major |E| in V/m. */
        val eVoltPerM: DoubleArray,
        /** Row-major time-average real Poynting-vector magnitude, W/m². */
        val powerDensityWPerM2: DoubleArray,
        /** Row-major local |E|/|H| ratio, ohms. Diagnostic only in near field. */
        val localWaveImpedanceOhm: DoubleArray,
        val peakHAmpPerM: Double,
        val minHAmpPerM: Double,
        val peakEVoltPerM: Double,
        val minEVoltPerM: Double,
        val peakPowerDensityWPerM2: Double,
        val minPowerDensityWPerM2: Double,
        val peakBMicroTesla: Double,
        val peakHU: Double,
        val peakHV: Double,
        val peakEU: Double,
        val peakEV: Double,
        val peakSU: Double,
        val peakSV: Double,
        val antennaMaxDimensionM: Double,
        val reactiveNearFieldBoundaryM: Double,
        val fraunhoferBoundaryM: Double,
        val note: String
    ) {
        fun hDb(index: Int, floorDb: Double = -60.0): Double = dbRelative(hAmpPerM[index], peakHAmpPerM, floorDb)
        fun eDb(index: Int, floorDb: Double = -60.0): Double = dbRelative(eVoltPerM[index], peakEVoltPerM, floorDb)
        fun sDb(index: Int, floorDb: Double = -60.0): Double {
            val peak = peakPowerDensityWPerM2.coerceAtLeast(1e-30)
            val v = powerDensityWPerM2[index].coerceAtLeast(peak * 1e-12)
            return (10.0 / ln(10.0) * ln(v / peak)).coerceAtLeast(floorDb)
        }

        private fun dbRelative(value: Double, peakValue: Double, floorDb: Double): Double {
            val peak = peakValue.coerceAtLeast(1e-30)
            val v = value.coerceAtLeast(peak * 1e-12)
            return (20.0 / ln(10.0) * ln(v / peak)).coerceAtLeast(floorDb)
        }
    }

    fun calculate(
        model: MaaModel,
        segments: List<Nec2Core.NearFieldSegment>,
        plane: Plane,
        fixedOffsetM: Double = 0.0,
        halfSpanLambda: Double = 0.5,
        gridSize: Int = 51,
        currentSourceLabel: String = "external currents",
        onProgress: (Progress) -> Unit = {},
        isCancelled: () -> Boolean = { false }
    ): Grid {
        require(model.frequencyMHz > 0.0) { "Invalid frequency." }
        require(segments.isNotEmpty()) { "No complex segment currents available for Near Field." }

        val n = gridSize.coerceIn(21, 161).let { if (it % 2 == 0) it + 1 else it }
        val halfSpan = model.wavelengthM * halfSpanLambda.coerceAtLeast(0.1)
        // Use solved segment geometry rather than raw MAA wires. FULL may apply MMANA Add height
        // before OpenNEC solving, so these coordinates are the actual geometry used by the solver.
        val fieldSegs = segments
        val integrationSegs = buildIntegrationSegments(segments, model.wavelengthM)
        fun ex1(s: Nec2Core.NearFieldSegment) = s.x - 0.5 * s.lengthM * s.ux
        fun ex2(s: Nec2Core.NearFieldSegment) = s.x + 0.5 * s.lengthM * s.ux
        fun ey1(s: Nec2Core.NearFieldSegment) = s.y - 0.5 * s.lengthM * s.uy
        fun ey2(s: Nec2Core.NearFieldSegment) = s.y + 0.5 * s.lengthM * s.uy
        fun ez1(s: Nec2Core.NearFieldSegment) = s.z - 0.5 * s.lengthM * s.uz
        fun ez2(s: Nec2Core.NearFieldSegment) = s.z + 0.5 * s.lengthM * s.uz
        val minX = fieldSegs.minOfOrNull { minOf(ex1(it), ex2(it)) } ?: 0.0
        val maxX = fieldSegs.maxOfOrNull { maxOf(ex1(it), ex2(it)) } ?: 0.0
        val minY = fieldSegs.minOfOrNull { minOf(ey1(it), ey2(it)) } ?: 0.0
        val maxY = fieldSegs.maxOfOrNull { maxOf(ey1(it), ey2(it)) } ?: 0.0
        val minZ = fieldSegs.minOfOrNull { minOf(ez1(it), ez2(it)) } ?: 0.0
        val maxZ = fieldSegs.maxOfOrNull { maxOf(ez1(it), ez2(it)) } ?: 0.0
        val centerX = 0.5 * (minX + maxX)
        val centerY = 0.5 * (minY + maxY)
        val centerZ = 0.5 * (minZ + maxZ)

        val centralFixed = when (plane) {
            Plane.XY -> centerZ
            Plane.XZ -> centerY
            Plane.YZ -> centerX
        }
        // Moving the observation slice must not modify NEC geometry or currents.
        // Clamp only for numerical/UI sanity; the UI normally exposes ±1 λ.
        val offset = fixedOffsetM.coerceIn(-2.0 * model.wavelengthM, 2.0 * model.wavelengthM)
        val fixed = centralFixed + offset
        val hValues = DoubleArray(n * n)
        val eValues = DoubleArray(n * n)
        val sValues = DoubleArray(n * n)
        val zEhValues = DoubleArray(n * n)
        // Preserve the solved complex vector field so the UI can render Re{E·e^jφ} and
        // Re{H·e^jφ} at video rate without re-running the expensive Near Field kernel.
        val hxReValues = DoubleArray(n * n); val hxImValues = DoubleArray(n * n)
        val hyReValues = DoubleArray(n * n); val hyImValues = DoubleArray(n * n)
        val hzReValues = DoubleArray(n * n); val hzImValues = DoubleArray(n * n)
        val exReValues = DoubleArray(n * n); val exImValues = DoubleArray(n * n)
        val eyReValues = DoubleArray(n * n); val eyImValues = DoubleArray(n * n)
        val ezReValues = DoubleArray(n * n); val ezImValues = DoubleArray(n * n)
        val k = 2.0 * PI / model.wavelengthM
        val inv4pi = 1.0 / (4.0 * PI)
        val mu0 = 4.0e-7 * PI
        val eps0 = 8.8541878128e-12
        val eta0 = sqrt(mu0 / eps0)
        var peakH = 0.0
        var minHPositive = Double.POSITIVE_INFINITY
        var peakE = 0.0
        var minEPositive = Double.POSITIVE_INFINITY
        var peakS = 0.0
        var minSPositive = Double.POSITIVE_INFINITY
        var peakHU = 0.0
        var peakHV = 0.0
        var peakEU = 0.0
        var peakEV = 0.0
        var peakSU = 0.0
        var peakSV = 0.0

        for (row in 0 until n) {
            if (isCancelled()) throw Cancelled()
            val v = -halfSpan + 2.0 * halfSpan * row / (n - 1).toDouble()
            for (col in 0 until n) {
                val u = -halfSpan + 2.0 * halfSpan * col / (n - 1).toDouble()
                val px: Double
                val py: Double
                val pz: Double
                when (plane) {
                    Plane.XY -> { px = centerX + u; py = centerY - v; pz = fixed }
                    Plane.XZ -> { px = centerX + u; py = fixed; pz = centerZ - v }
                    Plane.YZ -> { px = fixed; py = centerY + u; pz = centerZ - v }
                }

                var hxRe = 0.0; var hxIm = 0.0
                var hyRe = 0.0; var hyIm = 0.0
                var hzRe = 0.0; var hzIm = 0.0
                var exRe = 0.0; var exIm = 0.0
                var eyRe = 0.0; var eyIm = 0.0
                var ezRe = 0.0; var ezIm = 0.0

                for (s in integrationSegs) {
                    val dx = px - s.x
                    val dy = py - s.y
                    val dz = pz - s.z
                    val r0 = sqrt(dx * dx + dy * dy + dz * dz)
                    // Do not let point-sampling hit the singular centre of a thin-wire pulse.
                    val r = max(r0, max(1.25 * s.radiusM, 0.12 * s.lengthM).coerceAtLeast(1e-7))
                    val rx = dx / r
                    val ry = dy / r
                    val rz = dz / r

                    // dl-vector cross rHat.
                    val cx = (s.uy * rz - s.uz * ry) * s.lengthM
                    val cy = (s.uz * rx - s.ux * rz) * s.lengthM
                    val cz = (s.ux * ry - s.uy * rx) * s.lengthM

                    // (1 + jkr) * exp(-jkr) / (4*pi*r^2)
                    val kr = k * r
                    val c = cos(kr)
                    val sn = sin(kr)
                    val kernelRe = (c + kr * sn) * inv4pi / (r * r)
                    val kernelIm = (kr * c - sn) * inv4pi / (r * r)

                    // I * H-kernel.
                    val aRe = s.currentReA * kernelRe - s.currentImA * kernelIm
                    val aIm = s.currentReA * kernelIm + s.currentImA * kernelRe
                    hxRe += aRe * cx; hxIm += aIm * cx
                    hyRe += aRe * cy; hyIm += aIm * cy
                    hzRe += aRe * cz; hzIm += aIm * cz

                    // Matching E-field of a Hertzian electric-current element.
                    // Vector form, exp(-jkr) convention:
                    // E = eta0*I*dl/(4*pi) * exp(-jkr) *
                    // [ 2*n*(u.n)*(1/r^2 - j/(k*r^3))
                    //   - (u - n*(u.n))*(j*k/r + 1/r^2 - j/(k*r^3)) ]
                    val udotn = s.ux * rx + s.uy * ry + s.uz * rz
                    val upx = s.ux - rx * udotn
                    val upy = s.uy - ry * udotn
                    val upz = s.uz - rz * udotn
                    val invR2 = 1.0 / (r * r)
                    val invKr3 = 1.0 / (k * r * r * r).coerceAtLeast(1e-30)

                    // Radial coefficient: 2*(1/r^2 - j/(k r^3)).
                    val rrRe = 2.0 * invR2
                    val rrIm = -2.0 * invKr3
                    // Transverse coefficient with the leading minus sign included.
                    val trRe = -invR2
                    val trIm = -(k / r - invKr3)

                    val bxRe = rx * udotn * rrRe + upx * trRe
                    val bxIm = rx * udotn * rrIm + upx * trIm
                    val byRe = ry * udotn * rrRe + upy * trRe
                    val byIm = ry * udotn * rrIm + upy * trIm
                    val bzRe = rz * udotn * rrRe + upz * trRe
                    val bzIm = rz * udotn * rrIm + upz * trIm

                    // Multiply vector coefficient by exp(-jkr).
                    fun phased(vRe: Double, vIm: Double): Pair<Double, Double> =
                        Pair(vRe * c + vIm * sn, vIm * c - vRe * sn)
                    val pex = phased(bxRe, bxIm)
                    val pey = phased(byRe, byIm)
                    val pez = phased(bzRe, bzIm)
                    val eScale = eta0 * s.lengthM * inv4pi

                    // I * phased coefficient.
                    fun addE(pr: Pair<Double, Double>): Pair<Double, Double> {
                        val vr = s.currentReA * pr.first - s.currentImA * pr.second
                        val vi = s.currentReA * pr.second + s.currentImA * pr.first
                        return Pair(vr * eScale, vi * eScale)
                    }
                    val ex = addE(pex); val ey = addE(pey); val ez = addE(pez)
                    exRe += ex.first; exIm += ex.second
                    eyRe += ey.first; eyIm += ey.second
                    ezRe += ez.first; ezIm += ez.second
                }

                val h = sqrt(hxRe * hxRe + hxIm * hxIm + hyRe * hyRe + hyIm * hyIm + hzRe * hzRe + hzIm * hzIm)
                val e = sqrt(exRe * exRe + exIm * exIm + eyRe * eyRe + eyIm * eyIm + ezRe * ezRe + ezIm * ezIm)

                // Time-average real Poynting vector: 0.5 * Re(E x H*).
                val sx = 0.5 * ((eyRe * hzRe + eyIm * hzIm) - (ezRe * hyRe + ezIm * hyIm))
                val sy = 0.5 * ((ezRe * hxRe + ezIm * hxIm) - (exRe * hzRe + exIm * hzIm))
                val sz = 0.5 * ((exRe * hyRe + exIm * hyIm) - (eyRe * hxRe + eyIm * hxIm))
                val poynting = sqrt(sx * sx + sy * sy + sz * sz)
                val zEh = if (h > 1e-18) (e / h).coerceIn(0.0, 1.0e9) else 1.0e9

                val idx = row * n + col
                hxReValues[idx] = hxRe; hxImValues[idx] = hxIm
                hyReValues[idx] = hyRe; hyImValues[idx] = hyIm
                hzReValues[idx] = hzRe; hzImValues[idx] = hzIm
                exReValues[idx] = exRe; exImValues[idx] = exIm
                eyReValues[idx] = eyRe; eyImValues[idx] = eyIm
                ezReValues[idx] = ezRe; ezImValues[idx] = ezIm
                hValues[idx] = h
                eValues[idx] = e
                sValues[idx] = poynting
                zEhValues[idx] = zEh
                if (h > peakH) { peakH = h; peakHU = u; peakHV = v }
                if (h > 0.0 && h < minHPositive) minHPositive = h
                if (e > peakE) { peakE = e; peakEU = u; peakEV = v }
                if (e > 0.0 && e < minEPositive) minEPositive = e
                if (poynting > peakS) { peakS = poynting; peakSU = u; peakSV = v }
                if (poynting > 0.0 && poynting < minSPositive) minSPositive = poynting
            }
            onProgress(Progress(((row + 1) * 100 / n).coerceIn(0, 100), row + 1, n))
        }

        val peakB = peakH * mu0 * 1e6
        val dxSpan = maxX - minX
        val dySpan = maxY - minY
        val dzSpan = maxZ - minZ
        val antennaD = max(dxSpan, max(dySpan, dzSpan)).coerceAtLeast(1e-9)
        // Standard engineering region estimates for an antenna with maximum dimension D.
        val reactiveBoundary = 0.62 * sqrt(antennaD * antennaD * antennaD / model.wavelengthM)
        val fraunhoferBoundary = 2.0 * antennaD * antennaD / model.wavelengthM
        return Grid(
            plane = plane,
            size = n,
            halfSpanM = halfSpan,
            fixedCoordinateM = fixed,
            sliceOffsetM = offset,
            centerX = centerX,
            centerY = centerY,
            centerZ = centerZ,
            hxRe = hxReValues,
            hxIm = hxImValues,
            hyRe = hyReValues,
            hyIm = hyImValues,
            hzRe = hzReValues,
            hzIm = hzImValues,
            exRe = exReValues,
            exIm = exImValues,
            eyRe = eyReValues,
            eyIm = eyImValues,
            ezRe = ezReValues,
            ezIm = ezImValues,
            hAmpPerM = hValues,
            eVoltPerM = eValues,
            powerDensityWPerM2 = sValues,
            localWaveImpedanceOhm = zEhValues,
            peakHAmpPerM = peakH,
            minHAmpPerM = if (minHPositive.isFinite()) minHPositive else 0.0,
            peakEVoltPerM = peakE,
            minEVoltPerM = if (minEPositive.isFinite()) minEPositive else 0.0,
            peakPowerDensityWPerM2 = peakS,
            minPowerDensityWPerM2 = if (minSPositive.isFinite()) minSPositive else 0.0,
            peakBMicroTesla = peakB,
            peakHU = peakHU,
            peakHV = peakHV,
            peakEU = peakEU,
            peakEV = peakEV,
            peakSU = peakSU,
            peakSV = peakSV,
            antennaMaxDimensionM = antennaD,
            reactiveNearFieldBoundaryM = reactiveBoundary,
            fraunhoferBoundaryM = fraunhoferBoundary,
            note = "Near E/H/S: complex Hertzian kernels + subsegment integration/interpolation; complex E/H phasors retained for time-phase animation; S=0.5·Re(E×H*); driven by $currentSourceLabel segment currents"
        )
    }

    /**
     * Convert NEC pulse-basis centre currents into a smoother field-integration mesh.
     * Boundary current is the complex average of neighbouring centre samples on the same GW/tag,
     * so both amplitude and phase remain continuous. Geometry/current solving itself is untouched.
     */
    private fun buildIntegrationSegments(
        segments: List<Nec2Core.NearFieldSegment>,
        wavelengthM: Double
    ): List<Nec2Core.NearFieldSegment> {
        if (segments.isEmpty()) return emptyList()
        val out = ArrayList<Nec2Core.NearFieldSegment>(segments.size * 3)
        val targetCell = (wavelengthM / 96.0).coerceAtLeast(1e-7)
        val groups = segments.groupBy { it.wireIndex }
        for ((_, groupRaw) in groups) {
            val group = groupRaw.sortedBy { it.alongWire }
            for (i in group.indices) {
                val s = group[i]
                val prev = group.getOrNull(i - 1)
                val next = group.getOrNull(i + 1)
                val leftRe = if (prev != null) 0.5 * (prev.currentReA + s.currentReA) else s.currentReA
                val leftIm = if (prev != null) 0.5 * (prev.currentImA + s.currentImA) else s.currentImA
                val rightRe = if (next != null) 0.5 * (s.currentReA + next.currentReA) else s.currentReA
                val rightIm = if (next != null) 0.5 * (s.currentImA + next.currentImA) else s.currentImA
                val parts = ceil(s.lengthM / targetCell).toInt().coerceIn(2, 4)
                val cellLength = s.lengthM / parts.toDouble()
                for (part in 0 until parts) {
                    val t = (part + 0.5) / parts.toDouble()
                    val offset = (t - 0.5) * s.lengthM
                    out += s.copy(
                        x = s.x + s.ux * offset,
                        y = s.y + s.uy * offset,
                        z = s.z + s.uz * offset,
                        lengthM = cellLength,
                        currentReA = leftRe + (rightRe - leftRe) * t,
                        currentImA = leftIm + (rightIm - leftIm) * t,
                        alongWire = s.alongWire + (t - 0.5) / group.size.coerceAtLeast(1).toDouble()
                    )
                }
            }
        }
        return out
    }
}
