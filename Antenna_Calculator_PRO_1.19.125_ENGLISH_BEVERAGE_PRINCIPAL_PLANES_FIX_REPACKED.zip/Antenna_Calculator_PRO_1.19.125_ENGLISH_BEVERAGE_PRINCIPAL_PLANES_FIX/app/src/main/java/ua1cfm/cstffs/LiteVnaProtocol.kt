package ua1cfm.cstffs

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToLong

/**
 * LiteVNA / SAA2 wire protocol helpers.
 *
 * The protocol is binary and little-endian. This file intentionally contains no Android USB
 * classes so the command encoder / FIFO decoder can be checked with plain kotlinc.
 */
object LiteVnaProtocol {
    const val OP_NOP = 0x00
    const val OP_INDICATE = 0x0d
    const val OP_READ = 0x10
    const val OP_READ2 = 0x11
    const val OP_READ4 = 0x12
    const val OP_READ_FIFO = 0x18
    const val OP_WRITE = 0x20
    const val OP_WRITE2 = 0x21
    const val OP_WRITE4 = 0x22
    const val OP_WRITE8 = 0x23

    const val REG_SWEEP_START_HZ = 0x00
    const val REG_SWEEP_STEP_HZ = 0x10
    const val REG_SWEEP_POINTS = 0x20
    const val REG_VALUES_PER_FREQUENCY = 0x22
    const val REG_RAW_SAMPLES_MODE = 0x26
    const val REG_VALUES_FIFO = 0x30
    const val REG_AVERAGE = 0x40
    const val REG_CHANNEL_SELECT = 0x44
    const val REG_DEVICE_VARIANT = 0xf0
    const val REG_PROTOCOL_VERSION = 0xf1
    const val REG_HARDWARE_REVISION = 0xf2
    const val REG_FIRMWARE_MAJOR = 0xf3
    const val REG_FIRMWARE_MINOR = 0xf4

    const val FIFO_RECORD_BYTES = 32

    data class SweepConfig(
        val startHz: Long,
        val stopHz: Long,
        val points: Int,
        val average: Int = 1
    ) {
        init {
            require(startHz >= 50_000L) { "START must be at least 50 kHz" }
            require(stopHz > startHz) { "STOP must be greater than START" }
            require(stopHz <= 6_300_000_000L) { "STOP must not exceed 6.3 GHz for LiteVNA64" }
            require(points in 2..65535) { "Point count must be 2…65535" }
            require(average in 1..80) { "Average must be 1…80" }
        }

        val stepHz: Long = ((stopHz - startHz).toDouble() / (points - 1).toDouble())
            .roundToLong()
            .coerceAtLeast(1L)

        fun frequencyHz(index: Int): Double = startHz.toDouble() + stepHz.toDouble() * index.toDouble()
        val actualStopHz: Long get() = startHz + stepHz * (points - 1L)
    }

    data class RawValue(
        val fwd0Re: Int,
        val fwd0Im: Int,
        val rev0Re: Int,
        val rev0Im: Int,
        val rev1Re: Int,
        val rev1Im: Int,
        val frequencyIndex: Int
    ) {
        fun s11(): Cpx = divide(Cpx(rev0Re.toDouble(), rev0Im.toDouble()), Cpx(fwd0Re.toDouble(), fwd0Im.toDouble()))
        fun s21(): Cpx = divide(Cpx(rev1Re.toDouble(), rev1Im.toDouble()), Cpx(fwd0Re.toDouble(), fwd0Im.toDouble()))
    }

    fun indicate(): ByteArray = byteArrayOf(OP_INDICATE.toByte())
    fun readByte(address: Int): ByteArray = byteArrayOf(OP_READ.toByte(), address.toByte())
    fun readFifo(count: Int): ByteArray {
        require(count in 1..255)
        return byteArrayOf(OP_READ_FIFO.toByte(), REG_VALUES_FIFO.toByte(), count.toByte())
    }

    fun writeByte(address: Int, value: Int): ByteArray = byteArrayOf(
        OP_WRITE.toByte(), address.toByte(), value.toByte()
    )

    fun write2(address: Int, value: Int): ByteArray {
        require(value in 0..0xffff)
        return byteArrayOf(
            OP_WRITE2.toByte(), address.toByte(),
            (value and 0xff).toByte(), ((value ushr 8) and 0xff).toByte()
        )
    }

    fun write8(address: Int, value: Long): ByteArray {
        require(value >= 0L)
        val out = ByteArray(10)
        out[0] = OP_WRITE8.toByte()
        out[1] = address.toByte()
        for (i in 0 until 8) out[2 + i] = ((value ushr (8 * i)) and 0xffL).toByte()
        return out
    }

    fun parseRawValue(bytes: ByteArray, offset: Int = 0): RawValue {
        require(offset >= 0 && offset + FIFO_RECORD_BYTES <= bytes.size)
        val b = ByteBuffer.wrap(bytes, offset, FIFO_RECORD_BYTES).order(ByteOrder.LITTLE_ENDIAN)
        val fwdRe = b.int
        val fwdIm = b.int
        val rev0Re = b.int
        val rev0Im = b.int
        val rev1Re = b.int
        val rev1Im = b.int
        val index = b.short.toInt() and 0xffff
        return RawValue(fwdRe, fwdIm, rev0Re, rev0Im, rev1Re, rev1Im, index)
    }

    fun buildTouchstone(config: SweepConfig, values: List<RawValue>): TouchstoneData {
        val byIndex = values.associateBy { it.frequencyIndex }
        require((0 until config.points).all { byIndex.containsKey(it) }) { "Not all sweep points were received" }
        val points = (0 until config.points).map { index ->
            val raw = byIndex.getValue(index)
            val s11 = raw.s11()
            val s21 = raw.s21()
            require(s11.re.isFinite() && s11.im.isFinite()) { "Invalid reference channel at point $index" }
            require(s21.re.isFinite() && s21.im.isFinite()) { "Invalid S21 at point $index" }
            TouchstonePoint(
                frequencyHz = config.frequencyHz(index),
                s11 = s11,
                s21 = s21
            )
        }
        return TouchstoneData(
            ports = 2,
            referenceOhm = 50.0,
            format = "RI",
            frequencyUnit = "HZ",
            points = points,
            comments = listOf(
                "LiteVNA USB/SAA2 direct sweep",
                "RAW wave-ratio data: on-device user calibration is not applied over this FIFO protocol"
            )
        )
    }

    private fun divide(a: Cpx, b: Cpx): Cpx {
        val d = b.re * b.re + b.im * b.im
        if (d <= 1e-30 || !d.isFinite()) return Cpx(Double.NaN, Double.NaN)
        return Cpx(
            (a.re * b.re + a.im * b.im) / d,
            (a.im * b.re - a.re * b.im) / d
        )
    }
}
