package ua1cfm.cstffs

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * JNI facade for the embedded OpenNEC 2.2.0 NEC-2 solver.
 *
 * OpenNEC is the primary input-impedance AND segment-current solver.
 * Since 1.19.6 the returned complex currents also drive the primary far-field pattern,
 * the primary far-field pattern and the NearFieldEngine E/H/B/S visualizer.
 */
object OpenNecFull {
    data class InputImpedance(
        val tag: Int,
        val segment: Int,
        val rOhm: Double,
        val xOhm: Double
    ) {
        fun swr(z0Ohm: Double): Double {
            val z0 = z0Ohm.coerceAtLeast(1e-9)
            val den = (rOhm + z0) * (rOhm + z0) + xOhm * xOhm
            if (den <= 1e-30) return Double.POSITIVE_INFINITY
            val gamma2 = (((rOhm - z0) * (rOhm - z0) + xOhm * xOhm) / den).coerceAtLeast(0.0)
            val gamma = sqrt(gamma2)
            if (!gamma.isFinite() || gamma >= 1.0) return Double.POSITIVE_INFINITY
            return (1.0 + gamma) / (1.0 - gamma)
        }

        fun formattedZ(): String = "%.2f %s j%.2f Ω".format(rOhm, if (xOhm >= 0.0) "+" else "−", abs(xOhm))
    }

    data class SegmentCurrent(
        val globalIndex: Int,
        val tag: Int,
        val segment: Int,
        val xM: Double,
        val yM: Double,
        val zM: Double,
        val lengthM: Double,
        val radiusM: Double,
        val ux: Double,
        val uy: Double,
        val uz: Double,
        val currentReA: Double,
        val currentImA: Double,
        /** NEC thin-wire current expansion coefficients Ai/lambda, Bi/lambda, Ci/lambda. */
        val basisARe: Double = Double.NaN,
        val basisAIm: Double = Double.NaN,
        val basisBRe: Double = Double.NaN,
        val basisBIm: Double = Double.NaN,
        val basisCRe: Double = Double.NaN,
        val basisCIm: Double = Double.NaN
    ) {
        val hasNecCurrentBasis: Boolean get() =
            basisARe.isFinite() && basisAIm.isFinite() &&
                basisBRe.isFinite() && basisBIm.isFinite() &&
                basisCRe.isFinite() && basisCIm.isFinite()
        val amplitudeA: Double get() = sqrt(currentReA * currentReA + currentImA * currentImA)
    }

    data class NativePatternPoint(
        val thetaDeg: Double,
        val phiDeg: Double,
        val gainDb: Double
    )

    data class Result(
        val engineVersion: String,
        val frequencyMHz: Double,
        val inputs: List<InputImpedance>,
        val segments: List<SegmentCurrent>,
        val warning: String?,
        /** Native OpenNEC RP total-gain grid. Empty only for sweep/impedance-only solves. */
        val nativePattern: List<NativePatternPoint> = emptyList()
    ) {
        val primary: InputImpedance get() = inputs.first()
        val currentPeakA: Double get() = segments.maxOfOrNull { it.amplitudeA } ?: 0.0
        val primarySegmentIndex: Int
            get() = segments.indexOfFirst { it.tag == primary.tag && it.segment == primary.segment }

        /** Adapter used by the existing current/near-field visualizers. */
        val nearFieldSegments: List<Nec2Core.NearFieldSegment>
            get() {
                if (segments.isEmpty()) return emptyList()
                val countByTag = segments.groupingBy { it.tag }.eachCount()
                return segments.map { s ->
                    val count = countByTag[s.tag]?.coerceAtLeast(1) ?: 1
                    Nec2Core.NearFieldSegment(
                        x = s.xM,
                        y = s.yM,
                        z = s.zM,
                        ux = s.ux,
                        uy = s.uy,
                        uz = s.uz,
                        lengthM = s.lengthM,
                        radiusM = s.radiusM,
                        currentReA = s.currentReA,
                        currentImA = s.currentImA,
                        wireIndex = s.tag - 1,
                        alongWire = ((s.segment - 0.5) / count.toDouble()).coerceIn(0.0, 1.0)
                    )
                }
            }
    }

    /**
     * Prepared small-frequency sweep. The base NEC deck is built once at the centre frequency,
     * then only FR and frequency-dependent LD cards are refreshed for each sample. This keeps
     * geometry, topology and segment numbering frozen across the Smith trace.
     */
    data class SweepPlan internal constructor(
        val centreFrequencyMHz: Double,
        internal val model: MaaModel,
        internal val config: Nec2Core.SegmentationConfig,
        internal val baseDeck: Nec2FullDeck.BuildResult
    )

    data class SweepPoint(
        val frequencyMHz: Double,
        val inputs: List<InputImpedance>
    ) {
        val primary: InputImpedance get() = inputs.first()
    }

    private val loadFailure: Throwable? = runCatching {
        System.loadLibrary("cstffs_nec2")
    }.exceptionOrNull()

    val isAvailable: Boolean get() = loadFailure == null
    val availabilityMessage: String?
        get() = loadFailure?.let { "NEC-2 FULL native library: ${it.message ?: it::class.java.simpleName}" }

    @JvmStatic
    private external fun nativeSolveNec(necDeck: String, includePattern: Boolean): String

    /**
     * OpenNEC 2.2 may expose only one inp_z row for a coherently driven multi-EX deck.
     * The solved current vector still contains the current on every excited segment.
     * For missing rows, recover the real NEC active-port impedance directly as Vsrc / Isrc.
     * No R0 substitution and no synthetic reactance are used.
     */
    private fun completeSourceInputs(
        built: Nec2FullDeck.BuildResult,
        native: Result
    ): List<InputImpedance> {
        if (built.sourcePorts.isEmpty() || native.inputs.size >= built.sourcePorts.size) return native.inputs

        val nativeByPort = native.inputs.associateBy { it.tag to it.segment }
        val segmentByPort = native.segments.associateBy { it.tag to it.segment }

        // NEC current orientation can be opposite to the voltage-source sign convention.
        // Calibrate that single global orientation from a native inp_z row when available.
        var currentSign = 1.0
        built.sourcePorts.firstNotNullOfOrNull { port ->
            val nz = nativeByPort[port.tag to port.segment] ?: return@firstNotNullOfOrNull null
            val cur = segmentByPort[port.tag to port.segment] ?: return@firstNotNullOfOrNull null
            val den = cur.currentReA * cur.currentReA + cur.currentImA * cur.currentImA
            if (den <= 1e-30) return@firstNotNullOfOrNull null
            val zr = (port.voltageRe * cur.currentReA + port.voltageIm * cur.currentImA) / den
            val zx = (port.voltageIm * cur.currentReA - port.voltageRe * cur.currentImA) / den
            val dPlus = (zr - nz.rOhm) * (zr - nz.rOhm) + (zx - nz.xOhm) * (zx - nz.xOhm)
            val dMinus = (-zr - nz.rOhm) * (-zr - nz.rOhm) + (-zx - nz.xOhm) * (-zx - nz.xOhm)
            if (dMinus < dPlus) -1.0 else 1.0
        }?.let { currentSign = it }

        return built.sourcePorts.mapNotNull { port ->
            nativeByPort[port.tag to port.segment] ?: run {
                val cur = segmentByPort[port.tag to port.segment] ?: return@run null
                val ir = currentSign * cur.currentReA
                val ii = currentSign * cur.currentImA
                val den = ir * ir + ii * ii
                if (den <= 1e-30) return@run null
                InputImpedance(
                    tag = port.tag,
                    segment = port.segment,
                    rOhm = (port.voltageRe * ir + port.voltageIm * ii) / den,
                    xOhm = (port.voltageIm * ir - port.voltageRe * ii) / den
                )
            }
        }.ifEmpty { native.inputs }
    }


    /**
     * OpenNEC 2.2 does not reliably keep several EX cards active at the same time in the
     * embedded execution path used by the Android build. Legacy MMANA stacks therefore need
     * coherent superposition: solve the SAME full geometry once per source, then sum the
     * complex current vectors. This is exact for linear NEC-2 and preserves mutual coupling,
     * because every single-source solve includes all passive copies of the other Yagis.
     */
    private fun solveCoherentStack(
        built: Nec2FullDeck.BuildResult
    ): Result {
        require(built.sourcePorts.size >= 2) { "Coherent stack needs at least two source ports." }

        val exLines = built.deck.lineSequence().filter { it.startsWith("EX ") }.toList()
        require(exLines.size == built.sourcePorts.size) {
            "NEC-2 stack: EX/source mismatch ${exLines.size}/${built.sourcePorts.size}."
        }

        fun deckForSource(sourceIndex: Int): String {
            val keep = exLines[sourceIndex]
            val out = StringBuilder(built.deck.length + 32)
            var inserted = false
            built.deck.lineSequence().forEach { line ->
                if (line.startsWith("EX ")) {
                    if (!inserted) {
                        out.appendLine(keep)
                        inserted = true
                    }
                } else {
                    out.appendLine(line)
                }
            }
            return out.toString()
        }

        val partials = built.sourcePorts.indices.map { idx ->
            parse(nativeSolveNec(deckForSource(idx), false))
        }
        require(partials.all { it.segments.size == built.segmentCount }) {
            "NEC-2 stack: inconsistent segment count during coherent source superposition."
        }

        val ref = partials.first()
        val summedSegments = ref.segments.indices.map { si ->
            val r = ref.segments[si]
            fun sum(f: (SegmentCurrent) -> Double): Double = partials.sumOf { f(it.segments[si]) }
            r.copy(
                currentReA = sum { it.currentReA },
                currentImA = sum { it.currentImA },
                basisARe = sum { it.basisARe },
                basisAIm = sum { it.basisAIm },
                basisBRe = sum { it.basisBRe },
                basisBIm = sum { it.basisBIm },
                basisCRe = sum { it.basisCRe },
                basisCIm = sum { it.basisCIm }
            )
        }

        val byPort = summedSegments.associateBy { it.tag to it.segment }
        val inputs = built.sourcePorts.mapNotNull { port ->
            val cur = byPort[port.tag to port.segment] ?: return@mapNotNull null
            val den = cur.currentReA * cur.currentReA + cur.currentImA * cur.currentImA
            if (den <= 1e-30) return@mapNotNull null
            InputImpedance(
                tag = port.tag,
                segment = port.segment,
                rOhm = (port.voltageRe * cur.currentReA + port.voltageIm * cur.currentImA) / den,
                xOhm = (port.voltageIm * cur.currentReA - port.voltageRe * cur.currentImA) / den
            )
        }
        require(inputs.size == built.sourcePorts.size) {
            "NEC-2 stack: failed to recover all active source impedances (${inputs.size}/${built.sourcePorts.size})."
        }

        val warnings = partials.mapNotNull { it.warning }.distinct().joinToString("; ")
        return Result(
            engineVersion = ref.engineVersion,
            frequencyMHz = ref.frequencyMHz,
            inputs = inputs,
            segments = summedSegments,
            warning = listOfNotNull(
                built.warning,
                warnings.takeIf { it.isNotBlank() },
                "MMANA stack solved by coherent ${built.sourcePorts.size}-source superposition"
            ).joinToString("; ").takeIf { it.isNotBlank() },
            nativePattern = emptyList()
        )
    }

    fun solveModel(model: MaaModel, config: Nec2Core.SegmentationConfig): Result {
        loadFailure?.let { throw IllegalStateException("NEC-2 FULL native library was not loaded: ${it.message}", it) }
        val built = Nec2FullDeck.fromMaa(model, config)
        // 1.19.104: one and the same physical NEC-2 FULL model must produce Zin,
        // complex segment currents and the radiation pattern.  In particular MMANA G=2
        // is no longer solved as PEC for Zin and then re-solved with real ground for RP.
        // That split could shift a tuned Gamma/Omega/T-match away from its real resonance.
        val isExpandedMmanaStack = model.sources.size > 1 && model.sources.all { it.raw.contains("[stack ") }
        if (isExpandedMmanaStack) {
            return solveCoherentStack(built)
        }

        val native = parse(nativeSolveNec(built.deck, true))
        require(native.inputs.isNotEmpty()) {
            "NEC-2 FULL returned no input impedance."
        }
        require(native.segments.size == built.segmentCount) {
            "NEC-2 FULL: expected ${built.segmentCount} current segments, received ${native.segments.size}."
        }
        val completedInputs = completeSourceInputs(built, native)
        val inputCountWarning = if (native.inputs.size != built.sourceCount) {
            "NEC-2 FULL multi-source array: ${built.sourceCount} coherent EX sources; native inp_z=${native.inputs.size}, active Z recovered for ${completedInputs.size} source ports from solved V/I"
        } else null
        val combinedWarning = listOfNotNull(
            built.warning,
            native.warning,
            inputCountWarning
        ).joinToString("; ").takeIf { it.isNotBlank() }
        return native.copy(inputs = completedInputs, warning = combinedWarning)
    }

    fun prepareSweep(model: MaaModel, config: Nec2Core.SegmentationConfig): SweepPlan {
        loadFailure?.let { throw IllegalStateException("NEC-2 FULL native library was not loaded: ${it.message}", it) }
        val base = Nec2FullDeck.fromMaa(model, config)
        return SweepPlan(model.frequencyMHz, model, config, base)
    }

    /**
     * Solve one sweep frequency while keeping the centre-frequency NEC mesh frozen.
     * The only cards patched into the centre deck are FR and LD. LD must be refreshed because
     * MMANA R/L/C loads are converted to explicit impedance at the active frequency.
     */
    fun solveSweepPoint(plan: SweepPlan, frequencyMHz: Double): SweepPoint {
        require(frequencyMHz.isFinite() && frequencyMHz > 0.0) { "Invalid sweep frequency." }
        val variedModel = plan.model.copy(frequencyMHz = frequencyMHz)
        val varied = Nec2FullDeck.fromMaa(variedModel, plan.config)
        require(varied.sourceCount == plan.baseDeck.sourceCount) {
            "NEC-2 sweep: source count changed ${plan.baseDeck.sourceCount}→${varied.sourceCount}."
        }
        val deck = patchSweepDeck(plan.baseDeck.deck, varied.deck)

        // 1.19.111: expanded legacy MMANA stacks must use the SAME coherent
        // one-source-at-a-time superposition at every Smith/sweep frequency as
        // the centre-frequency solveModel() path.  Using one native multi-EX
        // solve here caused only one Yagi to be driven reliably and produced a
        // false off-frequency impedance trace.
        val isExpandedMmanaStack = plan.model.sources.size > 1 &&
            plan.model.sources.all { it.raw.contains("[stack ") }
        if (isExpandedMmanaStack) {
            val frozenStackDeck = varied.copy(
                deck = deck,
                segmentCount = plan.baseDeck.segmentCount
            )
            val coherent = solveCoherentStack(frozenStackDeck)
            return SweepPoint(coherent.frequencyMHz, coherent.inputs)
        }

        val native = parse(nativeSolveNec(deck, false))
        require(native.inputs.isNotEmpty()) {
            "NEC-2 sweep returned no input impedance."
        }
        require(native.segments.size == plan.baseDeck.segmentCount) {
            "NEC-2 sweep: frozen mesh expected ${plan.baseDeck.segmentCount} segments, received ${native.segments.size}."
        }
        val completedInputs = completeSourceInputs(varied, native)
        return SweepPoint(native.frequencyMHz, completedInputs)
    }


    internal fun realGroundPatternDeck(deck: String): String {
        val out = StringBuilder(deck.length + 64)
        var replaced = false
        deck.lineSequence().forEach { line ->
            if (!replaced && line.trim().matches(Regex("GN\\s+1(?:\\s.*)?"))) {
                out.appendLine("GN 3 0 0 0 13.0 0.005")
                replaced = true
            } else {
                out.appendLine(line)
            }
        }
        require(replaced) { "Real Ground pattern: PEC card GN 1 was not found in the FULL deck." }
        return out.toString()
    }

    internal fun patchSweepDeck(baseDeck: String, variedDeck: String): String {
        val variedLines = variedDeck.lineSequence().toList()
        val newFr = variedLines.firstOrNull { it.startsWith("FR ") }
            ?: error("NEC-2 sweep: FR is missing from the deck.")
        val newLoads = variedLines.filter { it.startsWith("LD ") }
        val out = StringBuilder(baseDeck.length + 128)
        var loadsInserted = false
        baseDeck.lineSequence().forEach { line ->
            when {
                line.startsWith("FR ") -> out.appendLine(newFr)
                line.startsWith("LD ") -> Unit
                !loadsInserted && (line.startsWith("EX ") || line.startsWith("XQ ")) -> {
                    newLoads.forEach(out::appendLine)
                    loadsInserted = true
                    out.appendLine(line)
                }
                else -> out.appendLine(line)
            }
        }
        if (!loadsInserted && newLoads.isNotEmpty()) {
            // Defensive fallback; normal generated decks always have EX/XQ.
            newLoads.forEach(out::appendLine)
        }
        return out.toString()
    }

    internal fun parse(payload: String): Result {
        if (payload.startsWith("ERR|")) {
            error(payload.substringAfter("ERR|").ifBlank { "NEC-2 FULL error" })
        }

        // 1.19.35 native payload:
        // OK|version|freq|ninp|inputRows|nseg|currentRows|warning|npat|theta,phi,gtot;...
        val parts = payload.split('|', limit = 10)
        require(parts.size >= 7 && parts[0] == "OK") { "Invalid NEC-2 FULL response: $payload" }
        val version = parts[1]
        val frequency = parts[2].toDoubleOrNull() ?: Double.NaN
        val expectedInputs = parts[3].toIntOrNull() ?: 0
        val inputs = parts[4].split(';').filter { it.isNotBlank() }.map { row ->
            val p = row.split(',')
            require(p.size == 4) { "Invalid FULL Z row: $row" }
            InputImpedance(
                tag = p[0].toInt(),
                segment = p[1].toInt(),
                rOhm = p[2].toDouble(),
                xOhm = p[3].toDouble()
            )
        }
        require(inputs.isNotEmpty()) { "NEC-2 FULL returned no inputs." }
        require(expectedInputs <= 0 || inputs.size == expectedInputs) {
            "NEC-2 FULL: expected $expectedInputs inputs, received ${inputs.size}."
        }

        val expectedSegments = parts[5].toIntOrNull() ?: 0
        val segments = parts[6].split(';').filter { it.isNotBlank() }.map { row ->
            val p = row.split(',')
            require(p.size == 13 || p.size == 19) { "Invalid FULL current row: $row" }
            SegmentCurrent(
                globalIndex = p[0].toInt(),
                tag = p[1].toInt(),
                segment = p[2].toInt(),
                xM = p[3].toDouble(),
                yM = p[4].toDouble(),
                zM = p[5].toDouble(),
                lengthM = p[6].toDouble(),
                radiusM = p[7].toDouble(),
                ux = p[8].toDouble(),
                uy = p[9].toDouble(),
                uz = p[10].toDouble(),
                currentReA = p[11].toDouble(),
                currentImA = p[12].toDouble(),
                basisARe = p.getOrNull(13)?.toDoubleOrNull() ?: Double.NaN,
                basisAIm = p.getOrNull(14)?.toDoubleOrNull() ?: Double.NaN,
                basisBRe = p.getOrNull(15)?.toDoubleOrNull() ?: Double.NaN,
                basisBIm = p.getOrNull(16)?.toDoubleOrNull() ?: Double.NaN,
                basisCRe = p.getOrNull(17)?.toDoubleOrNull() ?: Double.NaN,
                basisCIm = p.getOrNull(18)?.toDoubleOrNull() ?: Double.NaN
            )
        }
        require(segments.isNotEmpty()) { "NEC-2 FULL returned no segment currents." }
        require(expectedSegments <= 0 || segments.size == expectedSegments) {
            "NEC-2 FULL: expected $expectedSegments current segments, received ${segments.size}."
        }
        require(segments.indices.all { segments[it].globalIndex == it }) {
            "NEC-2 FULL returned an invalid segment order."
        }

        val warning = parts.getOrNull(7)?.trim()?.takeIf { it.isNotEmpty() }
        val expectedPattern = parts.getOrNull(8)?.toIntOrNull() ?: 0
        val nativePattern = parts.getOrNull(9).orEmpty().split(';').filter { it.isNotBlank() }.map { row ->
            val p = row.split(',')
            require(p.size == 3) { "Invalid native RP row: $row" }
            NativePatternPoint(p[0].toDouble(), p[1].toDouble(), p[2].toDouble())
        }
        require(expectedPattern <= 0 || nativePattern.size == expectedPattern) {
            "NEC-2 FULL: expected $expectedPattern native RP points, received ${nativePattern.size}."
        }
        return Result(version, frequency, inputs, segments, warning, nativePattern)
    }
}
