package ua1cfm.cstffs

import java.io.BufferedReader
import java.io.StringReader
import kotlin.math.abs

object HfssFfdParser {
    private data class Grid(val start: Double, val stop: Double, val count: Int) {
        fun value(i: Int): Double = if (count <= 1) start else start + (stop - start) * i / (count - 1).toDouble()
    }
    private data class Block(val frequencyHz: Double?, val rows: List<DoubleArray>)

    fun parse(reader: BufferedReader, targetGHz: Double, edgeAngleDeg: Double,
              onCalculationProgress: (Int) -> Unit = {}): FfsResult {
        val lines = reader.readLines()
        require(lines.isNotEmpty()) { "Empty HFSS FFD file." }
        val significant = lines.map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") && !it.startsWith("//") }
        val coordinateTag = significant.firstOrNull {
            it.equals("Theta-Phi", true) || it.startsWith("ElOverAz", true) ||
            it.startsWith("AzOverEl", true) || it.contains("Theta-Phi", true)
        }
        if (coordinateTag != null && !coordinateTag.contains("Theta-Phi", true))
            error("HFSS FFD uses '$coordinateTag'. The Theta-Phi coordinate system is currently supported.")

        val grids = mutableListOf<Grid>(); var gridEndIndex = -1
        for ((idx, line) in significant.withIndex()) {
            if (line.startsWith("Frequencies", true) || line.startsWith("Frequency", true)) break
            val n = numbers(line)
            if (n.size >= 3) {
                val count = n[2].toInt()
                if (count > 0 && abs(n[2] - count.toDouble()) < 1e-6) {
                    grids += Grid(n[0], n[1], count); gridEndIndex = idx
                    if (grids.size == 2) break
                }
            }
        }
        require(grids.size == 2) { "Theta and Phi grid lines were not found in the HFSS FFD." }
        val thetaGrid = grids[0]; val phiGrid = grids[1]
        val expected = thetaGrid.count * phiGrid.count
        require(expected > 0) { "Invalid HFSS FFD angular grid." }

        val blocks = mutableListOf<Block>(); var currentFreq: Double? = null
        var currentRows = mutableListOf<DoubleArray>(); var sawFrequency = false
        fun flush() {
            if (currentRows.isNotEmpty()) {
                require(currentRows.size >= expected) { "Incomplete HFSS FFD block: ${currentRows.size} points instead of $expected." }
                blocks += Block(currentFreq, currentRows.take(expected)); currentRows = mutableListOf()
            }
        }
        for (i in (gridEndIndex + 1) until significant.size) {
            val line = significant[i]
            if (line.startsWith("Frequencies", true)) continue
            if (line.startsWith("Frequency", true)) {
                flush(); val n = numbers(line)
                require(n.isNotEmpty()) { "No frequency value found after Frequency." }
                currentFreq = n[0]; sawFrequency = true; continue
            }
            val n = numbers(line)
            if (n.size >= 4) {
                currentRows += doubleArrayOf(n[0], n[1], n[2], n[3])
                if (!sawFrequency && currentRows.size == expected) { flush(); break }
                if (sawFrequency && currentRows.size == expected) { flush(); currentFreq = null }
            }
        }
        flush(); require(blocks.isNotEmpty()) { "No complex-field rows found in the HFSS FFD." }

        val targetHz = targetGHz * 1e9
        val selected = blocks.minByOrNull { it.frequencyHz?.let { f -> abs(f - targetHz) } ?: 0.0 } ?: blocks.first()
        val selectedGHz = selected.frequencyHz?.div(1e9) ?: targetGHz

        // HFSS Theta-Phi: second angle (Phi) is the outer loop; Theta is inner.
        val sb = StringBuilder(selected.rows.size * 90)
        sb.appendLine("// CST Farfield Source File").appendLine("// Version:").appendLine("3.0")
        sb.appendLine("// Radiated/Accepted/Stimulated Power , Frequency")
        sb.appendLine("1.0").appendLine("1.0").appendLine("1.0").appendLine(selectedGHz * 1e9)
        sb.appendLine("// >> Total #phi samples, total #theta samples")
        sb.appendLine("${phiGrid.count} ${thetaGrid.count}")
        sb.appendLine("// >> Phi, Theta, Re(E_Theta), Im(E_Theta), Re(E_Phi), Im(E_Phi):")
        for (idx in 0 until expected) {
            val phiIndex = idx / thetaGrid.count; val thetaIndex = idx % thetaGrid.count
            val e = selected.rows[idx]
            sb.append(phiGrid.value(phiIndex)).append(' ').append(thetaGrid.value(thetaIndex)).append(' ')
                .append(e[0]).append(' ').append(e[1]).append(' ').append(e[2]).append(' ').append(e[3]).append('\n')
        }
        val base = FfsParser.parse(BufferedReader(StringReader(sb.toString())), selectedGHz, edgeAngleDeg, onCalculationProgress)
        return base.copy(
            availableFrequenciesGHz = blocks.mapNotNull { it.frequencyHz?.div(1e9) }.distinct().sorted(),
            radiatedPowerW = null, acceptedPowerW = null, radiationEfficiency = null, gainDbi = base.directivityDbi,
            note = buildString {
                append("HFSS FFD (Theta-Phi), ${thetaGrid.count} Theta × ${phiGrid.count} Phi. ")
                append("Space, comma, and semicolon separators are supported. ")
                if (selected.frequencyHz != null) append("Selected %.6f GHz block, closest to %.6f GHz. ".format(selectedGHz, targetGHz))
                else append("Frequency is not specified in the FFD; %.6f GHz from the UI was used. ".format(targetGHz))
                append("Accepted/Radiated Power are not provided by the FFD, so ηrad is not calculated.")
            }
        )
    }

    private fun numbers(line: String): DoubleArray {
        val tokens = line.trim().split(Regex("[,;\\s]+")); val out = DoubleArray(tokens.size); var count = 0
        for (token in tokens) token.toDoubleOrNull()?.let { out[count++] = it }
        return out.copyOf(count)
    }
}
