package ua1cfm.cstffs

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Non-invasive diagnostics for the primary NEC-2 FULL path.
 *
 * This class never calibrates or modifies impedance/current/pattern results.  It only checks the
 * already parsed MAA geometry and repeats OpenNEC with denser segmentation when the user explicitly
 * requests a convergence test.
 */
object Nec2Diagnostics {
    enum class Level { OK, WARNING, ERROR }

    data class Check(
        val title: String,
        val level: Level,
        val detail: String
    )

    data class Report(val checks: List<Check>) {
        val errors: Int get() = checks.count { it.level == Level.ERROR }
        val warnings: Int get() = checks.count { it.level == Level.WARNING }
        val overall: Level get() = when {
            errors > 0 -> Level.ERROR
            warnings > 0 -> Level.WARNING
            else -> Level.OK
        }
    }

    data class ConvergenceSample(
        val densityPerLambda: Int,
        val segmentCount: Int,
        val capped: Boolean,
        val rOhm: Double,
        val xOhm: Double,
        val swr: Double,
        val p1PeakDeg: Double,
        val p2PeakDeg: Double,
        val p1HpbwDeg: Double?,
        val p2HpbwDeg: Double?,
        val p1FbDb: Double?,
        val p2FbDb: Double?,
        val p1: MaaPatternPreview,
        val p2: MaaPatternPreview,
        val solverWarning: String?
    )

    data class ConvergenceReport(
        val samples: List<ConvergenceSample>,
        val level: Level,
        val deltaRPercent: Double,
        val deltaXOhm: Double,
        val deltaZPercent: Double,
        val maxPeakShiftDeg: Double,
        val maxPatternRmsDb: Double,
        val note: String
    )

    fun analyze(
        model: MaaModel,
        config: Nec2Core.SegmentationConfig,
        solved: OpenNecFull.Result?
    ): Report {
        val checks = mutableListOf<Check>()
        val lambda = model.wavelengthM
        val plan = runCatching { Nec2Core.planSegmentation(model, config) }.getOrNull()

        val badGeometry = model.wires.count { w ->
            !w.lengthM.isFinite() || w.lengthM <= 1e-9 || !w.radiusM.isFinite() || w.radiusM <= 0.0 ||
                listOf(w.x1,w.y1,w.z1,w.x2,w.y2,w.z2).any { !it.isFinite() }
        }
        checks += if (badGeometry == 0) {
            Check("Wire geometry", Level.OK, "${model.wires.size} wires; no zero-length/invalid GW elements found.")
        } else {
            Check("Wire geometry", Level.ERROR, "Invalid wires found: $badGeometry.")
        }

        if (plan != null) {
            val maxElectrical = plan.longestSegmentM / lambda
            checks += when {
                maxElectrical <= 0.05 -> Check("Electrical segment length", Level.OK, "max Δ = %.4f λ (%.4f m).".format(maxElectrical, plan.longestSegmentM))
                maxElectrical <= 0.10 -> Check("Electrical segment length", Level.WARNING, "max Δ = %.4f λ. For a reference calculation, ≤0.05 λ is recommended.".format(maxElectrical))
                else -> Check("Electrical segment length", Level.ERROR, "max Δ = %.4f λ — mesh is too coarse for reliable NEC-2 results.".format(maxElectrical))
            }

            var minLenRadius = Double.POSITIVE_INFINITY
            model.wires.forEachIndexed { i, w ->
                val n = plan.countsPerWire.getOrNull(i)?.coerceAtLeast(1) ?: 1
                if (w.radiusM > 0.0) minLenRadius = min(minLenRadius, (w.lengthM / n) / w.radiusM)
            }
            checks += when {
                !minLenRadius.isFinite() -> Check("Thin-wire condition", Level.ERROR, "Could not estimate segment-length-to-radius ratio.")
                minLenRadius >= 8.0 -> Check("Thin-wire condition", Level.OK, "Minimum Δ/r = %.1f.".format(minLenRadius))
                minLenRadius >= 2.0 -> Check("Thin-wire condition", Level.WARNING, "Minimum Δ/r = %.1f. The wire is relatively thick for the selected mesh; check convergence.".format(minLenRadius))
                else -> Check("Thin-wire condition", Level.ERROR, "Minimum Δ/r = %.1f — segment length is comparable to wire diameter/radius; thin-wire results are unreliable.".format(minLenRadius))
            }

            checks += if (!plan.capApplied) {
                Check("Segmentation limit", Level.OK, "Requested and applied ${plan.appliedSegments} segments; MAX N was not reached.")
            } else {
                Check("Segmentation limit", Level.WARNING, "Requested ${plan.requestedSegments}, applied ${plan.appliedSegments}: MAX N=${plan.maxSegments} reached.")
            }
        }

        val sources = if (model.sources.isNotEmpty()) model.sources else model.sourceWireIndex?.let { idx ->
            listOf(MaaSource(idx, sourcePosition(model.sourceDescription), raw = model.sourceDescription.orEmpty()))
        }.orEmpty()
        val badSources = sources.count { it.wireIndex !in model.wires.indices || it.amplitude < 0.0 || !it.amplitude.isFinite() || !it.phaseDeg.isFinite() }
        checks += when {
            sources.isEmpty() -> Check("Source", Level.WARNING, "No explicit Source found in MAA. The current FULL bridge uses fallback excitation of the first wire; verify the model feed point.")
            badSources > 0 -> Check("Source", Level.ERROR, "Invalid Sources: $badSources of ${sources.size}.")
            else -> Check("Source", Level.OK, "Sources: ${sources.size}; wires and excitation parameters recognized.")
        }

        val badLoads = model.loads.count { it.wireIndex !in model.wires.indices }
        val unsupportedLoads = model.loads.count { it.kind !in 0..1 }
        checks += when {
            badLoads > 0 -> Check("Loads", Level.ERROR, "${badLoads} loads reference a missing wire.")
            unsupportedLoads > 0 -> Check("Loads", Level.WARNING, "Loads: ${model.loads.size}; unsupported types: $unsupportedLoads.")
            else -> Check("Loads", Level.OK, "Loads: ${model.loads.size}; indices and supported types are valid.")
        }

        val gap = nearestAlmostConnectedEndpoints(model)
        checks += if (gap == null) {
            Check("Nodes / gaps", Level.OK, "No suspicious nearly coincident wire ends found.")
        } else {
            Check("Nodes / gaps", Level.WARNING, "Possible micro-gap %.3f mm between wires ${gap.first + 1} and ${gap.second + 1}.".format(gap.distanceM * 1000.0))
        }

        val intersections = interiorIntersections(model, limit = 4)
        checks += if (intersections.isEmpty()) {
            Check("Wire intersections", Level.OK, "No physical intersections without a common end node found.")
        } else {
            val text = intersections.joinToString { "${it.first + 1}↔${it.second + 1}" }
            Check("Wire intersections", Level.WARNING, "Possible intersection without an NEC node: $text. Check whether it should be electrically connected.")
        }

        val zShift = if (model.groundType != 0) model.addHeightM else 0.0
        val minGroundZ = model.wires.minOfOrNull { min(it.z1 + zShift, it.z2 + zShift) } ?: 0.0
        checks += when {
            model.groundType == 0 -> Check("Ground", Level.OK, "Free Space; ground image is not used.")
            minGroundZ < -1e-5 -> Check("Ground", Level.ERROR, "After Add height, part of the geometry is below z=0: min z=%.4f m.".format(minGroundZ))
            else -> Check("Ground", Level.OK, "Ground type=${model.groundType}; min z=%.4f m after Add height.".format(minGroundZ))
        }

        val loopLike = listOf("loop", "quad", "delta", "hentenna", "петл", "рам").any { model.antennaKind.contains(it, true) || model.title.contains(it, true) }
        if (loopLike) {
            val dangling = danglingEndpointCount(model)
            checks += if (dangling == 0) {
                Check("Closed loops", Level.OK, "End nodes are closed; no open ends found in loop/quad/delta topology.")
            } else {
                Check("Closed loops", Level.WARNING, "Found $dangling free end nodes in loop/quad/delta model. If these are not feed/stub/boom nodes, check loop closure.")
            }
        }

        if (solved == null) {
            checks += Check("NEC-2 FULL solution", Level.WARNING, "The main FULL calculation has not been run yet — Zin and currents were not checked.")
        } else {
            val z = solved.primary
            checks += when {
                !z.rOhm.isFinite() || !z.xOhm.isFinite() -> Check("Input impedance", Level.ERROR, "NEC-2 returned NaN/∞.")
                z.rOhm < -1e-6 -> Check("Input impedance", Level.ERROR, "R=%.3f Ω < 0 for a passive model.".format(z.rOhm))
                else -> Check("Input impedance", Level.OK, "Zin = ${z.formattedZ()}.")
            }

            val badCurrents = solved.segments.count { !it.currentReA.isFinite() || !it.currentImA.isFinite() || !it.lengthM.isFinite() }
            checks += when {
                badCurrents > 0 -> Check("Complex currents", Level.ERROR, "Invalid current segments: $badCurrents.")
                solved.currentPeakA <= 1e-14 -> Check("Complex currents", Level.WARNING, "All currents are practically zero; check the Source.")
                else -> Check("Complex currents", Level.OK, "Received ${solved.segments.size} segments; Ipeak=%.4g A.".format(solved.currentPeakA))
            }

            val src = solved.primary
            val sourceExists = solved.segments.any { it.tag == src.tag && it.segment == src.segment }
            checks += if (sourceExists) {
                Check("EX mapping", Level.OK, "Main EX: tag=${src.tag}, segment=${src.segment}; segment is present in the current array.")
            } else {
                Check("EX mapping", Level.ERROR, "EX tag=${src.tag}, segment=${src.segment} was not found among returned currents.")
            }

            val loadedTags = model.loads.map { it.wireIndex + 1 }.toSet()
            var sharpJumps = 0
            val peak = solved.currentPeakA.coerceAtLeast(1e-30)
            solved.segments.groupBy { it.tag }.forEach { (tag, rows) ->
                val sorted = rows.sortedBy { it.segment }
                for (i in 1 until sorted.size) {
                    val a = sorted[i - 1]
                    val b = sorted[i]
                    if (tag == src.tag && (a.segment == src.segment || b.segment == src.segment)) continue
                    if (tag in loadedTags) continue
                    val ma = a.amplitudeA
                    val mb = b.amplitudeA
                    if (max(ma, mb) < peak * 0.08) continue
                    val dr = a.currentReA - b.currentReA
                    val di = a.currentImA - b.currentImA
                    val jump = sqrt(dr * dr + di * di) / max(max(ma, mb), 1e-30)
                    val localElectrical = max(a.lengthM, b.lengthM) / lambda
                    if (localElectrical <= 0.10 && jump > 1.60) sharpJumps++
                }
            }
            checks += if (sharpJumps == 0) {
                Check("Current continuity", Level.OK, "No abrupt complex-current jumps found between adjacent segments outside Source/Load.")
            } else {
                Check("Current continuity", Level.WARNING, "Detected abrupt complex-current transitions: $sharpJumps. Check connections/segmentation and the current plot.")
            }

            solved.warning?.let { checks += Check("OpenNEC warning", Level.WARNING, it) }
        }

        return Report(checks)
    }

    fun runConvergence(
        model: MaaModel,
        baseConfig: Nec2Core.SegmentationConfig,
        onProgress: (done: Int, total: Int, message: String) -> Unit = { _, _, _ -> }
    ): ConvergenceReport {
        require(OpenNecFull.isAvailable) { OpenNecFull.availabilityMessage ?: "NEC-2 FULL unavailable" }
        val basePlan = Nec2Core.planSegmentation(model, baseConfig)
        val d0 = basePlan.effectiveSegmentsPerWavelength.coerceIn(8, 100)
        val densities = listOf(
            d0,
            max(d0 + 1, (d0 * 1.5).roundToInt()).coerceAtMost(100),
            max(d0 + 2, d0 * 2).coerceAtMost(100)
        ).distinct()
        require(densities.size >= 2) { "Cannot increase mesh density: the 100 segments/λ limit has already been reached." }

        val maxN = baseConfig.maxSegments.coerceIn(max(model.wires.size, 24), 600)
        val r0 = (model.referenceImpedanceOhms ?: 50.0).coerceAtLeast(1.0)
        val samples = mutableListOf<ConvergenceSample>()
        densities.forEachIndexed { index, density ->
            onProgress(index, densities.size, "NEC-2 FULL: $density segments/λ")
            val cfg = Nec2Core.SegmentationConfig(Nec2Core.SegmentationMode.MANUAL, density, maxN)
            val plan = Nec2Core.planSegmentation(model, cfg)
            val solved = OpenNecFull.solveModel(model, cfg)
            val pattern = OpenNecPattern.calculate(model, solved)
            val z = solved.primary
            samples += ConvergenceSample(
                densityPerLambda = density,
                segmentCount = solved.segments.size,
                capped = plan.capApplied || solved.warning.orEmpty().contains("MAX N", ignoreCase = true),
                rOhm = z.rOhm,
                xOhm = z.xOhm,
                swr = z.swr(r0),
                p1PeakDeg = peakAngle(pattern.previewTop),
                p2PeakDeg = peakAngle(pattern.previewSide),
                p1HpbwDeg = pattern.previewTop.hpbwDeg,
                p2HpbwDeg = pattern.previewSide.hpbwDeg,
                p1FbDb = pattern.previewTop.frontBackDb,
                p2FbDb = pattern.previewSide.frontBackDb,
                p1 = pattern.previewTop,
                p2 = pattern.previewSide,
                solverWarning = solved.warning
            )
            onProgress(index + 1, densities.size, "Done: ${solved.segments.size} segments")
        }

        val a = samples[samples.lastIndex - 1]
        val b = samples.last()
        val dR = abs(b.rOhm - a.rOhm) / max(abs(b.rOhm), 1.0) * 100.0
        val dX = abs(b.xOhm - a.xOhm)
        val za = sqrt(a.rOhm * a.rOhm + a.xOhm * a.xOhm)
        val dz = sqrt((b.rOhm - a.rOhm) * (b.rOhm - a.rOhm) + (b.xOhm - a.xOhm) * (b.xOhm - a.xOhm)) / max(za, 1.0) * 100.0
        val peakShift = max(circularDistance(a.p1PeakDeg, b.p1PeakDeg), circularDistance(a.p2PeakDeg, b.p2PeakDeg))
        val rms = max(patternRmsDb(a.p1, b.p1), patternRmsDb(a.p2, b.p2))
        val capped = samples.any { it.capped } || samples.map { it.segmentCount }.distinct().size < samples.size

        val level = when {
            capped -> Level.WARNING
            dz <= 3.0 && dR <= 3.0 && peakShift <= 2.0 && rms <= 1.0 -> Level.OK
            dz <= 8.0 && dR <= 8.0 && peakShift <= 5.0 && rms <= 2.5 -> Level.WARNING
            else -> Level.ERROR
        }
        val note = when {
            capped -> "One or more runs reached MAX N or produced the same N. Full convergence is not proven — increase MAX N or simplify the geometry."
            level == Level.OK -> "The result is stable with mesh refinement: Zin and the radiation-pattern shape change only slightly."
            level == Level.WARNING -> "Changes are noticeable. A denser mesh/larger MAX N is recommended for an accurate result."
            else -> "The result depends strongly on segmentation. Do not trust Zin/pattern until the cause is resolved."
        }
        return ConvergenceReport(samples, level, dR, dX, dz, peakShift, rms, note)
    }

    private data class PairDistance(val first: Int, val second: Int, val distanceM: Double)

    private fun nearestAlmostConnectedEndpoints(model: MaaModel): PairDistance? {
        data class E(val wire: Int, val x: Double, val y: Double, val z: Double)
        val e = buildList {
            model.wires.forEachIndexed { i, w ->
                add(E(i, w.x1, w.y1, w.z1)); add(E(i, w.x2, w.y2, w.z2))
            }
        }
        val tol = min(0.001 * model.wavelengthM, 0.0015).coerceAtLeast(2e-5)
        var best: PairDistance? = null
        for (i in e.indices) for (j in i + 1 until e.size) {
            if (e[i].wire == e[j].wire) continue
            val d = distance(e[i].x,e[i].y,e[i].z,e[j].x,e[j].y,e[j].z)
            if (d > 1e-8 && d < tol && (best == null || d < best!!.distanceM)) best = PairDistance(e[i].wire, e[j].wire, d)
        }
        return best
    }

    private data class Intersection(val first: Int, val second: Int)

    private fun interiorIntersections(model: MaaModel, limit: Int): List<Intersection> {
        val out = mutableListOf<Intersection>()
        for (i in model.wires.indices) for (j in i + 1 until model.wires.size) {
            val a = model.wires[i]; val b = model.wires[j]
            if (shareEndpoint(a, b)) continue
            val closest = segmentDistance(a, b)
            val physicalTol = (a.radiusM + b.radiusM) * 1.05 + 1e-7
            if (closest.distance <= physicalTol && closest.ta in 0.01..0.99 && closest.tb in 0.01..0.99) {
                out += Intersection(i, j)
                if (out.size >= limit) return out
            }
        }
        return out
    }

    private data class Closest(val distance: Double, val ta: Double, val tb: Double)

    /** Closest points of two finite 3-D segments, with parameters in [0,1]. */
    private fun segmentDistance(a: MaaWire, b: MaaWire): Closest {
        val ux=a.dx; val uy=a.dy; val uz=a.dz
        val vx=b.dx; val vy=b.dy; val vz=b.dz
        val wx=a.x1-b.x1; val wy=a.y1-b.y1; val wz=a.z1-b.z1
        val aa=dot(ux,uy,uz,ux,uy,uz); val bb=dot(ux,uy,uz,vx,vy,vz); val cc=dot(vx,vy,vz,vx,vy,vz)
        val dd=dot(ux,uy,uz,wx,wy,wz); val ee=dot(vx,vy,vz,wx,wy,wz)
        val den=aa*cc-bb*bb
        var sN:Double; var sD=den; var tN:Double; var tD=den
        if (den < 1e-20) { sN=0.0; sD=1.0; tN=ee; tD=cc }
        else {
            sN=bb*ee-cc*dd; tN=aa*ee-bb*dd
            if (sN < 0.0) { sN=0.0; tN=ee; tD=cc }
            else if (sN > sD) { sN=sD; tN=ee+bb; tD=cc }
        }
        if (tN < 0.0) {
            tN=0.0
            if (-dd < 0.0) sN=0.0 else if (-dd > aa) sN=sD else { sN=-dd; sD=aa }
        } else if (tN > tD) {
            tN=tD
            if (-dd+bb < 0.0) sN=0.0 else if (-dd+bb > aa) sN=sD else { sN=-dd+bb; sD=aa }
        }
        val sc=if(abs(sN)<1e-20)0.0 else sN/sD
        val tc=if(abs(tN)<1e-20)0.0 else tN/tD
        val dx=wx+sc*ux-tc*vx; val dy=wy+sc*uy-tc*vy; val dz=wz+sc*uz-tc*vz
        return Closest(sqrt(dx*dx+dy*dy+dz*dz), sc.coerceIn(0.0,1.0), tc.coerceIn(0.0,1.0))
    }

    private fun danglingEndpointCount(model: MaaModel): Int {
        data class E(val x:Double,val y:Double,val z:Double)
        val all = mutableListOf<E>()
        model.wires.forEach { w -> all += E(w.x1,w.y1,w.z1); all += E(w.x2,w.y2,w.z2) }
        val tol = 1e-7
        return all.indices.count { i ->
            all.indices.none { j -> j != i && distance(all[i].x,all[i].y,all[i].z,all[j].x,all[j].y,all[j].z) <= tol }
        }
    }

    private fun shareEndpoint(a:MaaWire,b:MaaWire):Boolean {
        val tol=1e-8
        return distance(a.x1,a.y1,a.z1,b.x1,b.y1,b.z1)<=tol || distance(a.x1,a.y1,a.z1,b.x2,b.y2,b.z2)<=tol ||
            distance(a.x2,a.y2,a.z2,b.x1,b.y1,b.z1)<=tol || distance(a.x2,a.y2,a.z2,b.x2,b.y2,b.z2)<=tol
    }

    private fun sourcePosition(desc: String?): Char {
        val d = desc.orEmpty().trim()
        return Regex("(?i)(?:^|[,;\\s])([BCE])(?:$|[,;\\s])").find(d)?.groupValues?.getOrNull(1)?.uppercase()?.firstOrNull() ?: 'C'
    }

    private fun peakAngle(p: MaaPatternPreview): Double = p.points.maxByOrNull { it.db }?.angleDeg ?: 0.0

    private fun patternRmsDb(a: MaaPatternPreview, b: MaaPatternPreview): Double {
        val n = min(a.points.size, b.points.size)
        if (n == 0) return Double.POSITIVE_INFINITY
        var sum = 0.0; var count = 0
        for (i in 0 until n) {
            val av = a.points[i].db; val bv = b.points[i].db
            if (max(av, bv) < -40.0) continue
            val d = av - bv; sum += d*d; count++
        }
        return if (count == 0) 0.0 else sqrt(sum / count)
    }

    private fun circularDistance(a: Double, b: Double): Double {
        var d = abs(a-b) % 360.0
        if (d > 180.0) d = 360.0-d
        return d
    }

    private fun dot(ax:Double,ay:Double,az:Double,bx:Double,by:Double,bz:Double)=ax*bx+ay*by+az*bz
    private fun distance(ax:Double,ay:Double,az:Double,bx:Double,by:Double,bz:Double):Double {
        val dx=ax-bx; val dy=ay-by; val dz=az-bz; return sqrt(dx*dx+dy*dy+dz*dz)
    }
}
