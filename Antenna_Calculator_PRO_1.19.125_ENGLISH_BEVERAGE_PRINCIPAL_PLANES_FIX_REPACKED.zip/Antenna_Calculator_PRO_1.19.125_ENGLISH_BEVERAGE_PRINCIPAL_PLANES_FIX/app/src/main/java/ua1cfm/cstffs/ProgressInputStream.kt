package ua1cfm.cstffs

import java.io.FilterInputStream
import java.io.InputStream

class ProgressInputStream(
    input: InputStream,
    private val totalBytes: Long,
    private val onProgress: (Int) -> Unit
) : FilterInputStream(input) {
    private var readBytes = 0L
    private var lastPercent = -1

    override fun read(): Int {
        val value = super.read()
        if (value >= 0) report(1)
        return value
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        val count = super.read(buffer, offset, length)
        if (count > 0) report(count.toLong())
        return count
    }

    private fun report(delta: Long) {
        readBytes += delta
        if (totalBytes <= 0L) return
        val percent = ((readBytes * 100L) / totalBytes).toInt().coerceIn(0, 100)
        if (percent != lastPercent) {
            lastPercent = percent
            onProgress(percent)
        }
    }
}
