package ua1cfm.cstffs

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.io.Closeable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.yield

/** Direct Android USB-host transport for LiteVNA64 / SAA2-compatible CDC devices. */
object LiteVnaUsb {
    data class DeviceInfo(
        val product: String,
        val vendorId: Int,
        val productId: Int,
        val deviceVariant: Int,
        val protocolVersion: Int,
        val hardwareRevision: Int,
        val firmwareMajor: Int,
        val firmwareMinor: Int
    ) {
        val shortText: String
            get() = "$product • VID:PID %04X:%04X • HW %d • FW %d.%d • protocol %d".format(
                vendorId, productId, hardwareRevision, firmwareMajor, firmwareMinor, protocolVersion
            )
    }

    data class Measurement(val info: DeviceInfo, val data: TouchstoneData)

    fun manager(context: Context): UsbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    data class ScanResult(
        val device: UsbDevice?,
        val message: String,
        val details: String
    )

    private const val STM_VID = 0x0483
    private const val STM_VCP_PID = 0x5740

    fun findBestDevice(manager: UsbManager): UsbDevice? = scan(manager).device

    /**
     * Enumerates every USB device Android exposes and returns the most likely LiteVNA.
     * Important: product/manufacturer strings are not reliable before USB permission is granted,
     * therefore known VID:PID and interface descriptors are used as primary evidence.
     */
    fun scan(manager: UsbManager): ScanResult {
        val devices = manager.deviceList.values.toList()
        if (devices.isEmpty()) {
            return ScanResult(
                device = null,
                message = "Android does not see any USB devices. Check USB OTG/Host, the DATA cable, and that LiteVNA is powered on.",
                details = "UsbManager.deviceList = 0"
            )
        }

        val ranked = devices.mapNotNull { d -> scoreDevice(d)?.let { it to d } }.sortedByDescending { it.first }
        val best = ranked.firstOrNull()?.second
        val details = devices.joinToString("\n") { describeDevice(it) }

        if (best != null) {
            return ScanResult(
                device = best,
                message = "Found ${deviceLabel(best)}",
                details = details
            )
        }

        val dfu = devices.firstOrNull { isDfuDevice(it) }
        if (dfu != null) {
            return ScanResult(
                device = null,
                message = "Found DFU/bootloader ${vidPid(dfu)}. Restart LiteVNA in normal mode.",
                details = details
            )
        }

        return ScanResult(
            device = null,
            message = "USB is present, but LiteVNA/CDC was not recognized. The actual VID:PID and Android interfaces are shown below.",
            details = details
        )
    }

    fun deviceLabel(device: UsbDevice): String {
        val product = runCatching { device.productName }.getOrNull().orEmpty().ifBlank { "USB CDC/VNA" }
        return "$product • VID:PID %04X:%04X".format(device.vendorId, device.productId)
    }

    fun measure(
        manager: UsbManager,
        device: UsbDevice,
        config: LiteVnaProtocol.SweepConfig,
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }
    ): Measurement {
        Session.open(manager, device).use { session ->
            val info = validateSession(session)
            val raw = session.readSweep(config, onProgress)
            val ts = LiteVnaProtocol.buildTouchstone(config, raw)
            return Measurement(info, ts)
        }
    }

    /**
     * Keeps one USB connection open and continuously receives complete sweeps.
     * LiteVNA itself scans continuously in RAW USB mode; we only drain the FIFO sweep-by-sweep.
     * Cancellation is checked between USB blocks and after every completed sweep.
     */
    suspend fun measureContinuous(
        manager: UsbManager,
        device: UsbDevice,
        config: LiteVnaProtocol.SweepConfig,
        onProgress: (sweepNumber: Long, done: Int, total: Int) -> Unit = { _, _, _ -> },
        onRecovery: (stage: String, attempt: Int, message: String) -> Unit = { _, _, _ -> },
        onSweep: suspend (measurement: Measurement, sweepNumber: Long) -> Unit
    ) {
        var sweepNumber = 0L
        var reopenFailures = 0

        while (true) {
            currentCoroutineContext().ensureActive()
            try {
                Session.open(manager, device).use { session ->
                    val info = validateSession(session)
                    session.configureSweep(config)
                    reopenFailures = 0
                    var readFailures = 0
                    var sweepsSinceKeepAlive = 0

                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val nextNumber = sweepNumber + 1L
                        val raw = try {
                            session.readNextSweep(config) { done, total ->
                                onProgress(nextNumber, done, total)
                            }
                        } catch (e: kotlinx.coroutines.CancellationException) {
                            throw e
                        } catch (e: Throwable) {
                            readFailures++
                            onRecovery("RESYNC", readFailures, e.message ?: e::class.simpleName.orEmpty())
                            if (readFailures >= 12) throw e

                            // A transient Android USB timeout or a FIFO overtake should not kill LIVE.
                            // Clear stale records and restart the analyzer sweep inside the SAME USB session.
                            runCatching { session.configureSweep(config) }
                                .onFailure { cfgErr ->
                                    onRecovery("RECONFIGURE", readFailures, cfgErr.message ?: cfgErr::class.simpleName.orEmpty())
                                }
                            delay((80L * readFailures).coerceAtMost(400L))
                            continue
                        }

                        readFailures = 0
                        currentCoroutineContext().ensureActive()
                        val ts = LiteVnaProtocol.buildTouchstone(config, raw)
                        sweepNumber = nextNumber
                        onSweep(Measurement(info, ts), sweepNumber)

                        // Periodically re-arm USB sweep mode even when reads are healthy.
                        // LiteVNA documentation says the sweep is always running in USB data mode,
                        // so this is a watchdog against rare firmware/USB stalls seen on Android OTG.
                        sweepsSinceKeepAlive++
                        if (sweepsSinceKeepAlive >= 20) {
                            runCatching { session.rearmContinuousSweep(config) }
                                .onSuccess {
                                    onRecovery("KEEPALIVE", 1, "Periodic LiteVNA sweep re-arm")
                                }
                                .onFailure { keepAliveErr ->
                                    onRecovery("KEEPALIVE", 1, keepAliveErr.message ?: keepAliveErr::class.simpleName.orEmpty())
                                }
                            sweepsSinceKeepAlive = 0
                        }
                        yield()
                    }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                reopenFailures++
                onRecovery("REOPEN", reopenFailures, e.message ?: e::class.simpleName.orEmpty())
                // Never terminate LIVE merely because Android temporarily stalls USB while the
                // user scrolls/renders a heavy Canvas. Keep trying until the user explicitly STOPs
                // or the coroutine is cancelled. The last valid sweep remains visible in the UI.
                delay((250L * reopenFailures.coerceAtMost(8)).coerceAtMost(2000L))
            }
        }
    }

    private fun validateSession(session: Session): DeviceInfo {
        if (!session.indicate()) error("LiteVNA did not respond to the INDICATE command")
        val info = session.readDeviceInfo()
        // The LiteVNA manual defines deviceVariant=2 for normal LiteVNA operation.
        if (info.deviceVariant != 2) {
            error("The USB device responded, but deviceVariant=${info.deviceVariant}; LiteVNA variant=2 was expected")
        }
        if (info.firmwareMajor == 0xff) {
            error("LiteVNA is in DFU/bootloader mode; restart the device in normal mode")
        }
        return info
    }

    private fun scoreDevice(device: UsbDevice): Int? {
        var score = 0
        var identityEvidence = false

        // LiteVNA/NanoVNA-family ChibiOS virtual COM commonly enumerates as 0483:5740.
        // This must be checked before product strings: Android may hide strings until permission.
        if (device.vendorId == STM_VID && device.productId == STM_VCP_PID) {
            score += 10_000
            identityEvidence = true
        }

        val name = (runCatching { device.productName }.getOrNull().orEmpty() + " " +
            runCatching { device.manufacturerName }.getOrNull().orEmpty()).lowercase()
        if ("litevna" in name) { score += 1000; identityEvidence = true }
        if ("nanovna" in name || "saa2" in name) { score += 500; identityEvidence = true }
        if ("vna" in name) { score += 300; identityEvidence = true }
        if ("chibios" in name || "virtual com" in name) { score += 100; identityEvidence = true }

        if (device.deviceClass == UsbConstants.USB_CLASS_COMM) {
            score += 100
            identityEvidence = true
        }
        if (device.deviceClass == UsbConstants.USB_CLASS_PER_INTERFACE) score += 10

        var hasBulkPair = false
        var hasCdcData = false
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            if (intf.interfaceClass == UsbConstants.USB_CLASS_CDC_DATA) {
                hasCdcData = true
                identityEvidence = true
                score += 200
            }
            if (hasBulkInOut(intf)) hasBulkPair = true
        }

        // A CDC/VNA without visible BULK endpoints is still worth selecting so the UI can
        // request permission and Session.open() can report the exact descriptor problem.
        if (hasBulkPair) score += 500
        else if (device.vendorId == STM_VID && device.productId == STM_VCP_PID) score += 50
        else if (!hasCdcData) return null

        return if (identityEvidence) score else null
    }

    private fun hasBulkInOut(intf: UsbInterface): Boolean {
        var hasIn = false
        var hasOut = false
        for (e in 0 until intf.endpointCount) {
            val ep = intf.getEndpoint(e)
            if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
            if (ep.direction == UsbConstants.USB_DIR_IN) hasIn = true
            if (ep.direction == UsbConstants.USB_DIR_OUT) hasOut = true
        }
        return hasIn && hasOut
    }

    private fun isDfuDevice(device: UsbDevice): Boolean =
        device.productId == 0xdf11 && (device.vendorId == 0x0483 || device.vendorId == 0x2e3c)

    private fun vidPid(device: UsbDevice): String =
        "VID:PID %04X:%04X".format(device.vendorId, device.productId)

    private fun describeDevice(device: UsbDevice): String {
        val interfaces = (0 until device.interfaceCount).joinToString("; " ) { index ->
            val intf = device.getInterface(index)
            val endpoints = (0 until intf.endpointCount).joinToString(",") { e ->
                val ep = intf.getEndpoint(e)
                val dir = if (ep.direction == UsbConstants.USB_DIR_IN) "IN" else "OUT"
                val type = when (ep.type) {
                    UsbConstants.USB_ENDPOINT_XFER_BULK -> "BULK"
                    UsbConstants.USB_ENDPOINT_XFER_INT -> "INT"
                    UsbConstants.USB_ENDPOINT_XFER_ISOC -> "ISOC"
                    UsbConstants.USB_ENDPOINT_XFER_CONTROL -> "CTRL"
                    else -> ep.type.toString()
                }
                "$type-$dir@${ep.address}"
            }.ifBlank { "no-endpoints" }
            "I$index class=${intf.interfaceClass}/${intf.interfaceSubclass}/${intf.interfaceProtocol} [$endpoints]"
        }.ifBlank { "no-interfaces" }
        return "${vidPid(device)} class=${device.deviceClass}/${device.deviceSubclass}/${device.deviceProtocol} $interfaces"
    }

    private class Session(
        private val device: UsbDevice,
        private val connection: UsbDeviceConnection,
        private val dataInterface: UsbInterface,
        private val commInterface: UsbInterface?,
        private val epIn: UsbEndpoint,
        private val epOut: UsbEndpoint
    ) : Closeable {

        companion object {
            fun open(manager: UsbManager, device: UsbDevice): Session {
                if (!manager.hasPermission(device)) error("Android USB access permission was not granted")
                var selected: UsbInterface? = null
                var epIn: UsbEndpoint? = null
                var epOut: UsbEndpoint? = null
                var comm: UsbInterface? = null

                for (i in 0 until device.interfaceCount) {
                    val intf = device.getInterface(i)
                    if (intf.interfaceClass == UsbConstants.USB_CLASS_COMM && comm == null) comm = intf
                    var localIn: UsbEndpoint? = null
                    var localOut: UsbEndpoint? = null
                    for (e in 0 until intf.endpointCount) {
                        val ep = intf.getEndpoint(e)
                        if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                        if (ep.direction == UsbConstants.USB_DIR_IN) localIn = ep
                        else if (ep.direction == UsbConstants.USB_DIR_OUT) localOut = ep
                    }
                    if (localIn != null && localOut != null) {
                        // Prefer the CDC data interface, otherwise accept a VNA-compatible bulk pair.
                        if (selected == null || intf.interfaceClass == UsbConstants.USB_CLASS_CDC_DATA) {
                            selected = intf
                            epIn = localIn
                            epOut = localOut
                            if (intf.interfaceClass == UsbConstants.USB_CLASS_CDC_DATA) break
                        }
                    }
                }
                val data = selected ?: error("USB bulk IN/OUT interface not found")
                val input = epIn ?: error("USB bulk IN endpoint not found")
                val output = epOut ?: error("USB bulk OUT endpoint not found")
                val c = manager.openDevice(device) ?: error("Android could not open the USB device")
                if (!c.claimInterface(data, true)) {
                    c.close()
                    error("Failed to claim the USB data interface")
                }
                if (comm != null && comm.id != data.id) runCatching { c.claimInterface(comm, true) }

                val s = Session(device, c, data, comm, input, output)
                s.initCdc()
                return s
            }
        }

        private fun initCdc() {
            val ci = commInterface ?: return
            // CDC SET_LINE_CODING: baud is irrelevant for LiteVNA USB, but many CDC stacks
            // expect a conventional 8N1 setup before bulk traffic.
            val lineCoding = byteArrayOf(
                0x00, 0xC2.toByte(), 0x01, 0x00, // 115200 LE
                0x00, // 1 stop bit
                0x00, // no parity
                0x08  // 8 data bits
            )
            runCatching {
                connection.controlTransfer(0x21, 0x20, 0, ci.id, lineCoding, lineCoding.size, 1000)
                connection.controlTransfer(0x21, 0x22, 0x03, ci.id, null, 0, 1000)
            }
        }

        fun indicate(): Boolean {
            writeAll(LiteVnaProtocol.indicate())
            val reply = readExact(1, 2500)
            return reply[0].toInt() and 0xff == 0x32
        }

        fun readDeviceInfo(): DeviceInfo {
            fun reg(a: Int): Int {
                writeAll(LiteVnaProtocol.readByte(a))
                return readExact(1, 2500)[0].toInt() and 0xff
            }
            val product = runCatching { device.productName }.getOrNull().orEmpty().ifBlank { "LiteVNA" }
            return DeviceInfo(
                product = product,
                vendorId = device.vendorId,
                productId = device.productId,
                deviceVariant = reg(LiteVnaProtocol.REG_DEVICE_VARIANT),
                protocolVersion = reg(LiteVnaProtocol.REG_PROTOCOL_VERSION),
                hardwareRevision = reg(LiteVnaProtocol.REG_HARDWARE_REVISION),
                firmwareMajor = reg(LiteVnaProtocol.REG_FIRMWARE_MAJOR),
                firmwareMinor = reg(LiteVnaProtocol.REG_FIRMWARE_MINOR)
            )
        }

        fun configureSweep(config: LiteVnaProtocol.SweepConfig) {
            // Enter USB sweep mode. The device continuously scans once any sweep register is written.
            writeAll(LiteVnaProtocol.writeByte(LiteVnaProtocol.REG_VALUES_FIFO, 0)) // clear stale FIFO
            writeAll(LiteVnaProtocol.write8(LiteVnaProtocol.REG_SWEEP_START_HZ, config.startHz))
            writeAll(LiteVnaProtocol.write8(LiteVnaProtocol.REG_SWEEP_STEP_HZ, config.stepHz))
            writeAll(LiteVnaProtocol.write2(LiteVnaProtocol.REG_SWEEP_POINTS, config.points))
            writeAll(LiteVnaProtocol.write2(LiteVnaProtocol.REG_VALUES_PER_FREQUENCY, 1))
            writeAll(LiteVnaProtocol.writeByte(LiteVnaProtocol.REG_AVERAGE, config.average))
            writeAll(LiteVnaProtocol.writeByte(LiteVnaProtocol.REG_RAW_SAMPLES_MODE, 0)) // USB mode
            writeAll(LiteVnaProtocol.writeByte(LiteVnaProtocol.REG_CHANNEL_SELECT, 0)) // S11 + S21
            writeAll(LiteVnaProtocol.writeByte(LiteVnaProtocol.REG_VALUES_FIFO, 0)) // fresh data only
        }

        /**
         * Lightweight watchdog re-arm for long Android LIVE sessions.
         * Reasserts USB mode and current sweep parameters, then clears stale FIFO data.
         * This is intentionally called only between complete sweeps.
         */
        fun rearmContinuousSweep(config: LiteVnaProtocol.SweepConfig) {
            writeAll(LiteVnaProtocol.write8(LiteVnaProtocol.REG_SWEEP_START_HZ, config.startHz))
            writeAll(LiteVnaProtocol.write8(LiteVnaProtocol.REG_SWEEP_STEP_HZ, config.stepHz))
            writeAll(LiteVnaProtocol.write2(LiteVnaProtocol.REG_SWEEP_POINTS, config.points))
            writeAll(LiteVnaProtocol.write2(LiteVnaProtocol.REG_VALUES_PER_FREQUENCY, 1))
            writeAll(LiteVnaProtocol.writeByte(LiteVnaProtocol.REG_AVERAGE, config.average))
            writeAll(LiteVnaProtocol.writeByte(LiteVnaProtocol.REG_RAW_SAMPLES_MODE, 0))
            writeAll(LiteVnaProtocol.writeByte(LiteVnaProtocol.REG_CHANNEL_SELECT, 0))
            writeAll(LiteVnaProtocol.writeByte(LiteVnaProtocol.REG_VALUES_FIFO, 0))
        }

        fun readSweep(
            config: LiteVnaProtocol.SweepConfig,
            onProgress: (done: Int, total: Int) -> Unit
        ): List<LiteVnaProtocol.RawValue> {
            configureSweep(config)
            return readNextSweep(config, onProgress)
        }

        /**
         * Collect one coherent sweep. We synchronize on frequencyIndex=0 so a read that starts
         * in the middle of the continuously running FIFO cannot mix two different sweeps.
         */
        fun readNextSweep(
            config: LiteVnaProtocol.SweepConfig,
            onProgress: (done: Int, total: Int) -> Unit
        ): List<LiteVnaProtocol.RawValue> {
            val values = arrayOfNulls<LiteVnaProtocol.RawValue>(config.points)
            var unique = 0
            var synced = false
            var batches = 0
            val maxBatches = ((config.points + 15) / 16) * 12 + 64

            while (unique < config.points) {
                if (batches++ > maxBatches) {
                    error("LiteVNA: failed to synchronize a complete sweep ($unique/${config.points})")
                }

                val remaining = (config.points - unique).coerceAtLeast(1)
                val requestCount = if (synced) minOf(32, remaining) else minOf(32, config.points)
                writeAll(LiteVnaProtocol.readFifo(requestCount))
                val block = readExact(requestCount * LiteVnaProtocol.FIFO_RECORD_BYTES, 8_000)

                for (offset in block.indices step LiteVnaProtocol.FIFO_RECORD_BYTES) {
                    val v = LiteVnaProtocol.parseRawValue(block, offset)
                    val idx = v.frequencyIndex
                    if (idx !in values.indices) continue

                    if (!synced) {
                        if (idx != 0) continue
                        values.fill(null)
                        values[0] = v
                        unique = 1
                        synced = true
                        onProgress(unique, config.points)
                        if (unique >= config.points) break
                        continue
                    }

                    // A new zero before completion means the previous partial sweep was overtaken.
                    // Restart from this newest sweep instead of mixing samples from two scans.
                    if (idx == 0 && unique < config.points) {
                        values.fill(null)
                        values[0] = v
                        unique = 1
                        onProgress(unique, config.points)
                        continue
                    }

                    if (values[idx] == null) {
                        values[idx] = v
                        unique++
                        onProgress(unique, config.points)
                    } else {
                        values[idx] = v
                    }

                    if (unique >= config.points) break
                }
            }

            return values.map { it ?: error("Internal sweep assembly error") }
        }

        private fun writeAll(bytes: ByteArray) {
            var offset = 0
            while (offset < bytes.size) {
                val slice = if (offset == 0) bytes else bytes.copyOfRange(offset, bytes.size)
                val n = connection.bulkTransfer(epOut, slice, slice.size, 3000)
                if (n <= 0) error("USB write timeout/error")
                offset += n
            }
        }

        private fun readExact(count: Int, timeoutMs: Int): ByteArray {
            val out = ByteArray(count)
            var offset = 0
            var timeoutCount = 0
            while (offset < count) {
                val chunk = ByteArray(count - offset)
                val n = connection.bulkTransfer(epIn, chunk, chunk.size, timeoutMs)
                if (n < 0) {
                    timeoutCount++
                    if (timeoutCount >= 3) error("USB read timeout ($offset/$count bytes)")
                    continue
                }
                if (n == 0) continue
                chunk.copyInto(out, destinationOffset = offset, startIndex = 0, endIndex = n)
                offset += n
                timeoutCount = 0
            }
            return out
        }

        override fun close() {
            // Best effort: return LiteVNA from USB sweep mode to normal device mode.
            runCatching { writeAll(LiteVnaProtocol.writeByte(LiteVnaProtocol.REG_RAW_SAMPLES_MODE, 2)) }
            runCatching { connection.releaseInterface(dataInterface) }
            commInterface?.takeIf { it.id != dataInterface.id }?.let { runCatching { connection.releaseInterface(it) } }
            connection.close()
        }
    }
}
