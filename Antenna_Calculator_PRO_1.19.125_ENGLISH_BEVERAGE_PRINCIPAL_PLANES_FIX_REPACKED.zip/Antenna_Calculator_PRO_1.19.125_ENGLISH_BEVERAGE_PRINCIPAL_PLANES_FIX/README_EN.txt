Antenna Calculator PRO 1.19.41 English
Copyright (c) 2026 UA1CFM

English edition based on the stable Russian 1.19.41 LiteVNA LIVE SINGLE PLOT build.

English UI coverage:
- CST FFS / HFSS FFD calculation screens
- 2D and 3D radiation pattern views
- reflector/feed analysis and phase-center tools
- amateur-radio calculators
- Touchstone / VNA / LiteVNA64 USB and LIVE sweep
- S11, S21, SWR and Smith Chart LIVE single-plot mode
- MAA antenna browser and NEC-2 FULL controls
- impedance, convergence and geometry diagnostics
- current/phase animation and Near Field E/H/B/S views
- USB/OpenNEC error and status messages

The numerical algorithms, stable NEC/OpenNEC solver path, LiteVNA USB protocol,
and LIVE single-plot architecture are unchanged from 1.19.41. Only visible text,
diagnostics text, and source comments were translated.

Note: Russian MMANA/MAA parser keywords are intentionally retained internally so
English builds can still open legacy MAA files that contain Russian section names.
These compatibility tokens are not user-interface text.
