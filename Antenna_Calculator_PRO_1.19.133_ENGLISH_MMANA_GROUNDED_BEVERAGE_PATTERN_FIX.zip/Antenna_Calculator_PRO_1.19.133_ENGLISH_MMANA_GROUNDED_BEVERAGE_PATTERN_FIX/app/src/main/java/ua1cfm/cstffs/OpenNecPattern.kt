package ua1cfm.cstffs

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Far-field pattern reconstructed directly from the complex segment currents solved by OpenNEC.
 *
 * NEC-2 FULL remains responsible for the electromagnetic solution (impedance + currents).  This
 * class only evaluates the standard thin-wire radiation integral for two display cuts.  Unlike the
 * old NEC2-alpha preview it never re-solves or calibrates the currents, so a Yagi pattern uses the
 * same complex currents that produced the displayed FULL input impedance.
 */
object OpenNecPattern {
    data class Result(
        val previewTop: MaaPatternPreview,
        val previewSide: MaaPatternPreview,
        val principalPlane1Label: String,
        val principalPlane2Label: String,
        val note: String
    )

    private data class C(val re: Double, val im: Double) {
        operator fun plus(o: C) = C(re + o.re, im + o.im)
        operator fun minus(o: C) = C(re - o.re, im - o.im)
        operator fun times(o: C) = C(re * o.re - im * o.im, re * o.im + im * o.re)
        operator fun times(v: Double) = C(re * v, im * v)
        operator fun div(o: C): C {
            val d = o.re * o.re + o.im * o.im
            return C((re * o.re + im * o.im) / d, (im * o.re - re * o.im) / d)
        }
        fun mag2(): Double = re * re + im * im
    }

    private fun csqrt(z: C): C {
        val r = kotlin.math.hypot(z.re, z.im)
        val a = kotlin.math.sqrt(kotlin.math.max(0.0, (r + z.re) * 0.5))
        val b0 = kotlin.math.sqrt(kotlin.math.max(0.0, (r - z.re) * 0.5))
        val b = if (z.im < 0.0) -b0 else b0
        return C(a, b)
    }

    private data class PlaneCut(val a: DoubleArray, val b: DoubleArray, val label: String)
    private data class RawCut(val power: DoubleArray, val peak: Double)

    /**
     * 1.19.128 MMANA-GAL compatible 2D display policy.
     *
     * MMANA-GAL does NOT rotate every antenna into an adaptive "principal plane". Its classic
     * Far field plots are tied to the model coordinate system:
     *   - left / horizontal plot: azimuth cut in a horizontal plane at the elevation of maximum
     *     radiation (if that elevation is > 87 deg, MMANA-GAL uses 45 deg instead);
     *   - right / vertical plot: fixed vertical XZ cut, i.e. azimuth 0/180 deg through the X axis;
     *   - angular samples are displayed at 1 deg resolution.
     *
     * This is display-only. NEC-2 FULL still supplies the electromagnetic field, impedance and
     * currents; no learned/corpus data can manufacture or rotate the radiation pattern.
     */
    fun calculate(model: MaaModel, solved: OpenNecFull.Result): Result {
        require(solved.segments.isNotEmpty()) { "NEC-2 FULL returned no currents for the radiation pattern." }
        require(model.frequencyMHz > 0.0) { "Invalid frequency." }

        val sampler = nativeSamplerOrNull(solved.nativePattern)
        val k = 2.0 * PI / model.wavelengthM
        val hasGround = model.groundType != 0
        val useImageFallback = model.groundType == 1 || model.groundType == 2

        fun sample(n: DoubleArray): Double = if (sampler != null) {
            sampler.powerForDirection(n, hasGround)
        } else {
            fieldPower(solved.segments, k, n, useImageFallback)
        }

        val elevationPeakDeg = mmanaElevationPeakDeg(model, sampler, solved.segments, k)
        val displayElevationDeg = if (elevationPeakDeg > 87.0) 45.0 else elevationPeakDeg
        val el = Math.toRadians(displayElevationDeg)
        val ce = cos(el)
        val se = sin(el)

        // 1.19.131: classic Beverage models need a vertical cut through the physical
        // travelling-wave wire. A fixed global XZ cut can completely miss the lobe when the
        // Beverage is drawn along Y or at an arbitrary azimuth. Keep the MMANA horizontal
        // azimuth rule, but rotate angle zero to the physical Beverage forward direction and
        // use the wire+Z plane for elevation. Non-Beverage models retain the 1.19.128 policy.
        val beverageAxes = if (isBeverageModel(model)) {
            val peakDir = findMainLobeDirection(model, sampler, solved.segments, k)
            fixedBeverageAxes(model, peakDir)
        } else null

        val azRaw = DoubleArray(361)
        var azPeak = 0.0
        for (idx in azRaw.indices) {
            val a = Math.toRadians(idx - 180.0)
            val horizontal = if (beverageAxes != null) {
                add(scale(beverageAxes.forward, cos(a)), scale(beverageAxes.transverse1, sin(a)))
            } else {
                doubleArrayOf(cos(a), sin(a), 0.0)
            }
            val n = doubleArrayOf(ce * horizontal[0], ce * horizontal[1], se)
            val q = sample(n)
            azRaw[idx] = q
            if (q > azPeak) azPeak = q
        }

        val elRaw = DoubleArray(361)
        var elPeak = 0.0
        for (idx in elRaw.indices) {
            val a = Math.toRadians(idx - 180.0)
            val n = if (beverageAxes != null) {
                add(scale(beverageAxes.forward, cos(a)), scale(beverageAxes.transverse2, sin(a)))
            } else {
                doubleArrayOf(cos(a), 0.0, sin(a))
            }
            val q = sample(n)
            elRaw[idx] = q
            if (q > elPeak) elPeak = q
        }

        // The horizontal cut contains the global upper-hemisphere peak by MMANA definition.
        // Use one common reference so the XZ cut keeps its true relative level.
        val commonPeak = max(azPeak, elPeak).coerceAtLeast(1e-30)
        val basisNote = if (sampler != null)
            "native OpenNEC RP / far_e_field coherent Eθ/Eφ"
        else if (solved.segments.all { it.hasNecCurrentBasis })
            "fallback OpenNEC NEC A/B/C current basis"
        else
            "legacy centre-current fallback"
        val groundNote = when (model.groundType) {
            0 -> "native Free Space"
            1 -> "native Perfect Ground"
            2 -> "native Real Ground epsr=13, sigma=0.005 S/m"
            -1 -> "native Sommerfeld-Norton ground"
            else -> "native OpenNEC ground"
        }
        val elevationText = "%.1f".format(java.util.Locale.US, displayElevationDeg)
        val autoText = "%.1f".format(java.util.Locale.US, elevationPeakDeg)
        val fallbackText = if (elevationPeakDeg > 87.0) " (MMANA >87° rule; auto peak $autoText°)" else ""
        val p1Label = beverageAxes?.label1 ?: "AZ XY • EL $elevationText°"
        val p2Label = beverageAxes?.label2 ?: "EL XZ • AZ 0°/180°"
        val planeNote = beverageAxes?.let {
            "Beverage MMANA-style physical cuts: azimuth at EL $elevationText°$fallbackText with 0° along the long wire; elevation in the long-wire/+Z plane."
        } ?: "MMANA-GAL 2D display rules: azimuth at EL $elevationText°$fallbackText; fixed XZ elevation cut through X axis."
        return Result(
            previewTop = finishPreview(azRaw, commonPeak),
            previewSide = finishPreview(elRaw, commonPeak),
            principalPlane1Label = p1Label,
            principalPlane2Label = p2Label,
            note = "$planeNote 1° display step. NEC-2 FULL pattern: $basisNote; $groundNote."
        )
    }

    /** Find MMANA's automatic elevation angle of maximum upper-hemisphere radiation. */
    private fun mmanaElevationPeakDeg(
        model: MaaModel,
        sampler: NativePatternSampler?,
        segments: List<OpenNecFull.SegmentCurrent>,
        k: Double
    ): Double {
        val hasGround = model.groundType != 0
        if (sampler != null) {
            // Coarse native RP search followed by a local 0.1° elevation / 0.5° azimuth refine.
            var bestEl = 0.0
            var bestAz = 0.0
            var bestPower = -1.0
            var el = 0.0
            while (el <= 90.0 + 1e-9) {
                val er = Math.toRadians(el)
                val ce = cos(er); val se = sin(er)
                var az = 0.0
                while (az < 360.0 - 1e-9) {
                    val ar = Math.toRadians(az)
                    val q = sampler.powerForDirection(doubleArrayOf(ce*cos(ar), ce*sin(ar), se), hasGround)
                    if (q > bestPower) { bestPower = q; bestEl = el; bestAz = az }
                    az += 2.5
                }
                el += 2.5
            }
            val el0 = (bestEl - 3.0).coerceAtLeast(0.0)
            val el1 = (bestEl + 3.0).coerceAtMost(90.0)
            val az0 = bestAz - 3.0
            val az1 = bestAz + 3.0
            el = el0
            while (el <= el1 + 1e-9) {
                val er = Math.toRadians(el)
                val ce = cos(er); val se = sin(er)
                var az = az0
                while (az <= az1 + 1e-9) {
                    var aa = az % 360.0; if (aa < 0.0) aa += 360.0
                    val ar = Math.toRadians(aa)
                    val q = sampler.powerForDirection(doubleArrayOf(ce*cos(ar), ce*sin(ar), se), hasGround)
                    if (q > bestPower) { bestPower = q; bestEl = el; bestAz = aa }
                    az += 0.5
                }
                el += 0.1
            }
            return (kotlin.math.round(bestEl * 10.0) / 10.0).coerceIn(0.0, 90.0)
        }

        // Old native payload fallback: retain a bounded search cost. This path is rarely used.
        var bestEl = 0.0
        var bestPower = -1.0
        var el = 0.0
        while (el <= 90.0 + 1e-9) {
            val er = Math.toRadians(el)
            val ce = cos(er); val se = sin(er)
            var az = 0.0
            while (az < 360.0 - 1e-9) {
                val ar = Math.toRadians(az)
                val n = doubleArrayOf(ce*cos(ar), ce*sin(ar), se)
                val q = fieldPower(segments, k, n, model.groundType == 1 || model.groundType == 2)
                if (q > bestPower) { bestPower = q; bestEl = el }
                az += 5.0
            }
            el += 1.0
        }
        return bestEl.coerceIn(0.0, 90.0)
    }



    private data class FixedMatchAxes(
        val forward: DoubleArray,
        val transverse1: DoubleArray,
        val transverse2: DoubleArray,
        val label1: String,
        val label2: String,
        val note: String
    )

    /**
     * 1.19.116: The Match corpus contains several electrically very different families under
     * one folder: T/Gamma/Omega matched Yagis, horizontal dipoles, vertical/GP radiators,
     * D/Delta/Quad loops and pure transformer examples.  Matching-network words must never be
     * allowed to redefine the radiation axis.  This helper recovers the radiator family first,
     * then defines the two physical principal planes from geometry.  It is used by BOTH the
     * direct 2D path and the 2D-from-3D path.
     */
    /**
     * 1.19.125: Beverage antennas must use MMANA-style physical principal planes.
     * The ground-reflected 3D maximum is allowed to rise in elevation, but it must NOT
     * rotate/re-center the 2D coordinate system.  P1 is the horizontal azimuth plane
     * containing the long wire; P2 is the vertical elevation plane containing the same
     * wire and +Z.  The forward/back sign is taken from the real NEC 3D maximum.
     */
    private fun isBeverageModel(model: MaaModel): Boolean {
        val semantic = (model.title + " " + model.fileNameHint.orEmpty()).lowercase(java.util.Locale.ROOT)
        return semantic.contains("beverage") || semantic.contains("beveridge") ||
            semantic.contains("tbev") || semantic.contains("l-bev") || semantic.contains("bidir_beverage")
    }

    private fun fixedBeverageAxes(model: MaaModel, peakVector: DoubleArray): FixedMatchAxes? {
        if (!isBeverageModel(model)) return null

        // A Beverage is defined by its long travelling-wave conductor, not by the short
        // feed/termination drops. Recover its TRUE horizontal direction, including diagonal
        // models, instead of snapping it to the nearest global X/Y axis.
        val mainWire = model.wires.maxByOrNull { it.lengthM } ?: return null
        var forward = normalize(doubleArrayOf(mainWire.dx, mainWire.dy, 0.0))
        if (norm(forward) < 1e-9) {
            val hAxis = if (kotlin.math.abs(mainWire.dx) >= kotlin.math.abs(mainWire.dy)) 'X' else 'Y'
            forward = axisVector(hAxis)
        }
        // Forward sign from the actual NEC solution. Ignore vertical component when selecting it.
        val peakHorizontal = doubleArrayOf(peakVector[0], peakVector[1], 0.0)
        if (norm(peakHorizontal) > 1e-9 && dot(peakHorizontal, forward) < 0.0) {
            forward = scale(forward, -1.0)
        }
        val z = axisVector('Z')
        var azTransverse = normalize(cross(z, forward))
        if (norm(azTransverse) < 1e-8) azTransverse = axisVector('Y')

        val az = Math.toDegrees(kotlin.math.atan2(forward[1], forward[0])).let { if (it < 0.0) it + 360.0 else it }
        val dir = "AZ %.1f° HORIZONTAL".format(java.util.Locale.US, az)
        return FixedMatchAxes(
            forward = forward,
            transverse1 = azTransverse,
            transverse2 = z,
            label1 = "P1 BEVERAGE AZ • $dir",
            label2 = "P2 BEVERAGE EL • $dir",
            note = "Beverage: MMANA-style fixed physical planes; P1 is horizontal azimuth along the wire, P2 is vertical elevation along the wire; the real elevation maximum remains inside P2."
        )
    }

    private fun fixedMatchAxes(model: MaaModel, peakVector: DoubleArray): FixedMatchAxes? {
        val path = model.fileNameHint.orEmpty().replace('\\', '/')
        val inMatchFolder = path.contains("/Match/", ignoreCase = true) || path.startsWith("Match/", ignoreCase = true)
        if (!inMatchFolder) return null

        val semantic = (model.title + " " + path).lowercase(java.util.Locale.ROOT)
        fun span(axis: Char): Double = when (axis) {
            'X' -> model.spanX
            'Y' -> model.spanY
            else -> model.spanZ
        }
        fun signedAxis(axis: Char): DoubleArray {
            val v = axisVector(axis)
            return if (dot(peakVector, v) >= 0.0) v else scale(v, -1.0)
        }
        fun longestAxis(exclude: Set<Char> = emptySet()): Char =
            listOf('X','Y','Z').filter { it !in exclude }.maxByOrNull(::span) ?: 'X'

        val explicitYagi = model.analysisProfile == "PARASITIC_ARRAY" ||
            semantic.contains("yagi") ||
            Regex("""\\b\\d{1,2}\\s*el(?:e)?""", RegexOption.IGNORE_CASE).containsMatchIn(semantic)
        val explicitLoop = semantic.contains("d-match") || semantic.contains("d match") ||
            semantic.contains("quad") || semantic.contains("delta")
        val explicitDipole = (semantic.contains("dipole") ||
            ((semantic.contains("t-match") || semantic.contains("t match")) && !explicitYagi && model.isPlanar)) && !explicitYagi
        val explicitVertical = !explicitYagi && !explicitLoop && !explicitDipole && (
            Regex("""(^|[^a-z])gp([^a-z]|$)""", RegexOption.IGNORE_CASE).containsMatchIn(semantic) ||
            semantic.contains("vertical") || semantic.contains("vert20") || semantic.contains("broadcast") ||
            // Geometry fallback for matching-network verticals whose filenames omit GP/Vertical.
            (model.groundType != 0 && model.spanZ > 0.0 && model.spanZ >= max(model.spanX, model.spanY) * 0.62 && model.sourceAxis == 'Z')
        )

        if (explicitYagi) {
            // A Yagi's longest overall span is often an element, not its boom (e.g. T-match Yagi).
            // Score each candidate boom axis by long wires transverse to it appearing at several
            // distinct stations.  This recovers X for the Match-folder Yagis even when spanY > spanX.
            fun boomScore(axis: Char): Double {
                val axisSpan = span(axis).coerceAtLeast(1e-9)
                val transverse = model.wires.filter { w ->
                    val len = w.lengthM
                    if (len <= 1e-7) false else {
                        val d = when (axis) { 'X' -> abs(w.dx); 'Y' -> abs(w.dy); else -> abs(w.dz) }
                        d / len < 0.35
                    }
                }
                if (transverse.size < 2) return -1.0
                val coords = transverse.map { w -> when (axis) { 'X' -> w.midX; 'Y' -> w.midY; else -> w.midZ } }.sorted()
                val tol = max(axisSpan * 0.025, model.wavelengthM * 0.002)
                var stations = 0
                var last = Double.NaN
                coords.forEach { c ->
                    if (!last.isFinite() || abs(c - last) > tol) { stations++; last = c }
                }
                val longTransverse = transverse.sumOf { it.lengthM }
                return stations * 1000.0 + longTransverse / model.wavelengthM.coerceAtLeast(1e-9)
            }
            val boom = listOf('X','Y','Z').maxByOrNull(::boomScore) ?: model.mainAxis
            val forward = signedAxis(boom)
            val other = listOf('X','Y','Z').filter { it != boom }
            // Element plane: the transverse axis carrying most physical element extent.
            val elemAxis = other.maxByOrNull { a ->
                model.wires.sumOf { w ->
                    val len = w.lengthM.coerceAtLeast(1e-12)
                    val comp = when (a) { 'X' -> abs(w.dx); 'Y' -> abs(w.dy); else -> abs(w.dz) }
                    len * (comp / len)
                }
            } ?: other.first()
            val t1 = axisVector(elemAxis)
            val t2 = normalize(cross(forward, t1))
            val az = Math.toDegrees(kotlin.math.atan2(forward[1], forward[0])).let { if (it < 0.0) it + 360.0 else it }
            val el = Math.toDegrees(kotlin.math.asin(forward[2].coerceIn(-1.0, 1.0)))
            val dir = "AZ %.1f° EL %.1f°".format(java.util.Locale.US, az, el)
            return FixedMatchAxes(
                forward, t1, t2,
                "P1 YAGI • $dir",
                "P2 YAGI ORTHO • $dir",
                "Match/Yagi: boresight from geometric boom stations; matching network cannot rotate the 2D planes."
            )
        }

        if (explicitLoop && model.isPlanar && model.planeNormalAxis != null) {
            val normal = model.planeNormalAxis!!
            val forward = signedAxis(normal)
            val inPlane = listOf('X','Y','Z').filter { it != normal }
            val p1 = inPlane.maxByOrNull(::span) ?: inPlane.first()
            val p2 = inPlane.first { it != p1 }
            return FixedMatchAxes(
                forward, axisVector(p1), axisVector(p2),
                "P1 BROADSIDE • ${normal}-normal",
                "P2 BROADSIDE • ${normal}-normal",
                "Match/loop: broadside is locked to the normal of the physical wire plane."
            )
        }

        if (explicitVertical) {
            // MMANA ground plane is XY; Z is physical vertical.  A matching wire may be longer
            // laterally than the radiator, so never infer H/E planes from the full bounding box.
            return FixedMatchAxes(
                axisVector('X'), axisVector('Y'), axisVector('Z'),
                "P1 H-PLANE • XY",
                "P2 E-PLANE • XZ",
                "Match/vertical: fixed physical H-plane (XY) and E-plane (XZ); network geometry ignored for orientation."
            )
        }

        if (explicitDipole) {
            val dipoleAxis = longestAxis()
            if (dipoleAxis == 'Z') {
                return FixedMatchAxes(
                    axisVector('X'), axisVector('Y'), axisVector('Z'),
                    "P1 H-PLANE • XY",
                    "P2 E-PLANE • XZ",
                    "Match/vertical dipole: physical H/E planes."
                )
            }
            // Horizontal dipoles in the corpus are normally aligned X or Y.  Use the horizontal
            // broadside normal for angle zero and show any ground-induced elevation inside P2.
            val d = axisVector(dipoleAxis)
            var broadside = normalize(cross(d, axisVector('Z')))
            if (norm(broadside) < 1e-8) broadside = axisVector('X')
            if (dot(peakVector, broadside) < 0.0) broadside = scale(broadside, -1.0)
            return FixedMatchAxes(
                broadside, d, axisVector('Z'),
                "P1 DIPOLE • horizontal",
                "P2 DIPOLE • elevation",
                "Match/dipole: zero angle is physical horizontal broadside; ground tilt remains visible in the elevation cut."
            )
        }

        return null
    }

    /**
     * 1.19.113: build the displayed 2D principal cuts directly from the already-calculated
     * coherent 3D pattern. This guarantees that a legacy MMANA stack cannot show a correct
     * summed 3D surface while the 2D panel accidentally follows a separate/single-array path.
     * Interpolation is performed in linear power, never directly in dB.
     */
    fun calculateFrom3D(model: MaaModel, points3D: List<Pattern3DPoint>): Result {
        require(points3D.isNotEmpty()) { "3D radiation pattern is empty." }

        val thetaVals = points3D.map { it.thetaDeg }.distinct().sorted()
        val phiVals = points3D.map { it.phiDeg }.distinct().sorted()
        require(thetaVals.isNotEmpty() && phiVals.isNotEmpty()) { "3D radiation grid is empty." }
        val thStep = thetaVals.zipWithNext().map { it.second - it.first }.filter { it > 1e-9 }.minOrNull() ?: 5.0
        val phStep = phiVals.zipWithNext().map { it.second - it.first }.filter { it > 1e-9 }.minOrNull() ?: 5.0
        val nTheta = thetaVals.size
        val nPhi = phiVals.size
        val power = DoubleArray(nTheta * nPhi) { 1e-30 }
        val thetaIndex = thetaVals.withIndex().associate { it.value to it.index }
        val phiIndex = phiVals.withIndex().associate { it.value to it.index }
        points3D.forEach { p ->
            val ti = thetaIndex[p.thetaDeg] ?: return@forEach
            val pi = phiIndex[p.phiDeg] ?: return@forEach
            power[pi * nTheta + ti] = Math.pow(10.0, p.db / 10.0).coerceAtLeast(1e-30)
        }

        fun sampleThetaPhi(thetaIn: Double, phiIn: Double): Double {
            val theta = thetaIn.coerceIn(thetaVals.first(), thetaVals.last())
            var phi = phiIn % 360.0
            if (phi < 0.0) phi += 360.0

            val tf = (theta - thetaVals.first()) / thStep
            val t0 = kotlin.math.floor(tf).toInt().coerceIn(0, nTheta - 1)
            val t1 = (t0 + 1).coerceAtMost(nTheta - 1)
            val ft = (tf - t0).coerceIn(0.0, 1.0)

            // Phi rows are periodic. This assumes the usual regular NEC 0..360 grid.
            val pf = (phi - phiVals.first()) / phStep
            val p0raw = kotlin.math.floor(pf).toInt()
            val p0 = ((p0raw % nPhi) + nPhi) % nPhi
            val p1 = (p0 + 1) % nPhi
            val fp = (pf - kotlin.math.floor(pf)).coerceIn(0.0, 1.0)

            fun v(ti: Int, pi: Int) = power[pi * nTheta + ti]
            val a = v(t0, p0) * (1.0 - ft) + v(t1, p0) * ft
            val b = v(t0, p1) * (1.0 - ft) + v(t1, p1) * ft
            return (a * (1.0 - fp) + b * fp).coerceAtLeast(1e-30)
        }

        fun sampleDirection(n: DoubleArray): Double {
            if (model.groundType != 0 && n[2] < -1e-10) return 1e-30
            val theta = Math.toDegrees(kotlin.math.acos(n[2].coerceIn(-1.0, 1.0)))
            var phi = Math.toDegrees(kotlin.math.atan2(n[1], n[0]))
            if (phi < 0.0) phi += 360.0
            return sampleThetaPhi(theta, phi)
        }

        // MMANA-GAL automatic horizontal slice elevation: global maximum in the upper
        // hemisphere, refined from the existing coherent 3D field in linear power.
        val upperPeak = points3D.filter { it.thetaDeg <= 90.0 + 1e-9 }.maxByOrNull { it.db }
            ?: points3D.maxByOrNull { it.db } ?: points3D.first()
        var bestEl = (90.0 - upperPeak.thetaDeg).coerceIn(0.0, 90.0)
        var bestAz = upperPeak.phiDeg
        var bestPower = Math.pow(10.0, upperPeak.db / 10.0)
        val elHalf = max(thStep, 1.0)
        val azHalf = max(phStep, 1.0)
        var el = (bestEl - elHalf).coerceAtLeast(0.0)
        val elEnd = (bestEl + elHalf).coerceAtMost(90.0)
        while (el <= elEnd + 1e-9) {
            var az = bestAz - azHalf
            val azEnd = bestAz + azHalf
            while (az <= azEnd + 1e-9) {
                val theta = 90.0 - el
                val q = sampleThetaPhi(theta, az)
                if (q > bestPower) { bestPower = q; bestEl = el; bestAz = az }
                az += 0.5
            }
            el += 0.1
        }
        bestEl = (kotlin.math.round(bestEl * 10.0) / 10.0).coerceIn(0.0, 90.0)
        val displayEl = if (bestEl > 87.0) 45.0 else bestEl

        val peakTheta = Math.toRadians(upperPeak.thetaDeg)
        val peakPhi = Math.toRadians(upperPeak.phiDeg)
        val peakVector = doubleArrayOf(sin(peakTheta) * cos(peakPhi), sin(peakTheta) * sin(peakPhi), cos(peakTheta))
        val beverageAxes = fixedBeverageAxes(model, peakVector)

        val azRaw = DoubleArray(361)
        var azPeak = 0.0
        val er = Math.toRadians(displayEl)
        val ce = cos(er); val se = sin(er)
        for (idx in azRaw.indices) {
            val a = Math.toRadians(idx - 180.0)
            val horizontal = if (beverageAxes != null) {
                add(scale(beverageAxes.forward, cos(a)), scale(beverageAxes.transverse1, sin(a)))
            } else {
                doubleArrayOf(cos(a), sin(a), 0.0)
            }
            val q = sampleDirection(doubleArrayOf(ce * horizontal[0], ce * horizontal[1], se))
            azRaw[idx] = q
            if (q > azPeak) azPeak = q
        }

        val elRaw = DoubleArray(361)
        var elPeak = 0.0
        for (idx in elRaw.indices) {
            val a = Math.toRadians(idx - 180.0)
            val n = if (beverageAxes != null) {
                add(scale(beverageAxes.forward, cos(a)), scale(beverageAxes.transverse2, sin(a)))
            } else {
                doubleArrayOf(cos(a), 0.0, sin(a))
            }
            val q = sampleDirection(n)
            elRaw[idx] = q
            if (q > elPeak) elPeak = q
        }

        val commonPeak = max(azPeak, elPeak).coerceAtLeast(1e-30)
        val elevationText = "%.1f".format(java.util.Locale.US, displayEl)
        val autoText = "%.1f".format(java.util.Locale.US, bestEl)
        val fallbackText = if (bestEl > 87.0) " (MMANA >87° rule; auto peak $autoText°)" else ""
        val p1Label = beverageAxes?.label1 ?: "AZ XY • EL $elevationText°"
        val p2Label = beverageAxes?.label2 ?: "EL XZ • AZ 0°/180°"
        val cutNote = if (beverageAxes != null)
            "Beverage MMANA-style physical cuts from the coherent 3D NEC field: azimuth at EL $elevationText°$fallbackText with 0° along the long wire; elevation in the long-wire/+Z plane"
        else
            "2D cuts extracted from the same coherent 3D NEC-2 FULL field using MMANA-GAL display rules: azimuth at EL $elevationText°$fallbackText; fixed XZ elevation cut through X axis"
        return Result(
            previewTop = finishPreview(azRaw, commonPeak),
            previewSide = finishPreview(elRaw, commonPeak),
            principalPlane1Label = p1Label,
            principalPlane2Label = p2Label,
            note = "$cutNote; 1° display step; linear-power interpolation."
        )
    }

    /**
     * MMANA/MININEC G=2 special case used by very low Beverage models whose short
     * feed/termination drops actually touch Z=0.  Their currents are solved over PEC, while
     * the far field receives a finite-ground reflection correction.  Re-solving those tiny
     * grounded end wires with NEC finite ground changes the travelling-wave current and can
     * turn the end-fire lobe into a mirrored/split pattern.  A raised Beverage such as
     * beverage180-NEC2.maa does not enter this route and keeps the native OpenNEC RP path.
     */
    private fun useMmanaGroundedBeverageFarField(model: MaaModel): Boolean {
        if (model.groundType != 2 || !isBeverageModel(model)) return false
        val eps = 1e-6
        val groundedDrop = model.wires.any { w ->
            val touchesGround = kotlin.math.abs(w.z1 + model.addHeightM) <= eps ||
                kotlin.math.abs(w.z2 + model.addHeightM) <= eps
            val dz = kotlin.math.abs(w.z2 - w.z1)
            val dh = kotlin.math.hypot(w.x2 - w.x1, w.y2 - w.y1)
            touchesGround && dz > dh * 2.0
        }
        val longHorizontal = model.wires.any { w ->
            val dz = kotlin.math.abs(w.z2 - w.z1)
            val dh = kotlin.math.hypot(w.x2 - w.x1, w.y2 - w.y1)
            dh > 0.25 * model.wavelengthM && dh > dz * 10.0
        }
        return groundedDrop && longHorizontal
    }

    /** Spatial display surface. 1.19.35 prefers the solver-native OpenNEC RP grid. */
    fun calculate3D(
        model: MaaModel,
        solved: OpenNecFull.Result,
        thetaStepDeg: Double = 5.0,
        phiStepDeg: Double = 5.0,
        onProgress: ((doneRows: Int, totalRows: Int) -> Unit)? = null
    ): List<Pattern3DPoint> {
        require(solved.segments.isNotEmpty()) { "NEC-2 FULL returned no currents for the 3D radiation pattern." }
        require(model.frequencyMHz > 0.0) { "Invalid frequency." }
        val thStep = thetaStepDeg.coerceIn(0.5, 30.0)
        val phStep = phiStepDeg.coerceIn(0.5, 30.0)
        // Ground-backed antennas (including Beverage) have a physical far field only above
        // the ground plane.  Do not manufacture theta=90..180 samples and later collapse them
        // to -80 dB: the surface mesh would stitch the horizon to the origin and look mirrored
        // or split into radial curtains.  Free-space models still use the full sphere.
        val thetaMaxDeg = if (model.groundType != 0) 90.0 else 180.0
        val thetas = mutableListOf<Double>().apply {
            var v = 0.0
            while (v < thetaMaxDeg - 1e-9) { add(v); v += thStep }
            if (lastOrNull()?.let { kotlin.math.abs(it - thetaMaxDeg) > 1e-9 } != false) add(thetaMaxDeg)
        }
        val phis = mutableListOf<Double>().apply {
            var v = 0.0
            while (v < 360.0 - 1e-9) { add(v); v += phStep }
        }

        val mmanaGroundedBeverage = useMmanaGroundedBeverageFarField(model)
        val sampler = if (mmanaGroundedBeverage) null else nativeSamplerOrNull(solved.nativePattern)
        data class Raw3D(val theta: Double, val phi: Double, val power: Double)
        val raw = ArrayList<Raw3D>(thetas.size * phis.size)
        var peak = 0.0

        if (sampler != null) {
            phis.forEachIndexed { rowIndex, phiDeg ->
                val phi = Math.toRadians(phiDeg)
                val cp = cos(phi)
                val sp = sin(phi)
                for (thetaDeg in thetas) {
                    val theta = Math.toRadians(thetaDeg)
                    val st = sin(theta)
                    val n = doubleArrayOf(st * cp, st * sp, cos(theta))
                    val power = sampler.powerForDirection(n, model.groundType != 0)
                    raw += Raw3D(thetaDeg, phiDeg, power)
                    if (power > peak) peak = power
                }
                onProgress?.invoke(rowIndex + 1, phis.size)
            }
        } else {
            // Compatibility fallback for an older native library/payload.
            val k = 2.0 * PI / model.wavelengthM
            phis.forEachIndexed { rowIndex, phiDeg ->
                val phi = Math.toRadians(phiDeg)
                val cp = cos(phi)
                val sp = sin(phi)
                for (thetaDeg in thetas) {
                    val theta = Math.toRadians(thetaDeg)
                    val st = sin(theta)
                    val n = doubleArrayOf(st * cp, st * sp, cos(theta))
                    val power = if (mmanaGroundedBeverage) {
                        fieldPowerMmanaRealGround(solved.segments, k, n, 13.0, 0.005)
                    } else {
                        fieldPower(solved.segments, k, n, model.groundType == 1 || model.groundType == 2)
                    }
                    raw += Raw3D(thetaDeg, phiDeg, power)
                    if (power > peak) peak = power
                }
                onProgress?.invoke(rowIndex + 1, phis.size)
            }
        }

        val norm = peak.coerceAtLeast(1e-30)
        return raw.map { q ->
            val db = (10.0 * log10((q.power / norm).coerceAtLeast(1e-8))).coerceAtLeast(-80.0)
            Pattern3DPoint(q.theta, q.phi, db)
        }
    }


    /**
     * A JNI/native RP payload is used only when it contains a meaningful set of finite gain
     * samples.  This prevents a partially initialized OpenNEC rpat buffer from collapsing the
     * whole 3D surface to the -80 dB floor.  The exact NEC A/B/C renderer remains the fail-safe.
     */
    private fun nativeSamplerOrNull(points: List<OpenNecFull.NativePatternPoint>): NativePatternSampler? {
        if (points.isEmpty()) return null
        val usable = points.filter { p ->
            p.thetaDeg.isFinite() && p.phiDeg.isFinite() && p.gainDb.isFinite() && p.gainDb > -290.0
        }
        return if (usable.size >= 100) NativePatternSampler(usable) else null
    }

    /**
     * Regular 2.5° native RP sampler. OpenNEC reports theta=0..180 and phi=0..360.
     * Interpolation is done in LINEAR power, never in dB, so cuts at 1° stay smooth without
     * inventing a second phase-summation path. Missing lower-hemisphere ground points are zero.
     */
    private class NativePatternSampler(points: List<OpenNecFull.NativePatternPoint>) {
        private val step = 2.5
        // Native OpenNEC now returns 0..90 theta for ground models and 0..180 for free space.
        // Derive the theta dimension from the payload instead of assuming a full sphere.
        private val maxThetaDeg = (points.maxOfOrNull { it.thetaDeg } ?: 180.0).coerceIn(0.0, 180.0)
        private val nTheta = (kotlin.math.round(maxThetaDeg / step).toInt() + 1).coerceAtLeast(2)
        private val nPhi = 145
        private val power = DoubleArray(nTheta * nPhi) { Double.NaN }

        init {
            points.forEach { p ->
                val ti = kotlin.math.round(p.thetaDeg / step).toInt()
                val pi = kotlin.math.round(p.phiDeg / step).toInt()
                if (ti in 0 until nTheta && pi in 0 until nPhi) {
                    val db = p.gainDb.coerceIn(-300.0, 300.0)
                    power[pi * nTheta + ti] = Math.pow(10.0, db / 10.0)
                }
            }
        }

        fun powerForDirection(n: DoubleArray, hasGround: Boolean): Double {
            if (hasGround && n[2] < -1e-10) return 0.0
            val nz = n[2].coerceIn(-1.0, 1.0)
            val theta = Math.toDegrees(kotlin.math.acos(nz)).coerceIn(0.0, maxThetaDeg)
            var phi = Math.toDegrees(kotlin.math.atan2(n[1], n[0]))
            if (phi < 0.0) phi += 360.0
            if (phi >= 360.0) phi -= 360.0
            return interpolate(theta, phi)
        }

        private fun value(ti: Int, pi: Int): Double {
            val v = power[pi.coerceIn(0, nPhi - 1) * nTheta + ti.coerceIn(0, nTheta - 1)]
            return if (v.isFinite()) v else 0.0
        }

        private fun interpolate(theta: Double, phi: Double): Double {
            val tf = theta / step
            val pf = phi / step
            val t0 = kotlin.math.floor(tf).toInt().coerceIn(0, nTheta - 1)
            val t1 = (t0 + 1).coerceAtMost(nTheta - 1)
            val p0 = kotlin.math.floor(pf).toInt().coerceIn(0, nPhi - 2)
            val p1 = (p0 + 1).coerceAtMost(nPhi - 1)
            val ft = (tf - t0).coerceIn(0.0, 1.0)
            val fp = (pf - p0).coerceIn(0.0, 1.0)
            val a = value(t0, p0) * (1.0 - ft) + value(t1, p0) * ft
            val b = value(t0, p1) * (1.0 - ft) + value(t1, p1) * ft
            return (a * (1.0 - fp) + b * fp).coerceAtLeast(0.0)
        }
    }

    private fun farFieldNativeRaw(
        sampler: NativePatternSampler,
        hasGround: Boolean,
        axisA: DoubleArray,
        axisB: DoubleArray
    ): RawCut {
        val raw = DoubleArray(361)
        var peak = 0.0
        for (idx in raw.indices) {
            val angle = Math.toRadians(idx - 180.0)
            val n = add(scale(axisA, cos(angle)), scale(axisB, sin(angle)))
            val p = sampler.powerForDirection(n, hasGround)
            raw[idx] = p
            if (p > peak) peak = p
        }
        return RawCut(raw, peak)
    }

    private fun farFieldRaw(
        segments: List<OpenNecFull.SegmentCurrent>,
        k: Double,
        axisA: DoubleArray,
        axisB: DoubleArray,
        usePerfectGroundImage: Boolean
    ): RawCut {
        val raw = DoubleArray(361)
        var peak = 0.0
        for (idx in raw.indices) {
            val angle = Math.toRadians(idx - 180.0)
            val n = add(scale(axisA, cos(angle)), scale(axisB, sin(angle)))
            val power = fieldPower(segments, k, n, usePerfectGroundImage)
            raw[idx] = power
            if (power > peak) peak = power
        }
        return RawCut(raw, peak)
    }

    /**
     * Far-field power in direction n from the solved NEC solution.
     *
     * Since 1.19.30 the preferred path reproduces NEC's segment radiation integral from the
     * solver's A/B/C sinusoidal current-expansion coefficients. A single complex centre current
     * multiplied by a finite-segment sinc is only exact for a uniform-current segment and can
     * noticeably corrupt phase-sensitive end-fire arrays (Yagi/LPDA) even when input Z is right.
     *
     * OpenNEC uses, for each segment (geometry lengths are in wavelengths internally):
     *   omega = -(n dot u), el = pi * halfLengthLambda
     *   rr = a*A.re + b*B.im + c*C.re
     *   ri = a*A.im - b*B.re + c*C.im
     * followed by exp(+j 2*pi n dot r/lambda).
     *
     * If an old native payload without A/B/C is ever parsed, all segments fall back together to
     * the previous centre-current approximation; exact and approximate amplitudes are never mixed.
     *
     * For MMANA G=1/G=2 the FULL deck uses ideal PEC (`GN 1`). The image current is
     * J_image=(-Jx,-Jy,+Jz) at z -> -z. Radiation below the PEC plane is blocked.
     */
    private fun fieldPower(
        segments: List<OpenNecFull.SegmentCurrent>,
        k: Double,
        n: DoubleArray,
        usePerfectGroundImage: Boolean
    ): Double {
        if (usePerfectGroundImage && n[2] < -1e-10) return 0.0

        var ex = C(0.0, 0.0)
        var ey = C(0.0, 0.0)
        var ez = C(0.0, 0.0)
        val useNecBasis = segments.all { it.hasNecCurrentBasis }

        fun sinc(x: Double): Double = if (abs(x) < 1.0e-7) 1.0 - x * x / 6.0 else sin(x) / x

        fun necBasisAmplitude(s: OpenNecFull.SegmentCurrent, ndotu: Double): C {
            val omega = -ndotu
            // OpenNEC geometry.half_len is half segment length in wavelengths.
            // lambda = 2*pi/k => pi*halfLen/lambda = k*length/4.
            val el = 0.25 * k * s.lengthM
            val sill = omega * el
            val top = el + sill
            val bot = el - sill
            val a = if (abs(omega) >= 1.0e-7) {
                2.0 * sin(sill) / omega
            } else {
                (2.0 - omega * omega * el * el / 3.0) * el
            }
            val too = sinc(top)
            val boo = sinc(bot)
            val b = el * (boo - too)
            val c = el * (boo + too)
            return C(
                a * s.basisARe + b * s.basisBIm + c * s.basisCRe,
                a * s.basisAIm - b * s.basisBRe + c * s.basisCIm
            )
        }

        fun accumulate(
            s: OpenNecFull.SegmentCurrent,
            zM: Double,
            ux: Double,
            uy: Double,
            uz: Double,
            currentSign: Double
        ) {
            val ndotu = n[0] * ux + n[1] * uy + n[2] * uz
            // n x (u x n): only the transverse part radiates.
            val vx = ux - n[0] * ndotu
            val vy = uy - n[1] * ndotu
            val vz = uz - n[2] * ndotu
            val phase = k * (n[0] * s.xM + n[1] * s.yM + n[2] * zM)
            val phasor = C(cos(phase), sin(phase))

            val segmentAmp = if (useNecBasis) {
                necBasisAmplitude(s, ndotu) * currentSign
            } else {
                // Compatibility only: 1.19.29 and earlier payloads had one centre current/segment.
                val current = C(s.currentReA * currentSign, s.currentImA * currentSign)
                val q = 0.5 * k * s.lengthM * ndotu
                val finiteSegment = if (abs(q) < 1e-8) 1.0 else sin(q) / q
                current * (s.lengthM * finiteSegment)
            }
            val amp = segmentAmp * phasor
            ex = ex + amp * vx
            ey = ey + amp * vy
            ez = ez + amp * vz
        }

        for (s in segments) {
            accumulate(s, s.zM, s.ux, s.uy, s.uz, +1.0)
            if (usePerfectGroundImage) {
                // Mirror direction + reverse scalar current => Jimg=(-Jx,-Jy,+Jz).
                accumulate(s, -s.zM, s.ux, s.uy, -s.uz, -1.0)
            }
        }
        return ex.mag2() + ey.mag2() + ez.mag2()
    }

    /**
     * MMANA-GAL style real-ground far-field correction for grounded low Beverage models.
     * The segment currents come from the PEC current solution.  Only the reflected far-field
     * term is changed using the complex Fresnel coefficients of average ground.  This follows
     * MMANA's G=2 principle (PEC current solution + real-ground far field) without re-solving
     * the antenna on finite NEC ground.
     */
    private fun fieldPowerMmanaRealGround(
        segments: List<OpenNecFull.SegmentCurrent>,
        k: Double,
        n: DoubleArray,
        epsR: Double,
        sigma: Double
    ): Double {
        if (n[2] < -1e-10) return 0.0
        val rho = kotlin.math.hypot(n[0], n[1])
        if (rho < 1e-12) return fieldPower(segments, k, n, true)

        var dx = C(0.0, 0.0); var dy = C(0.0, 0.0); var dz = C(0.0, 0.0)
        var ix = C(0.0, 0.0); var iy = C(0.0, 0.0); var iz = C(0.0, 0.0)
        val useNecBasis = segments.all { it.hasNecCurrentBasis }
        fun sinc(x: Double): Double = if (kotlin.math.abs(x) < 1e-7) 1.0 - x*x/6.0 else kotlin.math.sin(x)/x
        fun basis(s: OpenNecFull.SegmentCurrent, ndotu: Double): C {
            if (!useNecBasis) {
                val q=0.5*k*s.lengthM*ndotu
                val fs=if(kotlin.math.abs(q)<1e-8) 1.0 else kotlin.math.sin(q)/q
                return C(s.currentReA,s.currentImA)*(s.lengthM*fs)
            }
            val omega=-ndotu; val el=0.25*k*s.lengthM; val sill=omega*el
            val top=el+sill; val bot=el-sill
            val aa=if(kotlin.math.abs(omega)>=1e-7) 2.0*kotlin.math.sin(sill)/omega else (2.0-omega*omega*el*el/3.0)*el
            val too=sinc(top); val boo=sinc(bot); val bb=el*(boo-too); val cc=el*(boo+too)
            return C(aa*s.basisARe + bb*s.basisBIm + cc*s.basisCRe,
                     aa*s.basisAIm - bb*s.basisBRe + cc*s.basisCIm)
        }
        fun addOne(s: OpenNecFull.SegmentCurrent, z: Double, ux:Double, uy:Double, uz:Double, image:Boolean) {
            val ndotu=n[0]*ux+n[1]*uy+n[2]*uz
            val vx=ux-n[0]*ndotu; val vy=uy-n[1]*ndotu; val vz=uz-n[2]*ndotu
            val ph=k*(n[0]*s.xM+n[1]*s.yM+n[2]*z)
            val a=basis(s,ndotu)*C(kotlin.math.cos(ph),kotlin.math.sin(ph))
            if(image){ ix=ix+a*vx; iy=iy+a*vy; iz=iz+a*vz }
            else { dx=dx+a*vx; dy=dy+a*vy; dz=dz+a*vz }
        }
        for(s in segments){
            addOne(s,s.zM,s.ux,s.uy,s.uz,false)
            // geometrical mirror of the solved current; Fresnel dyadic below supplies reflection sign/phase
            addOne(s,-s.zM,s.ux,s.uy,-s.uz,true)
        }
        val ePhi=doubleArrayOf(-n[1]/rho,n[0]/rho,0.0)
        val eTheta=doubleArrayOf(n[2]*n[0]/rho,n[2]*n[1]/rho,-rho)
        fun dot(x:C,y:C,z:C,e:DoubleArray)=x*e[0]+y*e[1]+z*e[2]
        val iPhi=dot(ix,iy,iz,ePhi); val iTheta=dot(ix,iy,iz,eTheta)
        val freqHz=(k*299792458.0/(2.0*PI)).coerceAtLeast(1.0)
        val eps0=8.8541878128e-12
        val eps=C(epsR,-sigma/(2.0*PI*freqHz*eps0))
        val cosI=n[2].coerceIn(0.0,1.0); val sin2=1.0-cosI*cosI
        val root=csqrt(eps-C(sin2,0.0))
        val gs=(C(cosI,0.0)-root)/(C(cosI,0.0)+root)
        val gp=(eps*cosI-root)/(eps*cosI+root)
        val rx=(iPhi*gs)*ePhi[0]+(iTheta*gp)*eTheta[0]
        val ry=(iPhi*gs)*ePhi[1]+(iTheta*gp)*eTheta[1]
        val rz=(iPhi*gs)*ePhi[2]+(iTheta*gp)*eTheta[2]
        val tx=dx+rx; val ty=dy+ry; val tz=dz+rz
        return tx.mag2()+ty.mag2()+tz.mag2()
    }

    private fun finishPreview(raw: DoubleArray, peakIn: Double): MaaPatternPreview {
        val peak = peakIn.coerceAtLeast(1e-30)
        val points = raw.indices.map { idx ->
            val db = (10.0 * log10((raw[idx] / peak).coerceAtLeast(1e-6))).coerceAtLeast(-60.0)
            MaaPatternPoint(idx - 180.0, db)
        }
        val peakIdx = raw.indices.maxByOrNull { raw[it] } ?: 180
        val oppositeIdx = (peakIdx + 180).let { if (it > 360) it - 360 else it }
        val fb = points[peakIdx].db - points[oppositeIdx].db

        fun crossing(start: Int, step: Int): Double? {
            var i = start + step
            while (i in 0..360) {
                if (points[i].db <= -3.0) {
                    val j = i - step
                    val a = points[j]
                    val b = points[i]
                    val den = b.db - a.db
                    if (abs(den) < 1e-12) return b.angleDeg
                    val t = (-3.0 - a.db) / den
                    return a.angleDeg + (b.angleDeg - a.angleDeg) * t
                }
                i += step
            }
            return null
        }

        val left = crossing(peakIdx, -1)
        val right = crossing(peakIdx, 1)
        val hpbw = if (left != null && right != null && right >= left) right - left else null
        val peakAngle = points[peakIdx].angleDeg
        val exclusion = ((hpbw ?: 30.0) * 0.75).coerceAtLeast(10.0)
        fun angularDistance(a: Double, b: Double): Double {
            var d = abs(a - b) % 360.0
            if (d > 180.0) d = 360.0 - d
            return d
        }
        var side = -60.0
        for (i in 1 until points.lastIndex) {
            if (angularDistance(points[i].angleDeg, peakAngle) >= exclusion &&
                points[i].db >= points[i - 1].db && points[i].db >= points[i + 1].db
            ) {
                side = max(side, points[i].db)
            }
        }
        return MaaPatternPreview(points, hpbw, fb, side)
    }

    private fun principalCuts(
        model: MaaModel,
        sampler: NativePatternSampler?,
        segments: List<OpenNecFull.SegmentCurrent>,
        k: Double
    ): Pair<PlaneCut, PlaneCut> {
        val omni = model.omniSymmetryAxis
        if (omni != null) {
            val transverse = listOf('X', 'Y', 'Z').filter { it != omni }
            fun span(axis: Char): Double = when (axis) {
                'X' -> model.spanX
                'Y' -> model.spanY
                else -> model.spanZ
            }
            val t1 = transverse.maxByOrNull(::span) ?: transverse.first()
            val t2 = transverse.first { it != t1 }
            return PlaneCut(axisVector(t1), axisVector(t2), "AZ $t1-$t2") to
                PlaneCut(axisVector(t1), axisVector(omni), "EL $t1-$omni")
        }

        // 1.19.116: Match-folder models use the same physical plane policy as 2D-from-3D.
        // This prevents Gamma/Omega/T/D matching wires from masquerading as the radiator axis.
        val matchPeak = findMainLobeDirection(model, sampler, segments, k)
        (fixedBeverageAxes(model, matchPeak) ?: fixedMatchAxes(model, matchPeak))?.let { m ->
            return PlaneCut(m.forward, m.transverse1, m.label1) to
                PlaneCut(m.forward, m.transverse2, m.label2)
        }

        // For every non-omnidirectional topology, derive the two displayed principal cuts from
        // the ACTUAL full-field main-lobe direction. This fixes rotated/crossed/phased arrays
        // whose lobe is not contained in one of the global XY/XZ/YZ planes.
        val forward = findMainLobeDirection(model, sampler, segments, k)

        // Pick the geometrically most meaningful transverse reference axis. The projection makes
        // it exactly perpendicular to the full-pattern main-lobe vector.
        val refs = listOf('X', 'Y', 'Z').map { axis ->
            val sp = when (axis) {
                'X' -> model.spanX
                'Y' -> model.spanY
                else -> model.spanZ
            }
            axisVector(axis) to sp
        }
        val ref = refs.maxByOrNull { (v, sp) ->
            val proj2 = (1.0 - dot(v, forward) * dot(v, forward)).coerceAtLeast(0.0)
            sp * sp * proj2
        }?.first ?: axisVector('Z')
        var transverse1 = subtract(ref, scale(forward, dot(ref, forward)))
        if (norm(transverse1) < 1e-8) {
            val fallback = if (abs(forward[2]) < 0.9) axisVector('Z') else axisVector('Y')
            transverse1 = subtract(fallback, scale(forward, dot(fallback, forward)))
        }
        transverse1 = normalize(transverse1)
        val transverse2 = normalize(cross(forward, transverse1))

        val az = Math.toDegrees(kotlin.math.atan2(forward[1], forward[0])).let { if (it < 0.0) it + 360.0 else it }
        val el = Math.toDegrees(kotlin.math.asin(forward[2].coerceIn(-1.0, 1.0)))
        val dir = "AZ %.1f° EL %.1f°".format(java.util.Locale.US, az, el)
        return PlaneCut(forward, transverse1, "P1 MAIN • $dir") to
            PlaneCut(forward, transverse2, "P2 ORTHO • $dir")
    }

    private fun findMainLobeDirection(
        model: MaaModel,
        sampler: NativePatternSampler?,
        segments: List<OpenNecFull.SegmentCurrent>,
        k: Double
    ): DoubleArray {
        if (sampler != null) {
            var best = axisVector(model.mainAxis)
            var bestPower = -1.0
            var theta = 0.0
            while (theta <= 180.0 + 1e-9) {
                val th = Math.toRadians(theta)
                var phi = 0.0
                while (phi < 360.0 - 1e-9) {
                    val ph = Math.toRadians(phi)
                    val n = doubleArrayOf(sin(th) * cos(ph), sin(th) * sin(ph), cos(th))
                    val p = sampler.powerForDirection(n, model.groundType != 0)
                    if (p > bestPower) { bestPower = p; best = n }
                    phi += 2.5
                }
                theta += 2.5
            }
            return normalize(best)
        }

        // Compatibility fallback for old native payloads: a 10° full-sphere search is enough to
        // orient the 1° display cuts; the cuts themselves still use the exact coherent field sum.
        var best = axisVector(model.mainAxis)
        var bestPower = -1.0
        var theta = 0.0
        while (theta <= 180.0 + 1e-9) {
            val th = Math.toRadians(theta)
            var phi = 0.0
            while (phi < 360.0 - 1e-9) {
                val ph = Math.toRadians(phi)
                val n = doubleArrayOf(sin(th) * cos(ph), sin(th) * sin(ph), cos(th))
                val p = fieldPower(segments, k, n, model.groundType == 1 || model.groundType == 2)
                if (p > bestPower) { bestPower = p; best = n }
                phi += 10.0
            }
            theta += 10.0
        }
        return normalize(best)
    }

    private fun axisVector(axis: Char): DoubleArray = when (axis) {
        'X' -> doubleArrayOf(1.0, 0.0, 0.0)
        'Y' -> doubleArrayOf(0.0, 1.0, 0.0)
        else -> doubleArrayOf(0.0, 0.0, 1.0)
    }

    private fun dot(a: DoubleArray, b: DoubleArray) = a[0]*b[0] + a[1]*b[1] + a[2]*b[2]
    private fun norm(a: DoubleArray) = sqrt(dot(a, a))
    private fun normalize(a: DoubleArray): DoubleArray {
        val n = norm(a).coerceAtLeast(1e-30)
        return doubleArrayOf(a[0]/n, a[1]/n, a[2]/n)
    }
    private fun scale(a: DoubleArray, s: Double) = doubleArrayOf(a[0]*s, a[1]*s, a[2]*s)
    private fun subtract(a: DoubleArray, b: DoubleArray) = doubleArrayOf(a[0]-b[0], a[1]-b[1], a[2]-b[2])
    private fun cross(a: DoubleArray, b: DoubleArray) = doubleArrayOf(
        a[1]*b[2] - a[2]*b[1],
        a[2]*b[0] - a[0]*b[2],
        a[0]*b[1] - a[1]*b[0]
    )
    private fun add(a: DoubleArray, b: DoubleArray) =
        doubleArrayOf(a[0] + b[0], a[1] + b[1], a[2] + b[2])
}
