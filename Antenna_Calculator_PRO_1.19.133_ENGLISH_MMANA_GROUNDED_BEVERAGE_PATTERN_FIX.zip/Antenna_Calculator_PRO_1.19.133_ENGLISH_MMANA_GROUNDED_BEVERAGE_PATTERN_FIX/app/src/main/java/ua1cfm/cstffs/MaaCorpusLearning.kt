package ua1cfm.cstffs

import kotlin.math.ln

/**
 * 1.19.127 corpus-learning layer for MMANA models.
 *
 * Two corpora are used deliberately for different jobs:
 *  - the curated 722-model built-in library keeps its original folder/category labels;
 *  - the 1713-model external corpus is parsed by the current MaaParser and contributes
 *    geometry-derived antenna-kind / analysis-profile labels.
 *
 * This is a semantic interpretation layer only.  It never replaces NEC-2 FULL and never
 * manufactures impedance, current or radiation-pattern data.
 */
data class MaaCorpusSeed(
    val path: String,
    val title: String,
    val frequencyMHz: Double?,
    val category: String
)

data class MaaCorpusExperienceSeed(
    val path: String,
    val title: String,
    val frequencyMHz: Double?,
    val antennaKind: String,
    val analysisProfile: String
)

data class MaaCorpusProfile(
    val category: String,
    val confidencePercent: Int,
    val learnedKind: String,
    val learnedKindConfidencePercent: Int,
    val learnedAnalysisProfile: String,
    val experienceCorpusSize: Int,
    val role: String,
    val feedVariant: String,
    val shortening: String,
    val ground: String,
    val evidence: String
)

class MaaCorpusLearner(
    seeds: List<MaaCorpusSeed>,
    experienceSeeds: List<MaaCorpusExperienceSeed> = emptyList()
) {
    private val stopWords = setOf(
        "mhz", "antenna", "ant", "the", "with", "for", "and", "maa", "model", "wire",
        "hf", "vhf", "m", "cm", "mm", "of", "in", "to", "by", "from", "id"
    )

    private val normalizedSeeds = seeds.toList()
    private val normalizedExperienceSeeds = experienceSeeds.toList()
    private val categories = normalizedSeeds.map { it.category }.distinct().sorted()
    private val byExactPath = normalizedSeeds.associateBy { normalizePath(it.path) }
    private val byExperienceExactPath = normalizedExperienceSeeds.associateBy { normalizePath(it.path) }
    private val tokenCategoryCount: Map<String, Map<String, Int>>
    private val tokenKindCount: Map<String, Map<String, Int>>
    private val tokenProfileCount: Map<String, Map<String, Int>>

    init {
        tokenCategoryCount = buildTokenLabelTable(normalizedSeeds) { it.category }
        tokenKindCount = buildTokenLabelTable(normalizedExperienceSeeds) { it.antennaKind }
        tokenProfileCount = buildTokenLabelTable(normalizedExperienceSeeds) { it.analysisProfile }
    }

    fun profile(model: MaaModel, sourcePath: String?): MaaCorpusProfile {
        val path = sourcePath.orEmpty()
        val exact = byExactPath[normalizePath(path)]
        val categoryPrediction = if (exact != null) exact.category to 100 else predictCategory(model, path)

        val exactExperience = findExperienceExact(path, model.fileNameHint)
        val learnedKindPrediction = if (exactExperience != null) {
            exactExperience.antennaKind to 100
        } else {
            predictLabel(
                text = "$path ${model.fileNameHint.orEmpty()} ${model.title}",
                table = tokenKindCount,
                fallback = model.antennaKind
            )
        }
        val learnedProfilePrediction = if (exactExperience != null) {
            exactExperience.analysisProfile to 100
        } else {
            predictLabel(
                text = "$path ${model.fileNameHint.orEmpty()} ${model.title}",
                table = tokenProfileCount,
                fallback = model.analysisProfile
            )
        }

        val semantic = (path + " " + model.fileNameHint.orEmpty() + " " + model.title).lowercase()
        val category = categoryPrediction.first
        val stackInfo = inferStackInfo(category, semantic)
        val role = stackInfo ?: inferRole(category, semantic)
        val feed = if (stackInfo != null && model.sources.size <= 1) {
            "single MMANA source for stacked system"
        } else inferFeed(semantic, model)
        val shortening = inferShortening(category, semantic, model)
        val ground = when (model.groundType) {
            1 -> "perfect ground"
            2 -> "real ground"
            else -> "free space"
        }

        val evidenceParts = mutableListOf<String>()
        if (exact != null) evidenceParts += "curated 722 archive folder"
        if (exactExperience != null) evidenceParts += "exact 1713-corpus model"
        else if (normalizedExperienceSeeds.isNotEmpty()) evidenceParts += "1713-corpus name/title vocabulary"
        if (path.isNotBlank()) evidenceParts += "path/name"
        if (model.title.isNotBlank()) evidenceParts += "MAA title"
        evidenceParts += "geometry"
        if (model.sources.isNotEmpty() || model.sourceWireIndex != null) evidenceParts += "source"
        if (model.loads.isNotEmpty()) evidenceParts += "${model.loads.size} load(s)"

        return MaaCorpusProfile(
            category = category,
            confidencePercent = categoryPrediction.second,
            learnedKind = learnedKindPrediction.first,
            learnedKindConfidencePercent = learnedKindPrediction.second,
            learnedAnalysisProfile = learnedProfilePrediction.first,
            experienceCorpusSize = normalizedExperienceSeeds.size,
            role = role,
            feedVariant = feed,
            shortening = shortening,
            ground = ground,
            evidence = evidenceParts.distinct().joinToString(" + ")
        )
    }

    private fun findExperienceExact(path: String, fileNameHint: String?): MaaCorpusExperienceSeed? {
        val normPath = normalizePath(path)
        byExperienceExactPath[normPath]?.let { return it }

        // The downloaded 1713 corpus uses a stable __idNNNN suffix.  Android SAF may give only
        // a filename instead of the original MAA_files/ path, so also compare the basename.
        val candidateName = normalizePath(fileNameHint.orEmpty().ifBlank { path }).substringAfterLast('/')
        if (candidateName.isBlank()) return null

        // CQHAM download filenames carry a stable __idNNNN suffix.  Match it before the full
        // basename because some old ZIP names contain OEM characters that can be rendered
        // differently by Android/Windows while still referring to the same archive item.
        val corpusId = Regex("__id(\\d+)", RegexOption.IGNORE_CASE)
            .find(candidateName)?.groupValues?.getOrNull(1)
        if (corpusId != null) {
            normalizedExperienceSeeds.firstOrNull { seed ->
                Regex("__id(\\d+)", RegexOption.IGNORE_CASE)
                    .find(normalizePath(seed.path).substringAfterLast('/'))
                    ?.groupValues?.getOrNull(1) == corpusId
            }?.let { return it }
        }
        return normalizedExperienceSeeds.firstOrNull {
            normalizePath(it.path).substringAfterLast('/') == candidateName
        }
    }

    private fun predictCategory(model: MaaModel, path: String): Pair<String, Int> {
        if (categories.isEmpty()) return "Unclassified" to 0
        val score = categories.associateWith { 0.0 }.toMutableMap()
        val inputTokens = tokens("$path ${model.fileNameHint.orEmpty()} ${model.title}")

        for (token in inputTokens) {
            val counts = tokenCategoryCount[token] ?: continue
            val total = counts.values.sum().coerceAtLeast(1)
            for ((category, count) in counts) {
                val purity = count.toDouble() / total.toDouble()
                score[category] = (score[category] ?: 0.0) + ln(1.0 + count) * (0.35 + 1.65 * purity)
            }
        }

        // Geometry-aware priors are deliberately weak; NEC geometry remains authoritative.
        val kind = model.antennaKind.lowercase()
        fun boost(category: String, amount: Double) {
            if (category in score) score[category] = (score[category] ?: 0.0) + amount
        }
        when {
            "feeder" in kind || "balun" in kind || "transformer" in kind -> {
                boost("Feeders", 3.0); boost("Radiation of feeder", 2.0); boost("Match", 1.0)
            }
            "yagi" in kind || "parasitic" in kind || "lpda" in kind -> {
                boost("HF beams", 1.5); boost("VHF beams", 1.5)
            }
            "phased" in kind -> boost("Phased", 2.5)
            "stack" in kind -> boost("Stacks", 2.5)
            "aperiodic" in kind || "beverage" in kind || "rhomb" in kind -> boost("Aperiodic", 2.0)
        }
        if (model.loads.isNotEmpty()) {
            boost("Short", 0.8)
            boost("Match", 0.8)
            boost("HF multibands", 0.4)
        }

        val ordered = score.entries.sortedByDescending { it.value }
        val best = ordered.firstOrNull() ?: return "Unclassified" to 0
        val second = ordered.getOrNull(1)?.value ?: 0.0
        if (best.value <= 0.0) return "Unclassified" to 25
        val margin = ((best.value - second) / best.value).coerceIn(0.0, 1.0)
        val evidenceStrength = (best.value / 8.0).coerceIn(0.0, 1.0)
        val confidence = (50.0 + 30.0 * margin + 15.0 * evidenceStrength).toInt().coerceIn(50, 95)
        return best.key to confidence
    }

    private fun predictLabel(
        text: String,
        table: Map<String, Map<String, Int>>,
        fallback: String
    ): Pair<String, Int> {
        if (table.isEmpty()) return fallback to 0
        val score = linkedMapOf<String, Double>()
        var matchedTokens = 0
        for (token in tokens(text)) {
            val counts = table[token] ?: continue
            matchedTokens++
            val total = counts.values.sum().coerceAtLeast(1)
            for ((label, count) in counts) {
                val purity = count.toDouble() / total.toDouble()
                score[label] = (score[label] ?: 0.0) + ln(1.0 + count) * (0.30 + 1.70 * purity)
            }
        }
        val ordered = score.entries.sortedByDescending { it.value }
        val best = ordered.firstOrNull() ?: return fallback to 35
        val second = ordered.getOrNull(1)?.value ?: 0.0
        val margin = if (best.value > 0.0) ((best.value - second) / best.value).coerceIn(0.0, 1.0) else 0.0
        val evidence = (matchedTokens / 5.0).coerceIn(0.0, 1.0)
        val confidence = (48.0 + 32.0 * margin + 16.0 * evidence).toInt().coerceIn(48, 94)
        return best.key to confidence
    }

    private fun <T> buildTokenLabelTable(items: List<T>, labelOf: (T) -> String): Map<String, Map<String, Int>> {
        val tmp = linkedMapOf<String, MutableMap<String, Int>>()
        for (item in items) {
            val text = when (item) {
                is MaaCorpusSeed -> "${item.path} ${item.title}"
                is MaaCorpusExperienceSeed -> "${item.path} ${item.title}"
                else -> item.toString()
            }
            val label = labelOf(item)
            for (token in tokens(text)) {
                val perLabel = tmp.getOrPut(token) { linkedMapOf() }
                perLabel[label] = (perLabel[label] ?: 0) + 1
            }
        }
        return tmp.mapValues { it.value.toMap() }
    }

    private fun inferStackInfo(category: String, s: String): String? {
        if (!category.equals("Stacks", true) && "stack" !in s) return null
        val m = Regex("""\b(\d+)\s*[x×х]\s*(\d+)\s*el(?:e)?""", RegexOption.IGNORE_CASE).find(s)
            ?: return null
        val stackCount = m.groupValues[1].toIntOrNull() ?: return null
        val elements = m.groupValues[2].toIntOrNull() ?: return null
        if (stackCount < 2 || elements < 2) return null
        return "$stackCount × $elements-element Yagi stack (${stackCount * elements} radiating elements total)"
    }

    private fun inferRole(category: String, s: String): String = when {
        category.equals("Feeders", true) -> "feeder / transmission-line model"
        category.equals("Radiation of feeder", true) -> "feeder-radiation model"
        category.equals("Match", true) -> "matching / feed-network variant"
        category.equals("Receive", true) -> "receiving-antenna variant"
        category.equals("Short", true) -> "electrically-short antenna variant"
        category.equals("Phased", true) -> "phased-array variant"
        category.equals("Stacks", true) -> "stacked-array variant"
        "tuner" in s || "match" in s -> "antenna with matching network"
        else -> "radiating antenna model"
    }

    private fun inferFeed(s: String, model: MaaModel): String = when {
        "gamma" in s -> "gamma match"
        "omega" in s -> "omega match"
        "hairpin" in s -> "hairpin match"
        "t-match" in s || "t match" in s -> "T-match"
        "balun" in s -> "balun"
        "tuner" in s || "ant+tuner" in s -> "antenna tuner / matching network"
        "open sleeve" in s || "opensleeve" in s || "sleeve" in s || "sleve" in s -> "open-sleeve coupling"
        "end-fed" in s || "end fed" in s -> "end-fed"
        "windom" in s || "ocf" in s || "offset" in s -> "off-centre feed"
        "j-ant" in s || "j pole" in s || "j-pole" in s -> "J-type matching section"
        "feeder" in s || "feeders" in s -> "explicit feeder section"
        model.sources.size > 1 -> "${model.sources.size}-source / phased feed"
        model.sourceWireIndex != null -> "single MMANA source"
        else -> "source not explicitly identified"
    }

    private fun inferShortening(category: String, s: String, model: MaaModel): String = when {
        "trap" in s -> "trap-loaded / multiband"
        "coil" in s || "loading coil" in s -> "inductively loaded"
        "/short/" in normalizePath("/$s/") || category.equals("Short", true) || " short" in s -> {
            if (model.loads.isNotEmpty()) "shortened, explicit load(s)" else "shortened by geometry"
        }
        model.loads.any { it.kind == 0 && kotlin.math.abs(it.value1) > 0.0 } -> "inductively/capacitively loaded"
        model.loads.isNotEmpty() -> "loaded / matched"
        else -> "no shortening cue"
    }

    private fun normalizePath(s: String): String = s.replace('\\', '/').trim('/').lowercase()

    private fun tokens(s: String): Set<String> = s.lowercase()
        .replace('\\', '/')
        .split(Regex("[^a-z0-9а-яё+.-]+"))
        .map { it.trim('.', '-', '_') }
        .filter { token ->
            token.length >= 2 && token !in stopWords && !Regex("^id\\d+$").matches(token)
        }
        .toSet()
}
